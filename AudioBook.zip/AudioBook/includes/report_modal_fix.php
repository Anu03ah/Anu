<!-- Custom script for fixing modal conflicts in the reports section -->
<script src="assets/js/report-modal-fix.js"></script>
