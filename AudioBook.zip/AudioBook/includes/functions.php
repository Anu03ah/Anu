<?php
/**
 * Utility functions for the AudioBook application
 */

/**
 * Check if a user is logged in
 * 
 * @return bool True if user is logged in, false otherwise
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Check if the current user has a specific role
 * 
 * @param string $role The role to check for
 * @return bool True if user has the role, false otherwise
 */
function hasRole($role) {
    if (!isLoggedIn()) {
        return false;
    }
    return $_SESSION['user_role'] == $role;
}

/**
 * Check if the current user is an admin
 * 
 * @return bool True if user is an admin, false otherwise
 */
function isAdmin() {
    return hasRole(ROLE_ADMIN);
}

/**
 * Check if the current user is a moderator
 * 
 * @return bool True if user is a moderator, false otherwise
 */
function isModerator() {
    return hasRole(ROLE_MODERATOR);
}

/**
 * Check if the current user is a publisher
 * 
 * @return bool True if user is a publisher, false otherwise
 */
function isPublisher() {
    return hasRole(ROLE_PUBLISHER);
}

/**
 * Redirect to a specific page
 * 
 * @param string $page The page to redirect to
 */
function redirect($page) {
    header("Location: index.php?page=$page");
    exit();
}

/**
 * Set a flash message to be displayed on the next page
 * 
 * @param string $message The message to display
 * @param string $type The type of message (success, error, info, warning)
 */
function setMessage($message, $type = 'info') {
    $_SESSION['message'] = $message;
    $_SESSION['message_type'] = $type;
}

/**
 * Display a flash message if one exists
 * 
 * @return string HTML for the message
 */
function displayMessage() {
    if (isset($_SESSION['message'])) {
        $message = $_SESSION['message'];
        $type = $_SESSION['message_type'];
        
        // Clear the message
        unset($_SESSION['message']);
        unset($_SESSION['message_type']);
        
        // Skip notification-related messages
        if (strpos($message, 'Notification') === 0) {
            return '';
        }
        
        // Return the HTML for the message
        return "<div class='alert alert-$type'>$message</div>";
    }
    return '';
}

/**
 * Sanitize user input
 * 
 * @param string $data The data to sanitize
 * @return string The sanitized data
 */
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Get user by ID
 * 
 * @param int $id The user ID
 * @return array|false The user data or false if not found
 */
function getUserById($id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Get book by ID
 * 
 * @param int $id The book ID
 * @return array|false The book data or false if not found
 */
function getBookById($id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT b.*, u.name as publisher_name 
                           FROM books b 
                           JOIN users u ON b.publisher_id = u.id 
                           WHERE b.id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Check if a user has purchased a book
 * 
 * @param int $user_id The user ID
 * @param int $book_id The book ID
 * @return bool True if the user has purchased the book, false otherwise
 */
function hasPurchasedBook($user_id, $book_id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT COUNT(*) FROM purchases WHERE user_id = :user_id AND book_id = :book_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchColumn() > 0;
}

/**
 * Get the average rating for a book
 * 
 * @param int $book_id The book ID
 * @return float The average rating
 */
function getAverageRating($book_id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT AVG(rating) FROM feedback WHERE book_id = :book_id");
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    $avg = $stmt->fetchColumn();
    return $avg ? round($avg, 1) : 0;
}

/**
 * Get the total number of ratings for a book
 * 
 * @param int $book_id The book ID
 * @return int The number of ratings
 */
function getRatingCount($book_id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT COUNT(*) FROM feedback WHERE book_id = :book_id");
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchColumn();
}

/**
 * Format price as currency
 * 
 * @param float $price The price to format
 * @return string The formatted price
 */
function formatPrice($price) {
    return '₹' . number_format($price, 2);
}

/**
 * Get user's bookmark for a book
 * 
 * @param int $user_id The user ID
 * @param int $book_id The book ID
 * @return array|false The bookmark data or false if not found
 */
function getBookmark($user_id, $book_id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM bookmarks WHERE user_id = :user_id AND book_id = :book_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Create or update a bookmark
 * 
 * @param int $user_id The user ID
 * @param int $book_id The book ID
 * @param int|null $page The page number (for PDF)
 * @param int|null $position The position (for audio)
 * @return bool True if successful, false otherwise
 */
function saveBookmark($user_id, $book_id, $page = null, $position = null) {
    global $conn;
    
    // Check if bookmark exists
    $bookmark = getBookmark($user_id, $book_id);
    
    if ($bookmark) {
        // Update existing bookmark
        $stmt = $conn->prepare("UPDATE bookmarks SET 
                               last_read_page = :page,
                               last_listen_position = :position
                               WHERE user_id = :user_id AND book_id = :book_id");
    } else {
        // Create new bookmark
        $stmt = $conn->prepare("INSERT INTO bookmarks 
                               (user_id, book_id, last_read_page, last_listen_position)
                               VALUES (:user_id, :book_id, :page, :position)");
    }
    
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->bindParam(':page', $page, PDO::PARAM_INT);
    $stmt->bindParam(':position', $position, PDO::PARAM_INT);
    
    return $stmt->execute();
}

/**
 * Get trending books (most purchased in the last 30 days)
 * 
 * @param int $limit The number of books to return
 * @return array The trending books
 */
function getTrendingBooks($limit = 6) {
    global $conn;
    
    // Get books with purchases, ranked by number of purchases
    $stmt = $conn->prepare("SELECT b.*, COUNT(p.id) as purchase_count, u.name as publisher_name
                           FROM books b
                           JOIN purchases p ON b.id = p.book_id
                           JOIN users u ON b.publisher_id = u.id
                           GROUP BY b.id
                           HAVING purchase_count > 0
                           ORDER BY purchase_count DESC
                           LIMIT :limit");
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    
    $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return $books;
}

/**
 * Get free books (books with price = 0)
 * 
 * @param int $limit The number of books to return (0 for unlimited)
 * @return array The free books
 */
function getFreeBooks($limit = 6) {
    global $conn;
    
    $query = "SELECT b.*, u.name as publisher_name
              FROM books b
              JOIN users u ON b.publisher_id = u.id
              WHERE b.price = 0
              ORDER BY b.created_at DESC";
              
    if ($limit > 0) {
        $query .= " LIMIT :limit";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    } else {
        $stmt = $conn->prepare($query);
    }
    
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Get new releases (books added in the last 30 days)
 * 
 * @param int $limit The number of books to return (0 for unlimited)
 * @return array The new releases
 */
function getNewReleases($limit = 6) {
    global $conn;
    
    $query = "SELECT b.*, u.name as publisher_name
              FROM books b
              JOIN users u ON b.publisher_id = u.id
              WHERE b.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
              ORDER BY b.created_at DESC";
              
    if ($limit > 0) {
        $query .= " LIMIT :limit";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    } else {
        $stmt = $conn->prepare($query);
    }
    
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Search books by title, author, or category
 * 
 * @param string $query The search query
 * @param string|null $category The category to filter by
 * @return array The search results
 */
function searchBooks($query, $category = null) {
    global $conn;
    
    $sql = "SELECT b.*, u.name as publisher_name
            FROM books b
            JOIN users u ON b.publisher_id = u.id
            WHERE (b.title LIKE :query OR b.author LIKE :query)";
    
    if ($category) {
        $sql .= " AND b.category = :category";
    }
    
    $sql .= " ORDER BY b.title";
    
    $stmt = $conn->prepare($sql);
    
    $searchQuery = "%$query%";
    $stmt->bindParam(':query', $searchQuery, PDO::PARAM_STR);
    
    if ($category) {
        $stmt->bindParam(':category', $category, PDO::PARAM_STR);
    }
    
    $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Get all book categories
 * 
 * @return array The categories
 */
function getCategories() {
    global $conn;
    
    $stmt = $conn->prepare("SELECT DISTINCT category FROM books WHERE category IS NOT NULL ORDER BY category");
    $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

/**
 * Get user's purchased books
 * 
 * @param int $user_id The user ID
 * @return array The purchased books
 */
function getPurchasedBooks($user_id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT b.*, u.name as publisher_name, p.purchase_date
                           FROM books b
                           JOIN purchases p ON b.id = p.book_id
                           JOIN users u ON b.publisher_id = u.id
                           WHERE p.user_id = :user_id
                           ORDER BY p.purchase_date DESC");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Get publisher's uploaded books
 * 
 * @param int $publisher_id The publisher ID
 * @return array The uploaded books
 */
function getPublisherBooks($publisher_id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT b.*, 
                           (SELECT COUNT(*) FROM purchases WHERE book_id = b.id) as purchase_count
                           FROM books b
                           WHERE b.publisher_id = :publisher_id
                           ORDER BY b.created_at DESC");
    $stmt->bindParam(':publisher_id', $publisher_id, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Get user's license applications
 * 
 * @param int $user_id The user ID
 * @return array The license applications
 */
function getUserLicenses($user_id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT l.*, u.name as approved_by_name
                           FROM licenses l
                           LEFT JOIN users u ON l.approved_by = u.id
                           WHERE l.user_id = :user_id
                           ORDER BY l.created_at DESC");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Get pending license applications
 * 
 * @param string $type The license type (moderator or publisher)
 * @return array The pending applications
 */
function getPendingLicenses($type = null) {
    global $conn;
    
    $sql = "SELECT l.*, u.name as user_name, u.email as user_email
            FROM licenses l
            JOIN users u ON l.user_id = u.id
            WHERE l.status = 'pending'";
    
    if ($type) {
        $sql .= " AND l.type = :type";
    }
    
    $sql .= " ORDER BY l.created_at ASC";
    
    $stmt = $conn->prepare($sql);
    
    if ($type) {
        $stmt->bindParam(':type', $type, PDO::PARAM_STR);
    }
    
    $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Get pending complaints
 * 
 * @return array The pending complaints
 */
function getPendingComplaints() {
    global $conn;
    
    $stmt = $conn->prepare("SELECT c.*, u.name as user_name, u.email as user_email
                           FROM complaints c
                           JOIN users u ON c.user_id = u.id
                           WHERE c.status != 'resolved'
                           ORDER BY c.created_at ASC");
    $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Create a notification
 * 
 * @param int $user_id The user ID
 * @param string $type The notification type
 * @param string $message The notification message
 * @return bool True if successful, false otherwise
 */
function createNotification($user_id, $type, $message) {
    global $conn;
    
    $stmt = $conn->prepare("INSERT INTO notifications (user_id, type, message)
                           VALUES (:user_id, :type, :message)");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':type', $type, PDO::PARAM_STR);
    $stmt->bindParam(':message', $message, PDO::PARAM_STR);
    
    return $stmt->execute();
}

/**
 * Get user's unread notifications
 * 
 * @param int $user_id The user ID
 * @return array The unread notifications
 */
function getUnreadNotifications($user_id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM notifications
                           WHERE user_id = :user_id AND is_read = 0
                           ORDER BY created_at DESC");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Mark a notification as read
 * 
 * @param int $notification_id The notification ID
 * @return bool True if successful, false otherwise
 */
function markNotificationAsRead($notification_id) {
    global $conn;
    
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = :id");
    $stmt->bindParam(':id', $notification_id, PDO::PARAM_INT);
    
    return $stmt->execute();
}

// This function has been moved to line 295

/**
 * Get total sales count for a publisher
 * 
 * @param int $publisher_id The publisher ID
 * @return int The total number of sales
 */
function getPublisherTotalSales($publisher_id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT COUNT(*) FROM purchases p 
                           JOIN books b ON p.book_id = b.id 
                           WHERE b.publisher_id = :publisher_id");
    $stmt->bindParam(':publisher_id', $publisher_id, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchColumn();
}

/**
 * Get total revenue for a publisher
 * 
 * @param int $publisher_id The publisher ID
 * @return float The total revenue
 */
function getPublisherRevenue($publisher_id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT SUM(b.price) FROM purchases p 
                           JOIN books b ON p.book_id = b.id 
                           WHERE b.publisher_id = :publisher_id");
    $stmt->bindParam(':publisher_id', $publisher_id, PDO::PARAM_INT);
    $stmt->execute();
    
    $revenue = $stmt->fetchColumn();
    return $revenue ? $revenue : 0;
}

/**
 * Get sales count for a specific book
 * 
 * @param int $book_id The book ID
 * @return int The number of sales
 */
function getBookSales($book_id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT COUNT(*) FROM purchases WHERE book_id = :book_id");
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchColumn();
}

/**
 * Get revenue for a specific book
 * 
 * @param int $book_id The book ID
 * @return float The total revenue from this book
 */
function getBookRevenue($book_id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT price FROM books WHERE id = :book_id");
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    $price = $stmt->fetchColumn();
    
    $stmt = $conn->prepare("SELECT COUNT(*) FROM purchases WHERE book_id = :book_id");
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    $sales = $stmt->fetchColumn();
    
    return $price * $sales;
}

/**
 * Get users and publishers for moderator management
 * 
 * @param string|null $search Search query for name or email
 * @param string|null $role Filter by role (user, publisher)
 * @param string|null $status Filter by status (active, blocked, pending)
 * @return array The users and publishers
 */
function getUsersForModeration($search = null, $role = null, $status = null) {
    global $conn;
    
    $sql = "SELECT id, name, email, role, status, created_at FROM users WHERE role != 'admin'";
    $params = [];
    
    // Don't show other moderators in the list
    $sql .= " AND role != 'moderator'";
    
    // Add search condition if provided
    if ($search) {
        $sql .= " AND (name LIKE :search OR email LIKE :search)";
        $params[':search'] = "%$search%";
    }
    
    // Add role filter if provided
    if ($role) {
        $sql .= " AND role = :role";
        $params[':role'] = $role;
    }
    
    // Add status filter if provided
    if ($status) {
        $sql .= " AND status = :status";
        $params[':status'] = $status;
    }
    
    // Order by role (publishers first) and then by name
    $sql .= " ORDER BY FIELD(role, 'publisher', 'user'), name ASC";
    
    $stmt = $conn->prepare($sql);
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}



/**
 * Get pending account unblock appeals
 * 
 * @param string|null $userRole Filter appeals by user role (moderator, publisher, user)
 * @return array The pending appeals with user information
 */
function getPendingAppeals($userRole = null) {
    global $conn;
    
    $sql = "SELECT a.*, u.name, u.email, u.role FROM appeals a 
            JOIN users u ON a.user_id = u.id 
            WHERE a.status = 'pending'";
    $params = [];
    
    // Filter by user role if specified
    if ($userRole) {
        if ($userRole === 'non_moderator') {
            // For moderator dashboard - show appeals from users and publishers only
            $sql .= " AND u.role != 'moderator'";
        } else if ($userRole === 'moderator') {
            // For admin dashboard - show appeals from moderators only
            $sql .= " AND u.role = :role";
            $params[':role'] = 'moderator';
        } else {
            // Filter by specific role
            $sql .= " AND u.role = :role";
            $params[':role'] = $userRole;
        }
    }
    
    // Order by creation date, newest first
    $sql .= " ORDER BY a.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    
    // Bind parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Get a specific appeal by ID
 * 
 * @param int $appealId The appeal ID
 * @return array|false The appeal data or false if not found
 */
function getAppealById($appealId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT a.*, u.name, u.email, u.role FROM appeals a 
                          JOIN users u ON a.user_id = u.id 
                          WHERE a.id = :id");
    $stmt->bindParam(':id', $appealId, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Process an account unblock appeal
 * 
 * @param int $appealId The appeal ID
 * @param string $status The new status (approved, rejected)
 * @param int $reviewerId The ID of the admin/moderator who reviewed the appeal
 * @param string $responseMessage Optional response message to the user
 * @return bool True if successful, false otherwise
 */
function processAppeal($appealId, $status, $reviewerId, $responseMessage = '') {
    global $conn;
    
    try {
        // Start transaction
        $conn->beginTransaction();
        
        // Get appeal details
        $appeal = getAppealById($appealId);
        if (!$appeal) {
            return false;
        }
        
        // Update appeal status
        $stmt = $conn->prepare("UPDATE appeals SET 
                              status = :status, 
                              reviewed_by = :reviewer_id, 
                              updated_at = NOW() 
                              WHERE id = :appeal_id");
        $stmt->bindParam(':status', $status, PDO::PARAM_STR);
        $stmt->bindParam(':reviewer_id', $reviewerId, PDO::PARAM_INT);
        $stmt->bindParam(':appeal_id', $appealId, PDO::PARAM_INT);
        $stmt->execute();
        
        // If approved, unblock the user
        if ($status === 'approved') {
            $stmt = $conn->prepare("UPDATE users SET status = 'active' WHERE id = :user_id");
            $stmt->bindParam(':user_id', $appeal['user_id'], PDO::PARAM_INT);
            $stmt->execute();
            
            // Create notification for the user
            $message = "Your account unblock appeal has been approved. Your account is now active."; 
            if (!empty($responseMessage)) {
                $message .= " Message from moderator: " . $responseMessage;
            }
            createNotification($appeal['user_id'], 'appeal_approved', $message);
        } else {
            // Create rejection notification
            $message = "Your account unblock appeal has been rejected."; 
            if (!empty($responseMessage)) {
                $message .= " Reason: " . $responseMessage;
            }
            createNotification($appeal['user_id'], 'appeal_rejected', $message);
        }
        
        // Commit transaction
        $conn->commit();
        return true;
    } catch (PDOException $e) {
        // Rollback transaction on error
        $conn->rollBack();
        return false;
    }
}

/**
 * Create a new report
 * 
 * @param int $reporterId The ID of the user making the report
 * @param string $reportType The type of report (book, user, review)
 * @param int $targetId The ID of the reported item
 * @param string $reason The reason for the report
 * @param string $details Additional details about the report
 * @return bool True if successful, false otherwise
 */
function createReport($reporterId, $reportType, $targetId, $reason, $details = '') {
    global $conn;
    
    try {
        // Start transaction
        $conn->beginTransaction();
        
        // Create report record
        $stmt = $conn->prepare("INSERT INTO reports (reporter_id, report_type, target_id, reason, details, created_at) 
                              VALUES (:reporter_id, :report_type, :target_id, :reason, :details, NOW())");
        $stmt->bindParam(':reporter_id', $reporterId, PDO::PARAM_INT);
        $stmt->bindParam(':report_type', $reportType, PDO::PARAM_STR);
        $stmt->bindParam(':target_id', $targetId, PDO::PARAM_INT);
        $stmt->bindParam(':reason', $reason, PDO::PARAM_STR);
        $stmt->bindParam(':details', $details, PDO::PARAM_STR);
        $stmt->execute();
        
        // Get the report ID
        $reportId = $conn->lastInsertId();
        
        // Create notifications for moderators and admins
        $reportTypeCapitalized = ucfirst($reportType);
        $notification_message = "New {$reportTypeCapitalized} report submitted. ID: {$reportId}";
        
        // Get all moderators and admins
        $stmt = $conn->prepare("SELECT id, role FROM users WHERE role IN ('moderator', 'admin')");
        $stmt->execute();
        $staff = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Send notification to each staff member
        foreach ($staff as $staff_member) {
            createNotification($staff_member['id'], 'report', $notification_message);
        }
        
        // Commit transaction
        $conn->commit();
        return true;
    } catch (PDOException $e) {
        // Rollback transaction on error
        $conn->rollBack();
        return false;
    }
}

/**
 * Get pending reports
 * 
 * @param string|null $reportType Filter by report type (book, user, review)
 * @return array The pending reports with reporter information
 */
function getPendingReports($reportType = null) {
    global $conn;
    
    $sql = "SELECT r.*, 
                  u1.name as reporter_name, u1.email as reporter_email, 
                  u2.name as resolver_name, u2.email as resolver_email 
           FROM reports r 
           JOIN users u1 ON r.reporter_id = u1.id 
           LEFT JOIN users u2 ON r.resolved_by = u2.id 
           WHERE r.status IN ('pending', 'in_progress')";
    $params = [];
    
    // Filter by report type if specified
    if ($reportType) {
        $sql .= " AND r.report_type = :report_type";
        $params[':report_type'] = $reportType;
    }
    
    // Order by creation date, newest first
    $sql .= " ORDER BY r.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    
    // Bind parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->execute();
    $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Fetch additional information for each report based on type
    foreach ($reports as &$report) {
        switch ($report['report_type']) {
            case 'book':
                $book = getBookById($report['target_id']);
                if ($book) {
                    $report['target_name'] = $book['title'];
                    $report['target_details'] = "Author: {$book['author']}";
                    $report['target_link'] = "index.php?page=book&id={$report['target_id']}";
                }
                break;
                
            case 'user':
                $user = getUserById($report['target_id']);
                if ($user) {
                    $report['target_name'] = $user['name'];
                    $report['target_details'] = "Email: {$user['email']}, Role: {$user['role']}";
                    // No direct link to user profile for privacy reasons
                }
                break;
                
            case 'review':
                // Get review details
                $stmt = $conn->prepare("SELECT f.*, b.title as book_title, b.id as book_id, u.name as reviewer_name 
                                       FROM feedback f 
                                       LEFT JOIN books b ON f.book_id = b.id 
                                       LEFT JOIN users u ON f.user_id = u.id 
                                       WHERE f.id = :review_id");
                $stmt->bindParam(':review_id', $report['target_id'], PDO::PARAM_INT);
                $stmt->execute();
                $review = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($review) {
                    // Review exists
                    $reviewerName = isset($review['reviewer_name']) ? $review['reviewer_name'] : 'Unknown User';
                    $bookTitle = isset($review['book_title']) ? $review['book_title'] : 'Unknown Book';
                    
                    $report['target_name'] = "Review by {$reviewerName}";
                    $report['target_details'] = "Book: {$bookTitle}, Rating: {$review['rating']}/5";
                    
                    if (isset($review['book_id'])) {
                        $report['target_link'] = "index.php?page=book&id={$review['book_id']}";
                    }
                    
                    if (isset($review['comment'])) {
                        $report['review_content'] = $review['comment'];
                    }
                } else {
                    // Review doesn't exist anymore
                    $report['target_name'] = "Review ID: {$report['target_id']} (Deleted)";
                    $report['target_details'] = "This review appears to have been deleted.";
                }
                break;
        }
    }
    
    return $reports;
}

/**
 * Get a specific report by ID
 * 
 * @param int $reportId The report ID
 * @return array|false The report data or false if not found
 */
function getReportById($reportId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT r.*, 
                            u1.name as reporter_name, u1.email as reporter_email, 
                            u2.name as resolver_name, u2.email as resolver_email 
                            FROM reports r 
                            JOIN users u1 ON r.reporter_id = u1.id 
                            LEFT JOIN users u2 ON r.resolved_by = u2.id 
                            WHERE r.id = :id");
    $stmt->bindParam(':id', $reportId, PDO::PARAM_INT);
    $stmt->execute();
    
    $report = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($report) {
        // Add additional information based on report type
        switch ($report['report_type']) {
            case 'book':
                $book = getBookById($report['target_id']);
                if ($book) {
                    $report['target_name'] = $book['title'];
                    $report['target_details'] = "Author: {$book['author']}";
                    $report['target_link'] = "index.php?page=book&id={$report['target_id']}";
                    $report['book_data'] = $book;
                }
                break;
                
            case 'user':
                $user = getUserById($report['target_id']);
                if ($user) {
                    $report['target_name'] = $user['name'];
                    $report['target_details'] = "Email: {$user['email']}, Role: {$user['role']}";
                    $report['user_data'] = $user;
                }
                break;
                
            case 'review':
                // Get review details
                $stmt = $conn->prepare("SELECT f.*, b.title as book_title, b.id as book_id, u.name as reviewer_name 
                                      FROM feedback f 
                                      JOIN books b ON f.book_id = b.id 
                                      JOIN users u ON f.user_id = u.id 
                                      WHERE f.id = :review_id");
                $stmt->bindParam(':review_id', $report['target_id'], PDO::PARAM_INT);
                $stmt->execute();
                $review = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($review) {
                    $report['target_name'] = "Review by {$review['reviewer_name']}";
                    $report['target_details'] = "Book: {$review['book_title']}, Rating: {$review['rating']}/5";
                    $report['target_link'] = "index.php?page=book&id={$review['book_id']}";
                    $report['review_content'] = $review['comment'];
                    $report['review_data'] = $review;
                }
                break;
        }
    }
    
    return $report;
}

/**
 * Process a report
 * 
 * @param int $reportId The report ID
 * @param string $status The new status (in_progress, resolved, dismissed)
 * @param int $resolverId The ID of the moderator/admin who processed the report
 * @param string $resolutionNote Optional note about the resolution
 * @param bool $notifyReporter Whether to notify the reporter about the resolution
 * @return bool True if successful, false otherwise
 */
function processReport($reportId, $status, $resolverId, $resolutionNote = '', $notifyReporter = true) {
    global $conn;
    
    try {
        // Start transaction
        $conn->beginTransaction();
        
        // Get report details
        $report = getReportById($reportId);
        if (!$report) {
            return false;
        }
        
        // Update report status
        $stmt = $conn->prepare("UPDATE reports SET 
                              status = :status, 
                              resolved_by = :resolver_id, 
                              resolution_note = :resolution_note,
                              updated_at = NOW() 
                              WHERE id = :report_id");
        $stmt->bindParam(':status', $status, PDO::PARAM_STR);
        $stmt->bindParam(':resolver_id', $resolverId, PDO::PARAM_INT);
        $stmt->bindParam(':resolution_note', $resolutionNote, PDO::PARAM_STR);
        $stmt->bindParam(':report_id', $reportId, PDO::PARAM_INT);
        $stmt->execute();
        
        // Create notification for the reporter if status is resolved or dismissed and notification is requested
        if (($status === 'resolved' || $status === 'dismissed') && $notifyReporter) {
            $statusCapitalized = ucfirst($status);
            $message = "Your report has been {$status}."; 
            if (!empty($resolutionNote)) {
                $message .= " Note: {$resolutionNote}";
            }
            createNotification($report['reporter_id'], 'report_' . $status, $message);
        }
        
        // Commit transaction
        $conn->commit();
        return true;
    } catch (PDOException $e) {
        // Rollback transaction on error
        $conn->rollBack();
        return false;
    }
}

/**
 * Remove a book (used when processing book reports)
 * 
 * @param int $bookId The book ID
 * @param string $reason The reason for removal
 * @return bool True if successful, false otherwise
 */
function removeBook($bookId, $reason) {
    global $conn;
    
    try {
        // Start transaction
        $conn->beginTransaction();
        
        // Get book details first
        $book = getBookById($bookId);
        if (!$book) {
            return false;
        }
        
        // Check if the books table has a status column
        $stmt = $conn->prepare("SHOW COLUMNS FROM books LIKE 'status'");
        $stmt->execute();
        $hasStatusColumn = $stmt->rowCount() > 0;
        
        if ($hasStatusColumn) {
            // Update book status to 'removed' if the column exists
            $stmt = $conn->prepare("UPDATE books SET 
                                   status = 'removed', 
                                   removal_reason = :reason,
                                   updated_at = NOW() 
                                   WHERE id = :book_id");
            $stmt->bindParam(':reason', $reason, PDO::PARAM_STR);
            $stmt->bindParam(':book_id', $bookId, PDO::PARAM_INT);
            $stmt->execute();
        } else {
            // If status column doesn't exist, just delete the book
            $stmt = $conn->prepare("DELETE FROM books WHERE id = :book_id");
            $stmt->bindParam(':book_id', $bookId, PDO::PARAM_INT);
            $stmt->execute();
        }
        
        // Notify the publisher
        $message = "Your book '{$book['title']}' has been removed due to a violation of our terms. Reason: {$reason}";
        createNotification($book['publisher_id'], 'book_removed', $message);
        
        // Commit transaction
        $conn->commit();
        return true;
    } catch (PDOException $e) {
        // Rollback transaction on error
        $conn->rollBack();
        error_log("Error removing book: " . $e->getMessage());
        return false;
    }
}

/**
 * Block a user (used when processing user reports)
 * 
 * @param int $userId The user ID
 * @param string|int $duration The block duration in days or 'permanent'
 * @param string $reason The reason for blocking
 * @return bool True if successful, false otherwise
 */
function blockUser($userId, $duration, $reason) {
    global $conn;
    
    try {
        // Start transaction
        $conn->beginTransaction();
        
        // Get user details first
        $user = getUserById($userId);
        if (!$user) {
            return false;
        }
        
        // Check if the users table has the necessary columns
        $stmt = $conn->prepare("SHOW COLUMNS FROM users LIKE 'unblock_date'");
        $stmt->execute();
        $hasUnblockDateColumn = $stmt->rowCount() > 0;
        
        $stmt = $conn->prepare("SHOW COLUMNS FROM users LIKE 'block_reason'");
        $stmt->execute();
        $hasBlockReasonColumn = $stmt->rowCount() > 0;
        
        // Calculate unblock date if not permanent
        $unblockDate = null;
        if ($duration !== 'permanent') {
            $unblockDate = date('Y-m-d H:i:s', strtotime("+{$duration} days"));
        }
        
        // Update user status to 'blocked'
        if ($hasUnblockDateColumn && $hasBlockReasonColumn) {
            // Full update with all columns
            $stmt = $conn->prepare("UPDATE users SET 
                                   status = 'blocked', 
                                   block_reason = :reason,
                                   unblock_date = :unblock_date,
                                   updated_at = NOW()
                                   WHERE id = :user_id");
            $stmt->bindParam(':reason', $reason, PDO::PARAM_STR);
            $stmt->bindParam(':unblock_date', $unblockDate, PDO::PARAM_STR);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        } else {
            // Simple update with just status
            $stmt = $conn->prepare("UPDATE users SET status = 'blocked', updated_at = NOW() WHERE id = :user_id");
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        }
        $stmt->execute();
        
        // Create block notification for the user
        $blockMessage = "Your account has been blocked";
        if ($duration === 'permanent') {
            $blockMessage .= " permanently";
        } else {
            $blockMessage .= " for {$duration} days";
        }
        $blockMessage .= ". Reason: {$reason}";
        createNotification($userId, 'account_blocked', $blockMessage);
        
        // Commit transaction
        $conn->commit();
        return true;
    } catch (PDOException $e) {
        // Rollback transaction on error
        $conn->rollBack();
        return false;
    }
}

/**
 * Remove a review (used when processing review reports)
 * 
 * @param int $reviewId The review ID
 * @param string $reason The reason for removal
 * @param bool $notifyReviewer Whether to notify the reviewer about the removal
 * @return bool True if successful, false otherwise
 */
function removeReview($reviewId, $reason, $notifyReviewer = true) {
    global $conn;
    
    try {
        // Start transaction
        $conn->beginTransaction();
        
        // Get review details first
        $stmt = $conn->prepare("SELECT f.*, b.title as book_title, u.id as reviewer_id, u.name as reviewer_name 
                              FROM feedback f 
                              JOIN books b ON f.book_id = b.id 
                              JOIN users u ON f.user_id = u.id 
                              WHERE f.id = :review_id");
        $stmt->bindParam(':review_id', $reviewId, PDO::PARAM_INT);
        $stmt->execute();
        $review = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$review) {
            return false;
        }
        
        // Check if the feedback table has a status column
        $stmt = $conn->prepare("SHOW COLUMNS FROM feedback LIKE 'status'");
        $stmt->execute();
        $hasStatusColumn = $stmt->rowCount() > 0;
        
        if ($hasStatusColumn) {
            // Update review status to 'removed' if the column exists
            $stmt = $conn->prepare("UPDATE feedback SET 
                                   status = 'removed', 
                                   removal_reason = :reason
                                   WHERE id = :review_id");
            $stmt->bindParam(':reason', $reason, PDO::PARAM_STR);
            $stmt->bindParam(':review_id', $reviewId, PDO::PARAM_INT);
            $stmt->execute();
        } else {
            // If status column doesn't exist, just delete the review
            $stmt = $conn->prepare("DELETE FROM feedback WHERE id = :review_id");
            $stmt->bindParam(':review_id', $reviewId, PDO::PARAM_INT);
            $stmt->execute();
        }
        
        // Notify the reviewer if requested
        if ($notifyReviewer) {
            $message = "Your review for the book '{$review['book_title']}' has been removed. Reason: {$reason}";
            createNotification($review['reviewer_id'], 'review_removed', $message);
        }
        
        // Commit transaction
        $conn->commit();
        return true;
    } catch (PDOException $e) {
        // Rollback transaction on error
        $conn->rollBack();
        error_log("Error removing review: " . $e->getMessage());
        return false;
    }
}
?>
