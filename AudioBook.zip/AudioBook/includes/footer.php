    </main>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5><i class="fas fa-book-reader me-2"></i><?php echo APP_NAME; ?></h5>
                    <p>Your digital reading and listening experience. Access thousands of books in both PDF and audio formats.</p>
                </div>
                <div class="col-md-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-white">Home</a></li>
                        <li><a href="index.php?page=search" class="text-white">Browse Books</a></li>
                        <?php if (isLoggedIn()): ?>
                            <li><a href="index.php?page=dashboard" class="text-white">Dashboard</a></li>
                        <?php else: ?>
                            <li><a href="index.php?page=login" class="text-white">Login</a></li>
                            <li><a href="index.php?page=register" class="text-white">Register</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Contact Us</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-envelope me-2"></i>support@audiobook.com</li>
                        <li><i class="fas fa-phone me-2"></i>+1 (555) 123-4567</li>
                        <li><i class="fas fa-map-marker-alt me-2"></i>123 Book Street, Reading City</li>
                    </ul>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Report Modal -->
    <?php if (isLoggedIn()): ?>
    <div class="modal fade" id="reportModal" tabindex="-1" aria-labelledby="reportModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="report-modal-title">
                        <i class="fas fa-flag me-2"></i>
                        Report
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="reportForm" action="actions/submit_report.php" method="post">
                        <input type="hidden" id="report-type" name="report_type" value="">
                        <input type="hidden" id="target-id" name="target_id" value="">
                        
                        <div class="mb-3">
                            <label class="form-label">You are reporting:</label>
                            <p id="report-target-name" class="fw-bold"></p>
                        </div>
                        
                        <div class="mb-3">
                            <label for="report-reason" class="form-label">Reason for reporting</label>
                            <select class="form-select" id="report-reason" name="reason" required>
                                <option value="">Select a reason</option>
                                <option value="inappropriate_content">Inappropriate Content</option>
                                <option value="copyright_violation">Copyright Violation</option>
                                <option value="spam">Spam</option>
                                <option value="offensive_language">Offensive Language</option>
                                <option value="harassment">Harassment</option>
                                <option value="misinformation">Misinformation</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="report-details" class="form-label">Additional Details</label>
                            <textarea class="form-control" id="report-details" name="details" rows="4" placeholder="Please provide any additional details that will help us understand the issue..."></textarea>
                        </div>
                        
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i> 
                                Our moderators will review your report and take appropriate action. Thank you for helping keep our community safe.
                            </small>
                        </div>
                        
                        <div class="d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-danger">Submit Report</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Contact Support Modal for Blocked Users -->
    <div class="modal fade" id="contactSupportModal" tabindex="-1" aria-labelledby="contactSupportModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="contactSupportModalLabel">
                        <i class="fas fa-headset me-2" style="font-size: 1.4rem;"></i>
                        Contact Support
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info mb-4">
                        <p class="mb-0"><i class="fas fa-info-circle me-2" style="font-size: 1.4rem;"></i> Please provide details about your account block appeal. Our team will review your request and respond within 24-48 hours.</p>
                    </div>
                    
                    <form id="contactSupportForm" action="actions/submit_appeal.php" method="post">
                        <input type="hidden" name="appeal_type" value="block">
                        
                        <div class="mb-3">
                            <label for="contact-email" class="form-label">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input type="email" class="form-control" id="contact-email" name="email" required>
                            </div>
                            <small class="text-muted">Please use the email associated with your blocked account</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="contact-name" class="form-label">Full Name</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                                <input type="text" class="form-control" id="contact-name" name="name" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="contact-reason" class="form-label">Why should we unblock your account?</label>
                            <textarea class="form-control" id="contact-reason" name="reason" rows="5" placeholder="Please explain why you believe your account should be unblocked..." required></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="contact-additional" class="form-label">Additional Information (Optional)</label>
                            <textarea class="form-control" id="contact-additional" name="additional" rows="3" placeholder="Any additional information that might help us with your appeal..."></textarea>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <button type="button" class="btn btn-outline-secondary return-to-login">
                                <i class="fas fa-arrow-left me-2"></i> Return to Login
                            </button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane me-2"></i> Submit Appeal
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Custom JS -->
    <script src="assets/js/script.js"></script>
    <script src="assets/js/notifications.js"></script>
    <script src="assets/js/modal-fix.js"></script>
    <script src="assets/js/notification-blocker.js"></script>
    <script src="assets/js/search-button.js"></script>
    <script src="assets/js/clickable-cards.js"></script>
    <script src="assets/js/auth-modal.js"></script>
    <script src="assets/js/auth-modal-trigger.js"></script>
    <script src="assets/js/contact-support.js"></script>
    <script src="assets/js/report.js"></script>
</body>
</html>
