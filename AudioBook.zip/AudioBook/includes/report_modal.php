<!-- Report Modal -->
<div class="modal fade" id="reportModal" tabindex="-1" aria-labelledby="reportModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="report-modal-title">Report</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="reportForm" action="actions/submit_report.php" method="post">
                    <input type="hidden" id="report-type" name="report_type" value="">
                    <input type="hidden" id="target-id" name="target_id" value="">
                    
                    <div class="mb-3">
                        <label class="form-label">You are reporting:</label>
                        <p id="report-target-name" class="fw-bold"></p>
                    </div>
                    
                    <div class="mb-3">
                        <label for="report-reason" class="form-label">Reason for reporting</label>
                        <select class="form-select" id="report-reason" name="reason" required>
                            <option value="">Select a reason</option>
                            <option value="inappropriate_content">Inappropriate Content</option>
                            <option value="copyright_violation">Copyright Violation</option>
                            <option value="spam">Spam</option>
                            <option value="offensive_language">Offensive Language</option>
                            <option value="harassment">Harassment</option>
                            <option value="misinformation">Misinformation</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="report-details" class="form-label">Additional Details</label>
                        <textarea class="form-control" id="report-details" name="details" rows="4" placeholder="Please provide any additional details that will help us understand the issue..."></textarea>
                    </div>
                    
                    <div class="alert alert-info">
                        <small>
                            <i class="fas fa-info-circle me-1"></i> 
                            Our moderators will review your report and take appropriate action. Thank you for helping keep our community safe.
                        </small>
                    </div>
                    
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Submit Report</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
