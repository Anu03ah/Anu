<?php
// Clear the keep_auth_modal_open session variable if the user is logged in
// or if they navigate to any page other than the home page
if (isLoggedIn() || (isset($_GET['page']) && $_GET['page'] != '')) {
    unset($_SESSION['keep_auth_modal_open']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Your Digital Reading & Listening Experience</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/book-cards.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="assets/css/modern.css">
    <link rel="stylesheet" href="assets/css/hide-format-badges.css">
    <!-- PDF.js for PDF viewing -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js"></script>
    <!-- Dropdown fix script -->
    <script src="assets/js/dropdown-fix.js"></script>
    <!-- Reviewer details script -->
    <script src="assets/js/reviewer-details.js"></script>
    <!-- Auth AJAX script -->
    <script src="assets/js/auth-ajax.js"></script>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-book-reader me-2"></i><?php echo APP_NAME; ?>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Home">
                            <i class="fas fa-home"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=search" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Browse Books">
                            <i class="fas fa-book-open"></i>
                        </a>
                    </li>
                    <!-- Dashboard icon moved to right side of navbar -->
                </ul>
                
                <!-- Empty div to maintain spacing -->
                <div class="mx-auto"></div>
                
                <ul class="navbar-nav ms-auto">
                    <!-- Fixed Search Form -->
                    <li class="nav-item me-2">
                        <form action="index.php" method="GET" class="search-form" style="display: flex; align-items: center;">
                            <input type="hidden" name="page" value="search">
                            <div class="search-container" style="display: flex; flex-direction: row; align-items: center;">
                                <input class="search-input" type="search" name="query" placeholder="Search books..." aria-label="Search" style="margin-right: 8px;">
                                <button class="search-button" type="submit" style="border-radius: 50%; background-color: rgba(255, 255, 255, 0.2); width: 38px; height: 38px; display: flex; align-items: center; justify-content: center; border: none; color: white; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);">
                                    <i class="fas fa-search" style="font-size: 1rem;"></i>
                                </button>
                            </div>
                        </form>
                    </li>
                    
                    <?php if (isLoggedIn()): ?>
                        <!-- Notifications -->
                        <li class="nav-item dropdown">
                            <?php 
                            // Get all notifications for dropdown (limited to 5)
                            global $conn;
                            $stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = :user_id ORDER BY created_at DESC LIMIT 5");
                            $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
                            $stmt->execute();
                            $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            
                            // Count unread notifications
                            $unread_count = 0;
                            foreach ($notifications as $notification) {
                                if (!$notification['is_read']) {
                                    $unread_count++;
                                }
                            }
                            $count = $unread_count;
                            ?>
                            <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Notifications">
                                <i class="fas fa-bell"></i>
                                <?php if ($count > 0): ?>
                                <span class="badge bg-danger notification-badge"><?php echo $count; ?></span>
                                <?php endif; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end notification-dropdown" aria-labelledby="notificationsDropdown" style="width: 320px; max-height: 400px; overflow-y: auto;">
                                <?php if ($count > 0): ?>
                                <li>
                                    <div class="dropdown-item">
                                        <a href="actions/notification_actions.php?action=mark_all_read&redirect=dashboard" class="btn btn-sm btn-outline-primary w-100 mark-all-read" data-toast-message="All notifications marked as read" data-toast-type="success">
                                            <i class="fas fa-check-double me-1"></i> Mark All as Read
                                        </a>
                                    </div>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <?php endif; ?>
                                <?php if (count($notifications) > 0): ?>
                                    <?php foreach ($notifications as $notification): ?>
                                    <li>
                                        <div class="dropdown-item notification-item <?php echo $notification['is_read'] ? '' : 'bg-light'; ?>">
                                            <div class="d-flex justify-content-between align-items-start mb-1">
                                                <small class="text-muted"><?php echo date('M d, H:i', strtotime($notification['created_at'])); ?></small>
                                                <?php if (!$notification['is_read']): ?>
                                                <span class="badge bg-primary badge-sm">New</span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="mb-2">
                                                <?php 
                                                // Display icon based on notification type
                                                $icon = 'info-circle';
                                                switch ($notification['type']) {
                                                    case 'purchase': $icon = 'shopping-cart'; break;
                                                    case 'review': $icon = 'star'; break;
                                                    case 'license_application':
                                                    case 'license_approved':
                                                    case 'license_rejected': $icon = 'id-card'; break;
                                                    case 'book_uploaded':
                                                    case 'sale': $icon = 'book'; break;
                                                    case 'complaint_resolved': $icon = 'check-circle'; break;
                                                    case 'account_blocked': $icon = 'ban'; break;
                                                }
                                                ?>
                                                <i class="fas fa-<?php echo $icon; ?> me-1"></i>
                                                <?php echo $notification['message']; ?>
                                            </div>
                                            <div class="d-flex justify-content-end gap-1">
                                                <?php if (!$notification['is_read']): ?>
                                                <a href="actions/notification_actions.php?id=<?php echo $notification['id']; ?>&action=mark_read&redirect=dashboard" class="btn btn-sm btn-outline-secondary mark-notification-read" data-notification-id="<?php echo $notification['id']; ?>" data-toast-message="Notification marked as read" data-toast-type="success" data-bs-toggle="tooltip" data-bs-placement="top" title="Mark as read">
                                                    <i class="fas fa-check"></i>
                                                </a>
                                                <?php endif; ?>
                                                <a href="#" class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#notification-detail-dropdown-<?php echo $notification['id']; ?>" aria-expanded="false" data-bs-toggle="tooltip" data-bs-placement="top" title="View details">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="actions/notification_actions.php?id=<?php echo $notification['id']; ?>&action=delete&redirect=dashboard" class="btn btn-sm btn-outline-danger" data-toast-message="Notification deleted" data-toast-type="success" onclick="return confirm('Are you sure you want to delete this notification?')" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </div>
                                            <div class="collapse mt-2" id="notification-detail-dropdown-<?php echo $notification['id']; ?>">
                                                <div class="card card-body py-2 px-3 bg-light">
                                                    <small>Type: <?php echo ucfirst($notification['type']); ?></small>
                                                    <small>Created: <?php echo date('F d, Y H:i:s', strtotime($notification['created_at'])); ?></small>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li><hr class="dropdown-divider my-1"></li>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <li><div class="dropdown-item text-center">No notifications</div></li>
                                <?php endif; ?>
                                <li>
                                    <div class="dropdown-item text-center">
                                        <button id="loadMoreNotifications" class="btn btn-sm btn-outline-primary w-100">
                                            <i class="fas fa-chevron-down me-1"></i> Load More
                                        </button>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        
                        <!-- Dashboard Icon -->
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?page=dashboard" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Dashboard">
                                <i class="fas fa-tachometer-alt"></i>
                            </a>
                        </li>
                        
                        <!-- User Menu -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-circle"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li class="px-3 py-2 d-flex align-items-center">
                                    <i class="fas fa-user-circle text-primary me-2 fs-5"></i>
                                    <div>
                                        <div class="fw-bold"><?php echo $_SESSION['user_name']; ?></div>
                                        <small class="text-muted"><?php echo $_SESSION['user_email'] ?? ''; ?></small>
                                    </div>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="index.php?page=dashboard"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
                                <li><a class="dropdown-item" href="index.php?page=profile"><i class="fas fa-user-edit me-2"></i> My Profile</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#authModal" title="Login/Register">
                                <i class="fas fa-user-circle"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Auth Modal -->
    <div class="modal fade" id="authModal" tabindex="-1" aria-labelledby="authModalLabel" aria-hidden="true" <?php if(isset($_SESSION['keep_auth_modal_open']) && $_SESSION['keep_auth_modal_open']): ?>data-bs-backdrop="static" data-keep-open="true"<?php endif; ?>>
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0 pb-0">
                    <ul class="nav nav-tabs w-100" id="authTabs" role="tablist">
                        <li class="nav-item" role="presentation" style="width: 50%">
                            <button class="nav-link active w-100" id="login-tab" data-bs-toggle="tab" data-bs-target="#login-tab-pane" type="button" role="tab" aria-controls="login-tab-pane" aria-selected="true">Login</button>
                        </li>
                        <li class="nav-item" role="presentation" style="width: 50%">
                            <button class="nav-link w-100" id="register-tab" data-bs-toggle="tab" data-bs-target="#register-tab-pane" type="button" role="tab" aria-controls="register-tab-pane" aria-selected="false">Register</button>
                        </li>
                    </ul>
                    <button type="button" class="btn-close position-absolute" style="right: 15px; top: 15px;" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="tab-content" id="authTabsContent">
                        <!-- Login Tab -->
                        <div class="tab-pane fade show active" id="login-tab-pane" role="tabpanel" aria-labelledby="login-tab" tabindex="0">
                            <?php if (isset($_SESSION['auth_action_message'])): ?>
                            <div class="alert alert-info">
                                <p class="mb-0"><i class="fas fa-info-circle me-2"></i> <?php echo $_SESSION['auth_action_message']; ?></p>
                            </div>
                            <?php
                            // Clear the message but keep the modal open
                            unset($_SESSION['auth_action_message']);
                            ?>
                            <?php endif; ?>
                            
                            <?php if (isset($_SESSION['blocked_account']) && $_SESSION['blocked_account']): ?>
                            <div class="alert alert-danger">
                                <p class="mb-2"><i class="fas fa-exclamation-circle me-2" style="font-size: 1.4rem;"></i> Your account has been blocked by our support team.</p>
                                <p class="mb-0 small">Please <a href="#" class="alert-link contact-support-link" data-email="<?php echo isset($_SESSION['blocked_email']) ? htmlspecialchars($_SESSION['blocked_email']) : ''; ?>">contact support</a> to appeal this decision.</p>
                            </div>
                            <?php
                            // Clear the blocked account session variables but keep the modal open
                            $blocked_email = isset($_SESSION['blocked_email']) ? $_SESSION['blocked_email'] : '';
                            unset($_SESSION['blocked_account']);
                            unset($_SESSION['blocked_email']);
                            // Keep keep_auth_modal_open set so the modal stays open
                            ?>
                            <?php endif; ?>
                            <form action="actions/login_action.php" method="post">
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                        <input type="email" class="form-control" id="email" name="email" required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                        <input type="password" class="form-control" id="password" name="password" required>
                                    </div>
                                </div>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="remember" name="remember">
                                    <label class="form-check-label" for="remember">Remember me</label>
                                </div>
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">Login</button>
                                </div>
                            </form>
                        </div>
                        
                        <!-- Register Tab -->
                        <div class="tab-pane fade" id="register-tab-pane" role="tabpanel" aria-labelledby="register-tab" tabindex="0">
                            <form action="actions/register_action.php" method="post">
                                <div class="mb-3">
                                    <label for="reg-name" class="form-label">Name</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                                        <input type="text" class="form-control" id="reg-name" name="name" required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="reg-email" class="form-label">Email</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                        <input type="email" class="form-control" id="reg-email" name="email" required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="reg-password" class="form-label">Password</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                        <input type="password" class="form-control" id="reg-password" name="password" required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="reg-confirm-password" class="form-label">Confirm Password</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                        <input type="password" class="form-control" id="reg-confirm-password" name="confirm_password" required>
                                    </div>
                                </div>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="terms" name="terms" required>
                                    <label class="form-check-label" for="terms">I agree to the Terms of Service</label>
                                </div>
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">Register</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Toast Container for Notifications -->
    <div class="toast-container position-fixed bottom-0 end-0 p-3">
        <!-- Toasts will be added here dynamically -->
    </div>

    <!-- Main Content -->
    <main class="container py-4">
        <!-- Flash Messages -->
        <?php 
        // Only display messages if they're not notification-related
        if (isset($_SESSION['message']) && strpos($_SESSION['message'], 'Notification') !== 0) {
            echo displayMessage();
        } else {
            // Clear notification messages without displaying them
            if (isset($_SESSION['message'])) {
                unset($_SESSION['message']);
                unset($_SESSION['message_type']);
            }
        }
        ?>
