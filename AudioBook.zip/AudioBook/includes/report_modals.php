<?php
/**
 * Report modals for the moderator and admin dashboards
 */
?>
<!-- Report Modals -->
<?php foreach ($pendingReports ?? [] as $report): ?>
<div class="modal fade" id="reportModal<?php echo $report['id']; ?>" tabindex="-1" aria-labelledby="reportModalLabel<?php echo $report['id']; ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="reportModalLabel<?php echo $report['id']; ?>">
                    Report #<?php echo $report['id']; ?> - 
                    <?php if ($report['report_type'] === 'book'): ?>Book Report
                    <?php elseif ($report['report_type'] === 'user'): ?>User Report
                    <?php elseif ($report['report_type'] === 'review'): ?>Review Report
                    <?php endif; ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="fw-bold">Report Information</h6>
                        <p><strong>Reported by:</strong> <?php echo htmlspecialchars($report['reporter_name']); ?> (<?php echo htmlspecialchars($report['reporter_email']); ?>)</p>
                        <p><strong>Date Reported:</strong> <?php echo date('F d, Y h:i A', strtotime($report['created_at'])); ?></p>
                        <p><strong>Status:</strong> 
                            <?php if ($report['status'] === 'pending'): ?>
                                <span class="badge bg-secondary">Pending</span>
                            <?php elseif ($report['status'] === 'in_progress'): ?>
                                <span class="badge bg-primary">In Progress</span>
                            <?php endif; ?>
                        </p>
                        <p><strong>Reason:</strong> <?php echo htmlspecialchars($report['reason']); ?></p>
                        <?php if (!empty($report['details'])): ?>
                            <p><strong>Additional Details:</strong> <?php echo nl2br(htmlspecialchars($report['details'])); ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-6">
                        <h6 class="fw-bold">Reported Item Details</h6>
                        <?php if ($report['report_type'] === 'book'): ?>
                            <p><strong>Book Title:</strong> <?php echo htmlspecialchars($report['target_name']); ?></p>
                            <p><strong>Details:</strong> <?php echo htmlspecialchars($report['target_details']); ?></p>
                            <?php if (isset($report['target_link'])): ?>
                                <p><a href="<?php echo $report['target_link']; ?>" class="btn btn-sm btn-outline-primary" target="_blank"><i class="fas fa-book"></i> View Book</a></p>
                            <?php endif; ?>
                            
                        <?php elseif ($report['report_type'] === 'user'): ?>
                            <p><strong>User:</strong> <?php echo htmlspecialchars($report['target_name']); ?></p>
                            <p><strong>Details:</strong> <?php echo htmlspecialchars($report['target_details']); ?></p>
                            
                        <?php elseif ($report['report_type'] === 'review'): ?>
                            <p><strong>Review:</strong> <?php echo htmlspecialchars($report['target_name']); ?></p>
                            <p><strong>Details:</strong> <?php echo htmlspecialchars($report['target_details']); ?></p>
                            <?php if (isset($report['review_content'])): ?>
                                <div class="card mb-3">
                                    <div class="card-header bg-light">Review Content</div>
                                    <div class="card-body">
                                        <p class="mb-0"><?php echo nl2br(htmlspecialchars($report['review_content'])); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if (isset($report['target_link'])): ?>
                                <p><a href="<?php echo $report['target_link']; ?>" class="btn btn-sm btn-outline-primary" target="_blank"><i class="fas fa-book"></i> View Book</a></p>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <hr>
                
                <form action="actions/process_report.php" method="post">
                    <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                    
                    <div class="mb-3">
                        <label for="resolution_note<?php echo $report['id']; ?>" class="form-label">Resolution Note</label>
                        <textarea class="form-control" id="resolution_note<?php echo $report['id']; ?>" name="resolution_note" rows="3" placeholder="Add your notes about this report here..."></textarea>
                    </div>
                    
                    <div class="d-flex justify-content-end gap-2">
                        <?php if ($report['status'] === 'pending'): ?>
                            <button type="submit" name="action" value="in_progress" class="btn btn-outline-primary">
                                <i class="fas fa-hourglass-half"></i> Mark as In Progress
                            </button>
                        <?php endif; ?>
                        <button type="submit" name="action" value="dismiss" class="btn btn-outline-secondary">
                            <i class="fas fa-times"></i> Dismiss Report
                        </button>
                        <button type="submit" name="action" value="resolve" class="btn btn-success">
                            <i class="fas fa-check"></i> Resolve Report
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>
