<?php
/**
 * Report statistics component for admin dashboard
 * Shows statistics about reports in the system
 */

// Get report statistics
$reportStats = [];

// Total reports
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM reports");
$stmt->execute();
$reportStats['total'] = $stmt->fetchColumn();

// Reports by type
$stmt = $conn->prepare("SELECT report_type, COUNT(*) as count FROM reports GROUP BY report_type");
$stmt->execute();
$reportsByType = $stmt->fetchAll(PDO::FETCH_ASSOC);

$reportStats['by_type'] = [];
foreach ($reportsByType as $type) {
    $reportStats['by_type'][$type['report_type']] = $type['count'];
}

// Reports by status
$stmt = $conn->prepare("SELECT status, COUNT(*) as count FROM reports GROUP BY status");
$stmt->execute();
$reportsByStatus = $stmt->fetchAll(PDO::FETCH_ASSOC);

$reportStats['by_status'] = [];
foreach ($reportsByStatus as $status) {
    $reportStats['by_status'][$status['status']] = $status['count'];
}

// Most reported items
$stmt = $conn->prepare("
    SELECT report_type, target_id, COUNT(*) as report_count 
    FROM reports 
    GROUP BY report_type, target_id 
    ORDER BY report_count DESC 
    LIMIT 5
");
$stmt->execute();
$mostReportedItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get details for most reported items
foreach ($mostReportedItems as &$item) {
    switch ($item['report_type']) {
        case 'book':
            $bookStmt = $conn->prepare("SELECT title, author FROM books WHERE id = :id");
            $bookStmt->bindParam(':id', $item['target_id'], PDO::PARAM_INT);
            $bookStmt->execute();
            $book = $bookStmt->fetch(PDO::FETCH_ASSOC);
            if ($book) {
                $item['name'] = $book['title'];
                $item['details'] = "by " . $book['author'];
                $item['link'] = "index.php?page=book&id=" . $item['target_id'];
            }
            break;
            
        case 'user':
            $userStmt = $conn->prepare("SELECT name, role FROM users WHERE id = :id");
            $userStmt->bindParam(':id', $item['target_id'], PDO::PARAM_INT);
            $userStmt->execute();
            $user = $userStmt->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                $item['name'] = $user['name'];
                $item['details'] = ucfirst($user['role']);
                $item['link'] = "index.php?page=user&id=" . $item['target_id'];
            }
            break;
            
        case 'review':
            $reviewStmt = $conn->prepare("
                SELECT f.id, f.book_id, b.title as book_title, u.name as reviewer_name, u.id as reviewer_id
                FROM feedback f
                JOIN books b ON f.book_id = b.id
                JOIN users u ON f.user_id = u.id
                WHERE f.id = :id
            ");
            $reviewStmt->bindParam(':id', $item['target_id'], PDO::PARAM_INT);
            $reviewStmt->execute();
            $review = $reviewStmt->fetch(PDO::FETCH_ASSOC);
            if ($review) {
                $item['name'] = "Review by " . $review['reviewer_name'];
                $item['details'] = "on " . $review['book_title'];
                $item['link'] = "index.php?page=book&id=" . $review['book_id'];
            }
            break;
    }
}
?>

<div class="card bg-light mb-4">
    <div class="card-body">
        <h6 class="card-title">Report Statistics</h6>
        
        <div class="row mb-3">
            <div class="col-md-4">
                <div class="card bg-white">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h3 class="mb-0"><?php echo $reportStats['total']; ?></h3>
                                <small class="text-muted">Total Reports</small>
                            </div>
                            <div class="text-primary">
                                <i class="fas fa-flag fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card bg-white">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h3 class="mb-0"><?php echo $reportStats['by_status']['pending'] ?? 0; ?></h3>
                                <small class="text-muted">Pending Reports</small>
                            </div>
                            <div class="text-warning">
                                <i class="fas fa-clock fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card bg-white">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h3 class="mb-0"><?php echo $reportStats['by_status']['resolved'] ?? 0; ?></h3>
                                <small class="text-muted">Resolved Reports</small>
                            </div>
                            <div class="text-success">
                                <i class="fas fa-check-circle fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <h6 class="mb-2">Reports by Type</h6>
                <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span>Books</span>
                        <span class="badge bg-primary"><?php echo $reportStats['by_type']['book'] ?? 0; ?></span>
                    </div>
                    <div class="progress" style="height: 5px;">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo ($reportStats['total'] > 0) ? (($reportStats['by_type']['book'] ?? 0) / $reportStats['total'] * 100) : 0; ?>%" aria-valuenow="<?php echo $reportStats['by_type']['book'] ?? 0; ?>" aria-valuemin="0" aria-valuemax="<?php echo $reportStats['total']; ?>"></div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span>Users</span>
                        <span class="badge bg-warning"><?php echo $reportStats['by_type']['user'] ?? 0; ?></span>
                    </div>
                    <div class="progress" style="height: 5px;">
                        <div class="progress-bar bg-warning" role="progressbar" style="width: <?php echo ($reportStats['total'] > 0) ? (($reportStats['by_type']['user'] ?? 0) / $reportStats['total'] * 100) : 0; ?>%" aria-valuenow="<?php echo $reportStats['by_type']['user'] ?? 0; ?>" aria-valuemin="0" aria-valuemax="<?php echo $reportStats['total']; ?>"></div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span>Reviews</span>
                        <span class="badge bg-info"><?php echo $reportStats['by_type']['review'] ?? 0; ?></span>
                    </div>
                    <div class="progress" style="height: 5px;">
                        <div class="progress-bar bg-info" role="progressbar" style="width: <?php echo ($reportStats['total'] > 0) ? (($reportStats['by_type']['review'] ?? 0) / $reportStats['total'] * 100) : 0; ?>%" aria-valuenow="<?php echo $reportStats['by_type']['review'] ?? 0; ?>" aria-valuemin="0" aria-valuemax="<?php echo $reportStats['total']; ?>"></div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <h6 class="mb-2">Most Reported Items</h6>
                <?php if (count($mostReportedItems) > 0): ?>
                    <ul class="list-group list-group-flush small">
                        <?php foreach ($mostReportedItems as $item): ?>
                            <?php if (isset($item['name'])): ?>
                            <li class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center">
                                <div>
                                    <?php if ($item['report_type'] === 'book'): ?>
                                        <i class="fas fa-book text-primary me-1"></i>
                                    <?php elseif ($item['report_type'] === 'user'): ?>
                                        <i class="fas fa-user text-warning me-1"></i>
                                    <?php elseif ($item['report_type'] === 'review'): ?>
                                        <i class="fas fa-comment text-info me-1"></i>
                                    <?php endif; ?>
                                    
                                    <a href="<?php echo $item['link']; ?>" class="text-decoration-none">
                                        <?php echo htmlspecialchars($item['name']); ?>
                                    </a>
                                    <small class="text-muted d-block"><?php echo htmlspecialchars($item['details']); ?></small>
                                </div>
                                <span class="badge bg-danger rounded-pill"><?php echo $item['report_count']; ?></span>
                            </li>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="text-muted small">No reported items yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
