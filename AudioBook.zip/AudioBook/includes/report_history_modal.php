<?php
/**
 * Report history modal for admins and moderators
 */

// Only proceed if user is admin or moderator
if (!isLoggedIn() || (!isAdmin() && !isModerator())) {
    return;
}

// Get filter parameters
$status = isset($_GET['report_status']) ? sanitize($_GET['report_status']) : '';
$type = isset($_GET['report_type']) ? sanitize($_GET['report_type']) : '';
$dateRange = isset($_GET['report_date_range']) ? sanitize($_GET['report_date_range']) : '';

// Build query
$sql = "SELECT r.*, 
              u1.name as reporter_name, u1.email as reporter_email, 
              u2.name as resolver_name, u2.email as resolver_email 
       FROM reports r 
       JOIN users u1 ON r.reporter_id = u1.id 
       LEFT JOIN users u2 ON r.resolved_by = u2.id 
       WHERE 1=1";
$params = [];

// Add status filter
if (!empty($status)) {
    $sql .= " AND r.status = :status";
    $params[':status'] = $status;
} else {
    // Default to showing resolved and dismissed reports
    $sql .= " AND r.status IN ('resolved', 'dismissed')";
}

// Add type filter
if (!empty($type)) {
    $sql .= " AND r.report_type = :type";
    $params[':type'] = $type;
}

// Add date range filter
if (!empty($dateRange)) {
    switch ($dateRange) {
        case 'today':
            $sql .= " AND DATE(r.updated_at) = CURDATE()";
            break;
        case 'week':
            $sql .= " AND r.updated_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
            break;
        case 'month':
            $sql .= " AND r.updated_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
            break;
    }
}

// Order by updated date, newest first
$sql .= " ORDER BY r.updated_at DESC LIMIT 50"; // Limit to 50 for performance

// Execute query
$stmt = $conn->prepare($sql);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$historyReports = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get additional information for each report
foreach ($historyReports as &$report) {
    switch ($report['report_type']) {
        case 'book':
            $book = getBookById($report['target_id']);
            if ($book) {
                $report['target_name'] = $book['title'];
                $report['target_details'] = "Author: {$book['author']}";
                $report['target_link'] = "index.php?page=book&id={$report['target_id']}";
            }
            break;
            
        case 'user':
            $user = getUserById($report['target_id']);
            if ($user) {
                $report['target_name'] = $user['name'];
                $report['target_details'] = "Role: " . ucfirst($user['role']);
                $report['target_link'] = "index.php?page=user&id={$report['target_id']}";
            }
            break;
            
        case 'review':
            // Get review details
            $stmt = $conn->prepare("SELECT f.*, b.title as book_title, b.id as book_id, u.name as reviewer_name 
                                  FROM feedback f 
                                  JOIN books b ON f.book_id = b.id 
                                  JOIN users u ON f.user_id = u.id 
                                  WHERE f.id = :review_id");
            $stmt->bindParam(':review_id', $report['target_id'], PDO::PARAM_INT);
            $stmt->execute();
            $review = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($review) {
                $report['target_name'] = "Review by {$review['reviewer_name']}";
                $report['target_details'] = "Book: {$review['book_title']}";
                $report['target_link'] = "index.php?page=book&id={$review['book_id']}";
                $report['review_content'] = $review['comment'];
            }
            break;
    }
}
?>

<!-- Report History Modal -->
<div class="modal fade" id="reportHistoryModal" tabindex="-1" aria-labelledby="reportHistoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="reportHistoryModalLabel">
                    <i class="fas fa-history me-2" style="font-size: 1.4rem;"></i>
                    Report History
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Filters -->
                <div class="card mb-3">
                    <div class="card-body p-3">
                        <form id="reportHistoryFilterForm" class="row g-3 align-items-end">
                            <div class="col-md-3">
                                <label for="report_status" class="form-label">Status</label>
                                <select class="form-select" id="report_status" name="report_status">
                                    <option value="">All Statuses</option>
                                    <option value="resolved" <?php echo $status === 'resolved' ? 'selected' : ''; ?>>Resolved</option>
                                    <option value="dismissed" <?php echo $status === 'dismissed' ? 'selected' : ''; ?>>Dismissed</option>
                                    <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="in_progress" <?php echo $status === 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                </select>
                            </div>
                            
                            <div class="col-md-3">
                                <label for="report_type" class="form-label">Type</label>
                                <select class="form-select" id="report_type" name="report_type">
                                    <option value="">All Types</option>
                                    <option value="book" <?php echo $type === 'book' ? 'selected' : ''; ?>>Books</option>
                                    <option value="user" <?php echo $type === 'user' ? 'selected' : ''; ?>>Users</option>
                                    <option value="review" <?php echo $type === 'review' ? 'selected' : ''; ?>>Reviews</option>
                                </select>
                            </div>
                            
                            <div class="col-md-3">
                                <label for="report_date_range" class="form-label">Date Range</label>
                                <select class="form-select" id="report_date_range" name="report_date_range">
                                    <option value="">All Time</option>
                                    <option value="today" <?php echo $dateRange === 'today' ? 'selected' : ''; ?>>Today</option>
                                    <option value="week" <?php echo $dateRange === 'week' ? 'selected' : ''; ?>>Last 7 Days</option>
                                    <option value="month" <?php echo $dateRange === 'month' ? 'selected' : ''; ?>>Last 30 Days</option>
                                </select>
                            </div>
                            
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-filter me-1"></i> Filter
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Reports Table -->
                <div id="reportHistoryTableContainer">
                    <?php if (count($historyReports) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Type</th>
                                        <th>Reported Item</th>
                                        <th>Reporter</th>
                                        <th>Status</th>
                                        <th>Resolved By</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($historyReports as $report): ?>
                                    <tr>
                                        <td>#<?php echo $report['id']; ?></td>
                                        <td>
                                            <?php if ($report['report_type'] === 'book'): ?>
                                                <span class="badge bg-primary">Book</span>
                                            <?php elseif ($report['report_type'] === 'user'): ?>
                                                <span class="badge bg-warning">User</span>
                                            <?php elseif ($report['report_type'] === 'review'): ?>
                                                <span class="badge bg-info">Review</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($report['target_name'] ?? 'Unknown'); ?>
                                            <?php if (isset($report['target_link'])): ?>
                                                <a href="<?php echo $report['target_link']; ?>" class="ms-1" target="_blank"><i class="fas fa-external-link-alt small"></i></a>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($report['reporter_name']); ?></td>
                                        <td>
                                            <?php if ($report['status'] === 'pending'): ?>
                                                <span class="badge bg-secondary">Pending</span>
                                            <?php elseif ($report['status'] === 'in_progress'): ?>
                                                <span class="badge bg-primary">In Progress</span>
                                            <?php elseif ($report['status'] === 'resolved'): ?>
                                                <span class="badge bg-success">Resolved</span>
                                            <?php elseif ($report['status'] === 'dismissed'): ?>
                                                <span class="badge bg-danger">Dismissed</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo $report['resolver_name'] ?? 'N/A'; ?></td>
                                        <td><?php echo date('M d, Y', strtotime($report['updated_at'])); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-outline-primary view-report-details" 
                                                data-report-id="<?php echo $report['id']; ?>"
                                                data-report-type="<?php echo $report['report_type']; ?>"
                                                data-target-name="<?php echo htmlspecialchars($report['target_name'] ?? 'Unknown'); ?>"
                                                data-target-details="<?php echo htmlspecialchars($report['target_details'] ?? ''); ?>"
                                                data-target-link="<?php echo $report['target_link'] ?? ''; ?>"
                                                data-reporter-name="<?php echo htmlspecialchars($report['reporter_name']); ?>"
                                                data-reporter-email="<?php echo htmlspecialchars($report['reporter_email']); ?>"
                                                data-created-at="<?php echo date('F d, Y h:i A', strtotime($report['created_at'])); ?>"
                                                data-status="<?php echo $report['status']; ?>"
                                                data-reason="<?php echo htmlspecialchars($report['reason']); ?>"
                                                data-details="<?php echo htmlspecialchars($report['details'] ?? ''); ?>"
                                                data-resolution-note="<?php echo htmlspecialchars($report['resolution_note'] ?? ''); ?>"
                                                data-resolver-name="<?php echo htmlspecialchars($report['resolver_name'] ?? 'N/A'); ?>"
                                                data-updated-at="<?php echo date('F d, Y h:i A', strtotime($report['updated_at'])); ?>"
                                                <?php if (isset($report['review_content'])): ?>
                                                data-review-content="<?php echo htmlspecialchars($report['review_content']); ?>"
                                                <?php endif; ?>
                                            >
                                                <i class="fas fa-eye"></i> View
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <p class="mb-0">No reports found matching your criteria.</p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Report Details Section (Hidden by default) -->
                <div id="reportDetailsSection" class="mt-4 border-top pt-4" style="display: none;">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0" id="reportDetailTitle">Report Details</h5>
                        <button type="button" class="btn btn-sm btn-outline-secondary" id="closeReportDetails">
                            <i class="fas fa-times"></i> Close Details
                        </button>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="fw-bold">Report Information</h6>
                            <p><strong>Reported by:</strong> <span id="reporterName"></span> (<span id="reporterEmail"></span>)</p>
                            <p><strong>Date Reported:</strong> <span id="reportDate"></span></p>
                            <p><strong>Status:</strong> <span id="reportStatus"></span></p>
                            <p><strong>Reason:</strong> <span id="reportReason"></span></p>
                            <div id="reportDetailsContainer" style="display: none;">
                                <p><strong>Additional Details:</strong> <span id="reportDetails"></span></p>
                            </div>
                            
                            <div id="resolutionNoteContainer" class="alert alert-info" style="display: none;">
                                <h6 class="fw-bold">Resolution Note:</h6>
                                <p class="mb-0" id="resolutionNote"></p>
                            </div>
                            
                            <div id="resolverInfoContainer" style="display: none;">
                                <p><strong>Resolved By:</strong> <span id="resolverName"></span></p>
                                <p><strong>Resolution Date:</strong> <span id="resolutionDate"></span></p>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <h6 class="fw-bold">Reported Item Details</h6>
                            <div id="bookReportDetails" style="display: none;">
                                <p><strong>Book Title:</strong> <span id="bookTitle"></span></p>
                                <p><strong>Details:</strong> <span id="bookDetails"></span></p>
                                <p id="bookLinkContainer" style="display: none;">
                                    <a href="#" id="bookLink" class="btn btn-sm btn-outline-primary" target="_blank">
                                        <i class="fas fa-book"></i> View Book
                                    </a>
                                </p>
                            </div>
                            
                            <div id="userReportDetails" style="display: none;">
                                <p><strong>User:</strong> <span id="userName"></span></p>
                                <p><strong>Details:</strong> <span id="userDetails"></span></p>
                                <p id="userLinkContainer" style="display: none;">
                                    <a href="#" id="userLink" class="btn btn-sm btn-outline-primary" target="_blank">
                                        <i class="fas fa-user"></i> View User
                                    </a>
                                </p>
                            </div>
                            
                            <div id="reviewReportDetails" style="display: none;">
                                <p><strong>Review:</strong> <span id="reviewTitle"></span></p>
                                <p><strong>Details:</strong> <span id="reviewDetails"></span></p>
                                <div id="reviewContentContainer" class="card mb-3" style="display: none;">
                                    <div class="card-header bg-light">Review Content</div>
                                    <div class="card-body">
                                        <p class="mb-0" id="reviewContent"></p>
                                    </div>
                                </div>
                                <p id="reviewLinkContainer" style="display: none;">
                                    <a href="#" id="reviewLink" class="btn btn-sm btn-outline-primary" target="_blank">
                                        <i class="fas fa-book"></i> View Book
                                    </a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle filter form submission
    const filterForm = document.getElementById('reportHistoryFilterForm');
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(filterForm);
            const params = new URLSearchParams();
            
            // Add form data to params
            for (const [key, value] of formData.entries()) {
                if (value) {
                    params.append(key, value);
                }
            }
            
            // Reload the modal with the new filters
            const modal = bootstrap.Modal.getInstance(document.getElementById('reportHistoryModal'));
            modal.hide();
            
            // Set the URL parameters for the next modal open
            const reportHistoryBtn = document.querySelector('[data-bs-target="#reportHistoryModal"]');
            if (reportHistoryBtn) {
                reportHistoryBtn.setAttribute('data-report-filters', params.toString());
                
                // Simulate click to reopen with new filters
                setTimeout(() => {
                    reportHistoryBtn.click();
                }, 500);
            }
        });
    }
    
    // Handle view report details buttons
    const viewButtons = document.querySelectorAll('.view-report-details');
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get report data from data attributes
            const reportId = this.getAttribute('data-report-id');
            const reportType = this.getAttribute('data-report-type');
            const targetName = this.getAttribute('data-target-name');
            const targetDetails = this.getAttribute('data-target-details');
            const targetLink = this.getAttribute('data-target-link');
            const reporterName = this.getAttribute('data-reporter-name');
            const reporterEmail = this.getAttribute('data-reporter-email');
            const createdAt = this.getAttribute('data-created-at');
            const status = this.getAttribute('data-status');
            const reason = this.getAttribute('data-reason');
            const details = this.getAttribute('data-details');
            const resolutionNote = this.getAttribute('data-resolution-note');
            const resolverName = this.getAttribute('data-resolver-name');
            const updatedAt = this.getAttribute('data-updated-at');
            const reviewContent = this.getAttribute('data-review-content');
            
            // Set report title
            document.getElementById('reportDetailTitle').textContent = 'Report #' + reportId + ' - ' + 
                (reportType === 'book' ? 'Book Report' : 
                 reportType === 'user' ? 'User Report' : 
                 reportType === 'review' ? 'Review Report' : 'Report');
            
            // Set reporter info
            document.getElementById('reporterName').textContent = reporterName;
            document.getElementById('reporterEmail').textContent = reporterEmail;
            document.getElementById('reportDate').textContent = createdAt;
            
            // Set status with appropriate badge
            let statusHtml = '';
            if (status === 'pending') {
                statusHtml = '<span class="badge bg-secondary">Pending</span>';
            } else if (status === 'in_progress') {
                statusHtml = '<span class="badge bg-primary">In Progress</span>';
            } else if (status === 'resolved') {
                statusHtml = '<span class="badge bg-success">Resolved</span>';
            } else if (status === 'dismissed') {
                statusHtml = '<span class="badge bg-danger">Dismissed</span>';
            }
            document.getElementById('reportStatus').innerHTML = statusHtml;
            
            // Set reason
            document.getElementById('reportReason').textContent = reason;
            
            // Set additional details if available
            if (details && details.trim() !== '') {
                document.getElementById('reportDetails').innerHTML = details.replace(/\n/g, '<br>');
                document.getElementById('reportDetailsContainer').style.display = 'block';
            } else {
                document.getElementById('reportDetailsContainer').style.display = 'none';
            }
            
            // Set resolution note if available
            if (resolutionNote && resolutionNote.trim() !== '') {
                document.getElementById('resolutionNote').innerHTML = resolutionNote.replace(/\n/g, '<br>');
                document.getElementById('resolutionNoteContainer').style.display = 'block';
            } else {
                document.getElementById('resolutionNoteContainer').style.display = 'none';
            }
            
            // Set resolver info if resolved or dismissed
            if (status === 'resolved' || status === 'dismissed') {
                document.getElementById('resolverName').textContent = resolverName;
                document.getElementById('resolutionDate').textContent = updatedAt;
                document.getElementById('resolverInfoContainer').style.display = 'block';
            } else {
                document.getElementById('resolverInfoContainer').style.display = 'none';
            }
            
            // Hide all report type specific details first
            document.getElementById('bookReportDetails').style.display = 'none';
            document.getElementById('userReportDetails').style.display = 'none';
            document.getElementById('reviewReportDetails').style.display = 'none';
            
            // Show appropriate report type details
            if (reportType === 'book') {
                document.getElementById('bookTitle').textContent = targetName;
                document.getElementById('bookDetails').textContent = targetDetails;
                
                if (targetLink && targetLink.trim() !== '') {
                    document.getElementById('bookLink').href = targetLink;
                    document.getElementById('bookLinkContainer').style.display = 'block';
                } else {
                    document.getElementById('bookLinkContainer').style.display = 'none';
                }
                
                document.getElementById('bookReportDetails').style.display = 'block';
            } 
            else if (reportType === 'user') {
                document.getElementById('userName').textContent = targetName;
                document.getElementById('userDetails').textContent = targetDetails;
                
                if (targetLink && targetLink.trim() !== '') {
                    document.getElementById('userLink').href = targetLink;
                    document.getElementById('userLinkContainer').style.display = 'block';
                } else {
                    document.getElementById('userLinkContainer').style.display = 'none';
                }
                
                document.getElementById('userReportDetails').style.display = 'block';
            } 
            else if (reportType === 'review') {
                document.getElementById('reviewTitle').textContent = targetName;
                document.getElementById('reviewDetails').textContent = targetDetails;
                
                if (reviewContent && reviewContent.trim() !== '') {
                    document.getElementById('reviewContent').innerHTML = reviewContent.replace(/\n/g, '<br>');
                    document.getElementById('reviewContentContainer').style.display = 'block';
                } else {
                    document.getElementById('reviewContentContainer').style.display = 'none';
                }
                
                if (targetLink && targetLink.trim() !== '') {
                    document.getElementById('reviewLink').href = targetLink;
                    document.getElementById('reviewLinkContainer').style.display = 'block';
                } else {
                    document.getElementById('reviewLinkContainer').style.display = 'none';
                }
                
                document.getElementById('reviewReportDetails').style.display = 'block';
            }
            
            // Show the details section
            document.getElementById('reportDetailsSection').style.display = 'block';
            
            // Scroll to the details section
            document.getElementById('reportDetailsSection').scrollIntoView({ behavior: 'smooth' });
        });
    });
    
    // Handle close details button
    const closeDetailsBtn = document.getElementById('closeReportDetails');
    if (closeDetailsBtn) {
        closeDetailsBtn.addEventListener('click', function() {
            document.getElementById('reportDetailsSection').style.display = 'none';
        });
    }
});
</script>
