<?php
require_once 'config/config.php';

echo "<h2>Adding 'reason' column to licenses table</h2>";

try {
    // Check if the column already exists
    $stmt = $conn->prepare("SHOW COLUMNS FROM licenses LIKE 'reason'");
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        echo "<p>The 'reason' column already exists in the licenses table.</p>";
    } else {
        // Add the reason column
        $conn->exec("ALTER TABLE licenses ADD COLUMN reason TEXT AFTER type");
        echo "<p>Successfully added 'reason' column to the licenses table.</p>";
    }
    
    echo "<p><a href='index.php'>Return to homepage</a></p>";
} catch (PDOException $e) {
    echo "<p>Error: " . $e->getMessage() . "</p>";
}
?>
