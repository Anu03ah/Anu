<?php
session_start();
require_once 'config/config.php';
require_once 'includes/functions.php';

// Clear all session variables
$_SESSION = array();

// Delete the session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Clear remember me cookie if it exists
if (isset($_COOKIE['remember_token'])) {
    setcookie('remember_token', '', time() - 3600, '/');
    setcookie('user_id', '', time() - 3600, '/');
}

// Destroy the session
session_destroy();

// Set message and redirect
setMessage('You have been successfully logged out', 'success');
header("Location: index.php");
exit();
?>
