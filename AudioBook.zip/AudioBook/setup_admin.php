<?php
require_once 'config/config.php';

echo "<h2>AudioBook Admin Setup</h2>";

try {
    // Check if users table exists
    $stmt = $conn->prepare("SHOW TABLES LIKE 'users'");
    $stmt->execute();
    $table_exists = $stmt->rowCount() > 0;
    
    if (!$table_exists) {
        echo "<p>Users table does not exist. Please run the database setup first.</p>";
        exit;
    }
    
    // Check if admin user exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = 'admin@audiobook.com' AND role = 'admin'");
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($admin) {
        echo "<p>Admin user already exists with email: admin@audiobook.com</p>";
        
        // Reset admin password to make sure it works
        $admin_password = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = :password WHERE email = 'admin@audiobook.com'");
        $stmt->bindParam(':password', $admin_password);
        $stmt->execute();
        
        echo "<p>Admin password has been reset to: admin123</p>";
    } else {
        // Create admin user
        $admin_password = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES ('Admin', 'admin@audiobook.com', :password, 'admin')");
        $stmt->bindParam(':password', $admin_password);
        $stmt->execute();
        
        echo "<p>New admin user created with:</p>";
        echo "<p>Email: admin@audiobook.com</p>";
        echo "<p>Password: admin123</p>";
    }
    
    echo "<p>You can now <a href='index.php?page=login'>login</a> with these credentials.</p>";
    
} catch (PDOException $e) {
    echo "<p>Error: " . $e->getMessage() . "</p>";
}
?>
