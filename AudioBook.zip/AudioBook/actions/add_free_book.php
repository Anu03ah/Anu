<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    // Set session variables to indicate we need to show the auth modal
    $_SESSION['keep_auth_modal_open'] = true;
    $_SESSION['auth_action_message'] = 'Please login or register to add books to your library';
    $_SESSION['redirect_after_login'] = 'index.php?page=book&id=' . (isset($_GET['id']) ? intval($_GET['id']) : 0);
    
    // Set a message to be displayed
    setMessage('Please login or register to add books to your library', 'info');
    
    // Redirect back to the book page with a parameter to trigger the modal
    $book_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    header('Location: ../index.php?page=book&id=' . $book_id . '&show_auth=1');
    exit();
}

// Get book ID from URL
$book_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Validate book_id
if ($book_id <= 0) {
    setMessage('Invalid book ID', 'error');
    header('Location: ../index.php');
    exit();
}

// Check if book exists
$book = getBookById($book_id);
if (!$book) {
    setMessage('Book not found', 'error');
    header('Location: ../index.php');
    exit();
}

// Verify that the book is free
if ($book['price'] > 0) {
    setMessage('This book is not free and requires purchase', 'error');
    header('Location: ../index.php?page=book&id=' . $book_id);
    exit();
}

// Check if user has already added this book to their library
if (hasPurchasedBook($_SESSION['user_id'], $book_id)) {
    setMessage('This book is already in your library', 'info');
    header('Location: ../index.php?page=book&id=' . $book_id);
    exit();
}

// Add free book to user's library
try {
    // Begin transaction
    $conn->beginTransaction();
    
    // Record "purchase" (it's free but we use the same table structure)
    $stmt = $conn->prepare("INSERT INTO purchases (user_id, book_id) VALUES (:user_id, :book_id)");
    $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    // Record transaction with zero amount
    $stmt = $conn->prepare("INSERT INTO transactions (user_id, book_id, amount, payment_status) VALUES (:user_id, :book_id, 0, 'completed')");
    $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    // Commit transaction
    $conn->commit();
    
    // Create notification for user with larger icon size
    createNotification($_SESSION['user_id'], 'library', '<i class="fas fa-book fa-lg me-2"></i> "' . $book['title'] . '" has been added to your library.');
    
    // Create notification for publisher with larger icon size
    createNotification($book['publisher_id'], 'download', '<i class="fas fa-download fa-lg me-2"></i> Your free book "' . $book['title'] . '" has been added to a user\'s library.');
    
    setMessage('<i class="fas fa-check-circle me-2" style="font-size: 1.4rem;"></i> "' . $book['title'] . '" has been added to your library!', 'success');
    header('Location: ../index.php?page=book&id=' . $book_id);
    exit();
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollBack();
    
    setMessage('An error occurred: ' . $e->getMessage(), 'error');
    header('Location: ../index.php?page=book&id=' . $book_id);
    exit();
}
?>
