<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    setMessage('Please login to download books', 'error');
    header('Location: ../index.php?page=login');
    exit();
}

// Get parameters
$book_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$type = isset($_GET['type']) ? sanitize($_GET['type']) : '';

// Validate book_id
if ($book_id <= 0) {
    setMessage('Invalid book ID', 'error');
    header('Location: ../index.php');
    exit();
}

// Validate type
if ($type !== 'pdf' && $type !== 'audio') {
    setMessage('Invalid download type', 'error');
    header('Location: ../index.php');
    exit();
}

// Get book details
$book = getBookById($book_id);
if (!$book) {
    setMessage('Book not found', 'error');
    header('Location: ../index.php');
    exit();
}

// Check if downloads are allowed
if (!$book['download_allowed']) {
    setMessage('Downloads are not allowed for this book', 'error');
    header('Location: ../index.php?page=book&id=' . $book_id);
    exit();
}

// Check if user has purchased this book
if (!hasPurchasedBook($_SESSION['user_id'], $book_id)) {
    setMessage('You must purchase this book before downloading', 'error');
    header('Location: ../index.php?page=book&id=' . $book_id);
    exit();
}

// Check if requested file exists
$file_path = '';
if ($type === 'pdf') {
    if (empty($book['pdf_path'])) {
        setMessage('This book does not have a PDF version', 'error');
        header('Location: ../index.php?page=book&id=' . $book_id);
        exit();
    }
    // Fix path resolution - use direct path without DOCUMENT_ROOT
    $file_path = '../' . $book['pdf_path'];
} else { // audio
    if (empty($book['audio_path'])) {
        setMessage('This book does not have an audio version', 'error');
        header('Location: ../index.php?page=book&id=' . $book_id);
        exit();
    }
    // Fix path resolution - use direct path without DOCUMENT_ROOT
    $file_path = '../' . $book['audio_path'];
}

// Check if file exists
if (!file_exists($file_path)) {
    setMessage('File not found', 'error');
    header('Location: ../index.php?page=book&id=' . $book_id);
    exit();
}

// Get file information
$file_info = pathinfo($file_path);
$file_extension = isset($file_info['extension']) ? strtolower($file_info['extension']) : '';

// Create a clean filename (remove special characters)
$clean_title = preg_replace('/[^A-Za-z0-9\-]/', '_', $book['title']);
$file_name = $clean_title . '.' . $file_extension;

// Set the appropriate content type based on file extension
$content_type = 'application/octet-stream'; // Default
if ($type === 'pdf') {
    $content_type = 'application/pdf';
} elseif ($type === 'audio') {
    // Determine audio content type
    switch ($file_extension) {
        case 'mp3':
            $content_type = 'audio/mpeg';
            break;
        case 'wav':
            $content_type = 'audio/wav';
            break;
        case 'ogg':
            $content_type = 'audio/ogg';
            break;
        case 'm4a':
        case 'aac':
            $content_type = 'audio/aac';
            break;
    }
}

// Set appropriate headers for download
header('Content-Description: File Transfer');
header('Content-Type: ' . $content_type);
header('Content-Disposition: attachment; filename="' . $file_name . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($file_path));

// Make sure there's no output before headers
if (ob_get_level()) {
    ob_end_clean();
}

// Output file
readfile($file_path);
exit();
?>
