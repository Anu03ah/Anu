<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    setMessage('Please login to submit a review', 'error');
    header('Location: ../index.php?page=login');
    exit();
}

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    setMessage('Invalid request method', 'error');
    header('Location: ../index.php');
    exit();
}

// Get parameters
$book_id = isset($_POST['book_id']) ? intval($_POST['book_id']) : 0;
$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
$comment = isset($_POST['comment']) ? sanitize($_POST['comment']) : '';

// Validate book_id
if ($book_id <= 0) {
    setMessage('Invalid book ID', 'error');
    header('Location: ../index.php');
    exit();
}

// Validate rating
if ($rating < 1 || $rating > 5) {
    setMessage('Rating must be between 1 and 5', 'error');
    header('Location: ../index.php?page=book&id=' . $book_id);
    exit();
}

// Check if book exists
$book = getBookById($book_id);
if (!$book) {
    setMessage('Book not found', 'error');
    header('Location: ../index.php');
    exit();
}

// Check if user has purchased this book
if (!hasPurchasedBook($_SESSION['user_id'], $book_id)) {
    setMessage('You must purchase this book before submitting a review', 'error');
    header('Location: ../index.php?page=book&id=' . $book_id);
    exit();
}

// Check if user has already reviewed this book
$stmt = $conn->prepare("SELECT COUNT(*) FROM feedback WHERE user_id = :user_id AND book_id = :book_id");
$stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
$stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
$stmt->execute();

if ($stmt->fetchColumn() > 0) {
    // Update existing review
    $stmt = $conn->prepare("UPDATE feedback SET rating = :rating, comment = :comment, created_at = NOW() WHERE user_id = :user_id AND book_id = :book_id");
    $stmt->bindParam(':rating', $rating, PDO::PARAM_INT);
    $stmt->bindParam(':comment', $comment, PDO::PARAM_STR);
    $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        setMessage('Your review has been updated successfully', 'success');
    } else {
        setMessage('Failed to update your review', 'error');
    }
} else {
    // Insert new review
    $stmt = $conn->prepare("INSERT INTO feedback (user_id, book_id, rating, comment) VALUES (:user_id, :book_id, :rating, :comment)");
    $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->bindParam(':rating', $rating, PDO::PARAM_INT);
    $stmt->bindParam(':comment', $comment, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        // Create notification for publisher
        createNotification($book['publisher_id'], 'review', 'Your book "' . $book['title'] . '" has received a new review.');
        
        setMessage('Your review has been submitted successfully', 'success');
    } else {
        setMessage('Failed to submit your review', 'error');
    }
}

// Redirect back to book page
header('Location: ../index.php?page=book&id=' . $book_id);
exit();
?>
