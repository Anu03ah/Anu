<?php
/**
 * Handle account block appeal submissions
 */
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $email = sanitize($_POST['email']);
    $name = sanitize($_POST['name']);
    $reason = sanitize($_POST['reason']);
    $additional = isset($_POST['additional']) ? sanitize($_POST['additional']) : '';
    $appeal_type = sanitize($_POST['appeal_type']);
    
    // Validate input
    if (empty($email) || empty($name) || empty($reason)) {
        setMessage('Please fill in all required fields', 'error');
        header('Location: ../index.php?page=contact&appeal=block&email=' . urlencode($email));
        exit();
    }
    
    // Check if email exists in the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        setMessage('No account found with this email address', 'error');
        header('Location: ../index.php?page=contact&appeal=block&email=' . urlencode($email));
        exit();
    }
    
    // Create appeal record in the database
    $stmt = $conn->prepare("INSERT INTO appeals (user_id, type, reason, additional_info, status, created_at) 
                           VALUES (:user_id, :type, :reason, :additional_info, 'pending', NOW())");
    
    $stmt->bindParam(':user_id', $user['id'], PDO::PARAM_INT);
    $stmt->bindParam(':type', $appeal_type, PDO::PARAM_STR);
    $stmt->bindParam(':reason', $reason, PDO::PARAM_STR);
    $stmt->bindParam(':additional_info', $additional, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        // Determine which staff members should be notified based on the user's role
        if ($user['role'] === 'moderator') {
            // Moderator appeals should only notify admins
            $notification_message = "New account unblock appeal from moderator {$user['name']} ({$user['email']})";
            
            // Get all admins
            $stmt = $conn->prepare("SELECT id FROM users WHERE role = 'admin'");
            $stmt->execute();
            $admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Send notification to each admin
            foreach ($admins as $admin) {
                createNotification($admin['id'], 'moderator_appeal', $notification_message);
            }
        } else {
            // User and publisher appeals should only notify moderators
            $user_type = ucfirst($user['role']);
            $notification_message = "New account unblock appeal from {$user_type} {$user['name']} ({$user['email']})";
            
            // Get all moderators
            $stmt = $conn->prepare("SELECT id FROM users WHERE role = 'moderator'");
            $stmt->execute();
            $moderators = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Send notification to each moderator
            foreach ($moderators as $moderator) {
                createNotification($moderator['id'], 'user_appeal', $notification_message);
            }
        }
        
        setMessage('Your appeal has been submitted successfully. We will review it and get back to you soon.', 'success');
        header('Location: ../index.php');
    } else {
        setMessage('Failed to submit your appeal. Please try again later.', 'error');
        header('Location: ../index.php?page=contact&appeal=block&email=' . urlencode($email));
    }
    
    exit();
} else {
    // Redirect if accessed directly
    header('Location: ../index.php');
    exit();
}
?>
