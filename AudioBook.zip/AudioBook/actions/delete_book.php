<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if user is logged in
if (!isLoggedIn()) {
    setMessage('You must be logged in to perform this action', 'error');
    header('Location: ../index.php');
    exit();
}

// Check if user is admin or publisher
if (!isAdmin() && !isPublisher()) {
    setMessage('You do not have permission to delete books', 'error');
    header('Location: ../index.php');
    exit();
}

// Check if book ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    setMessage('Invalid book ID', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

$book_id = intval($_GET['id']);

// Get book details
$book = getBookById($book_id);

if (!$book) {
    setMessage('Book not found', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Check if user is the publisher of the book or an admin
if (!isAdmin() && $book['publisher_id'] != $_SESSION['user_id']) {
    setMessage('You do not have permission to delete this book', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

try {
    global $conn;
    
    // Begin transaction
    $conn->beginTransaction();
    
    // Delete related records first (purchases, reviews, bookmarks)
    $stmt = $conn->prepare("DELETE FROM purchases WHERE book_id = :book_id");
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    $stmt = $conn->prepare("DELETE FROM reviews WHERE book_id = :book_id");
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    $stmt = $conn->prepare("DELETE FROM bookmarks WHERE book_id = :book_id");
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    // Delete the book
    $stmt = $conn->prepare("DELETE FROM books WHERE id = :book_id");
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    // Commit transaction
    $conn->commit();
    
    // Delete the files
    if (!empty($book['pdf_path']) && file_exists('../' . $book['pdf_path'])) {
        unlink('../' . $book['pdf_path']);
    }
    
    if (!empty($book['audio_path']) && file_exists('../' . $book['audio_path'])) {
        unlink('../' . $book['audio_path']);
    }
    
    if (!empty($book['cover_path']) && file_exists('../' . $book['cover_path'])) {
        unlink('../' . $book['cover_path']);
    }
    
    setMessage('Book deleted successfully', 'success');
} catch (PDOException $e) {
    // Rollback transaction on error
    $conn->rollBack();
    error_log("Error deleting book: " . $e->getMessage());
    setMessage('Failed to delete book: ' . $e->getMessage(), 'error');
}

// Redirect based on user role
if (isAdmin()) {
    header('Location: ../index.php?page=dashboard&section=admin');
} else {
    header('Location: ../index.php?page=dashboard');
}
exit();
?>
