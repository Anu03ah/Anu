<?php
/**
 * Search users action for moderator dashboard
 */
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and is a moderator
if (!isLoggedIn() || !isModerator()) {
    $_SESSION['message'] = "You don't have permission to access this page";
    $_SESSION['message_type'] = "error";
    header("Location: ../index.php?page=login");
    exit();
}

// Get search parameters
$search = isset($_GET['query']) ? sanitize($_GET['query']) : null;
$role = isset($_GET['role']) ? sanitize($_GET['role']) : null;
$status = isset($_GET['status']) ? sanitize($_GET['status']) : null;

// Get users based on search criteria
$users = getUsersForModeration($search, $role, $status);

// Store results in session for display
$_SESSION['user_search_results'] = $users;
$_SESSION['user_search_query'] = $search;
$_SESSION['user_search_role'] = $role;
$_SESSION['user_search_status'] = $status;

// Redirect back to moderator dashboard
header("Location: ../index.php?page=dashboard#user-management");
exit();
?>
