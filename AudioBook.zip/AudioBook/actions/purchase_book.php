<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    setMessage('Please login to purchase books', 'error');
    header('Location: ../index.php?page=login');
    exit();
}

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    setMessage('Invalid request method', 'error');
    header('Location: ../index.php');
    exit();
}

// Get parameters
$book_id = isset($_POST['book_id']) ? intval($_POST['book_id']) : 0;
$payment_method = isset($_POST['payment_method']) ? sanitize($_POST['payment_method']) : '';

// Validate book_id
if ($book_id <= 0) {
    setMessage('Invalid book ID', 'error');
    header('Location: ../index.php');
    exit();
}

// Validate payment method
if (empty($payment_method)) {
    setMessage('Please select a payment method', 'error');
    header('Location: ../index.php?page=book&id=' . $book_id);
    exit();
}

// Check if book exists
$book = getBookById($book_id);
if (!$book) {
    setMessage('Book not found', 'error');
    header('Location: ../index.php');
    exit();
}

// Check if user has already purchased this book
if (hasPurchasedBook($_SESSION['user_id'], $book_id)) {
    setMessage('You have already purchased this book', 'info');
    header('Location: ../index.php?page=book&id=' . $book_id);
    exit();
}

// Process payment (simulated)
try {
    // Begin transaction
    $conn->beginTransaction();
    
    // Record purchase
    $stmt = $conn->prepare("INSERT INTO purchases (user_id, book_id) VALUES (:user_id, :book_id)");
    $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    // Record transaction
    $stmt = $conn->prepare("INSERT INTO transactions (user_id, book_id, amount, payment_status) VALUES (:user_id, :book_id, :amount, 'completed')");
    $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->bindParam(':amount', $book['price'], PDO::PARAM_STR);
    $stmt->execute();
    
    // Commit transaction
    $conn->commit();
    
    // Create notification for user
    createNotification($_SESSION['user_id'], 'purchase', 'You have successfully purchased "' . $book['title'] . '".');
    
    // Create notification for publisher
    createNotification($book['publisher_id'], 'sale', 'Your book "' . $book['title'] . '" has been purchased by a user.');
    
    setMessage('Book purchased successfully! You can now access the full content.', 'success');
    header('Location: ../index.php?page=book&id=' . $book_id);
    exit();
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollBack();
    
    setMessage('An error occurred during purchase: ' . $e->getMessage(), 'error');
    header('Location: ../index.php?page=book&id=' . $book_id);
    exit();
}
?>
