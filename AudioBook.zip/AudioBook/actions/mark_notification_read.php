<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get notification ID
$notification_id = isset($_POST['notification_id']) ? intval($_POST['notification_id']) : 0;

// Validate notification ID
if ($notification_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid notification ID']);
    exit();
}

// Check if notification belongs to user
$stmt = $conn->prepare("SELECT COUNT(*) FROM notifications WHERE id = :id AND user_id = :user_id");
$stmt->bindParam(':id', $notification_id, PDO::PARAM_INT);
$stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
$stmt->execute();

if ($stmt->fetchColumn() == 0) {
    echo json_encode(['success' => false, 'message' => 'Notification not found or does not belong to user']);
    exit();
}

// Mark notification as read
$result = markNotificationAsRead($notification_id);

if ($result) {
    echo json_encode(['success' => true, 'message' => 'Notification marked as read']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to mark notification as read']);
}
?>
