<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if user is logged in
if (!isLoggedIn()) {
    setMessage('You must be logged in to perform this action', 'error');
    header('Location: ../index.php');
    exit();
}

// Check if user is admin or publisher
if (!isAdmin() && !isPublisher()) {
    setMessage('You do not have permission to update books', 'error');
    header('Location: ../index.php');
    exit();
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    setMessage('Invalid request method', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Get book ID
$book_id = isset($_POST['book_id']) ? intval($_POST['book_id']) : 0;

if ($book_id <= 0) {
    setMessage('Invalid book ID', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Get book details
try {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM books WHERE id = :id");
    $stmt->bindParam(':id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    $book = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$book) {
        setMessage('Book not found', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Check if user has permission to edit this book (admin or publisher of the book)
    if (!isAdmin() && $book['publisher_id'] != $_SESSION['user_id']) {
        setMessage('You do not have permission to edit this book', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Get form data
    $title = isset($_POST['title']) ? sanitize($_POST['title']) : '';
    $author = isset($_POST['author']) ? sanitize($_POST['author']) : '';
    $category = isset($_POST['category']) ? sanitize($_POST['category']) : '';
    $price = isset($_POST['price']) ? floatval($_POST['price']) : 0;
    $description = isset($_POST['description']) ? sanitize($_POST['description']) : '';
    $preview_enabled = isset($_POST['preview_enabled']) ? 1 : 0;
    $download_allowed = isset($_POST['download_allowed']) ? 1 : 0;
    $terms_signed = isset($_POST['terms_signed']) ? 1 : 0;
    
    // Validate required fields
    if (empty($title) || empty($author) || empty($category) || $price < 0 || empty($description)) {
        setMessage('Please fill in all required fields', 'error');
        header('Location: ../index.php?page=edit_book&id=' . $book_id);
        exit();
    }
    
    // If download is allowed, check if terms are signed
    if ($download_allowed && !$terms_signed) {
        // Set download_allowed to false if terms not signed
        $download_allowed = 0;
    }
    
    // Initialize file paths
    $pdf_path = $book['pdf_path'];
    $audio_path = $book['audio_path'];
    $cover_path = $book['cover_path'];
    
    // Create directories if they don't exist with proper error handling
    $upload_dirs = [UPLOAD_DIR, PDF_DIR, AUDIO_DIR, COVER_DIR];
    
    foreach ($upload_dirs as $dir) {
        if (!file_exists($dir)) {
            if (!mkdir($dir, 0777, true)) {
                error_log("Failed to create directory: " . $dir);
                setMessage('Failed to create upload directories. Please contact the administrator.', 'error');
                header('Location: ../index.php?page=edit_book&id=' . $book_id);
                exit();
            }
            // Ensure proper permissions
            chmod($dir, 0777);
        }
    }
    
    // Process cover image upload if provided
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] == 0) {
        $cover_file = $_FILES['cover'];
        $cover_name = time() . '_' . sanitize(basename($cover_file['name']));
        $cover_target = COVER_DIR . '/' . $cover_name;
        
        // Check file type
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($cover_file['type'], $allowed_types)) {
            setMessage('Invalid cover image format. Please upload a JPEG, PNG, GIF, or WEBP image.', 'error');
            header('Location: ../index.php?page=edit_book&id=' . $book_id);
            exit();
        }
        
        // Check file size (max 5MB)
        if ($cover_file['size'] > 5 * 1024 * 1024) {
            setMessage('Cover image is too large. Maximum size is 5MB.', 'error');
            header('Location: ../index.php?page=edit_book&id=' . $book_id);
            exit();
        }
        
        // Upload file with better error handling
        if (!move_uploaded_file($cover_file['tmp_name'], $cover_target)) {
            $error_message = 'Failed to upload cover image';
            
            // Get more detailed error information
            switch ($cover_file['error']) {
                case UPLOAD_ERR_INI_SIZE:
                    $error_message .= ' - File exceeds upload_max_filesize directive in php.ini';
                    break;
                case UPLOAD_ERR_FORM_SIZE:
                    $error_message .= ' - File exceeds MAX_FILE_SIZE directive in the HTML form';
                    break;
                case UPLOAD_ERR_PARTIAL:
                    $error_message .= ' - File was only partially uploaded';
                    break;
                case UPLOAD_ERR_NO_FILE:
                    $error_message .= ' - No file was uploaded';
                    break;
                case UPLOAD_ERR_NO_TMP_DIR:
                    $error_message .= ' - Missing a temporary folder';
                    break;
                case UPLOAD_ERR_CANT_WRITE:
                    $error_message .= ' - Failed to write file to disk';
                    break;
                case UPLOAD_ERR_EXTENSION:
                    $error_message .= ' - A PHP extension stopped the file upload';
                    break;
            }
            
            // Log the error for debugging
            error_log("Cover upload error: " . $error_message . " - Path: " . $cover_target);
            
            setMessage($error_message, 'error');
            header('Location: ../index.php?page=edit_book&id=' . $book_id);
            exit();
        }
        
        // Delete old cover file if it exists
        if (!empty($book['cover_path']) && file_exists('../' . $book['cover_path'])) {
            unlink('../' . $book['cover_path']);
        }
        
        $cover_path = 'uploads/covers/' . $cover_name;
    }
    
    // Process PDF upload if provided
    if (isset($_FILES['pdf_file']) && $_FILES['pdf_file']['error'] == 0) {
        $pdf_file = $_FILES['pdf_file'];
        $pdf_name = time() . '_' . sanitize(basename($pdf_file['name']));
        $pdf_target = PDF_DIR . '/' . $pdf_name;
        
        // Check file type
        if ($pdf_file['type'] != 'application/pdf') {
            setMessage('Invalid PDF file format. Please upload a PDF file.', 'error');
            header('Location: ../index.php?page=edit_book&id=' . $book_id);
            exit();
        }
        
        // Check file size (max 50MB)
        if ($pdf_file['size'] > 50 * 1024 * 1024) {
            setMessage('PDF file is too large. Maximum size is 50MB.', 'error');
            header('Location: ../index.php?page=edit_book&id=' . $book_id);
            exit();
        }
        
        // Upload file with better error handling
        if (!move_uploaded_file($pdf_file['tmp_name'], $pdf_target)) {
            $error_message = 'Failed to upload PDF file';
            
            // Get more detailed error information
            switch ($pdf_file['error']) {
                case UPLOAD_ERR_INI_SIZE:
                    $error_message .= ' - File exceeds upload_max_filesize directive in php.ini';
                    break;
                case UPLOAD_ERR_FORM_SIZE:
                    $error_message .= ' - File exceeds MAX_FILE_SIZE directive in the HTML form';
                    break;
                case UPLOAD_ERR_PARTIAL:
                    $error_message .= ' - File was only partially uploaded';
                    break;
                case UPLOAD_ERR_NO_FILE:
                    $error_message .= ' - No file was uploaded';
                    break;
                case UPLOAD_ERR_NO_TMP_DIR:
                    $error_message .= ' - Missing a temporary folder';
                    break;
                case UPLOAD_ERR_CANT_WRITE:
                    $error_message .= ' - Failed to write file to disk';
                    break;
                case UPLOAD_ERR_EXTENSION:
                    $error_message .= ' - A PHP extension stopped the file upload';
                    break;
            }
            
            // Log the error for debugging
            error_log("PDF upload error: " . $error_message . " - Path: " . $pdf_target);
            
            setMessage($error_message, 'error');
            header('Location: ../index.php?page=edit_book&id=' . $book_id);
            exit();
        }
        
        // Delete old PDF file if it exists
        if (!empty($book['pdf_path']) && file_exists('../' . $book['pdf_path'])) {
            unlink('../' . $book['pdf_path']);
        }
        
        $pdf_path = 'uploads/pdf/' . $pdf_name;
    }
    
    // Process audio upload if provided
    if (isset($_FILES['audio_file']) && $_FILES['audio_file']['error'] == 0) {
        $audio_file = $_FILES['audio_file'];
        $audio_name = time() . '_' . sanitize(basename($audio_file['name']));
        $audio_target = AUDIO_DIR . '/' . $audio_name;
        
        // Check file type
        $allowed_audio_types = ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/x-wav'];
        if (!in_array($audio_file['type'], $allowed_audio_types)) {
            setMessage('Invalid audio file format. Please upload an MP3 or WAV file.', 'error');
            header('Location: ../index.php?page=edit_book&id=' . $book_id);
            exit();
        }
        
        // Check file size (max 100MB)
        if ($audio_file['size'] > 100 * 1024 * 1024) {
            setMessage('Audio file is too large. Maximum size is 100MB.', 'error');
            header('Location: ../index.php?page=edit_book&id=' . $book_id);
            exit();
        }
        
        // Upload file with better error handling
        if (!move_uploaded_file($audio_file['tmp_name'], $audio_target)) {
            $error_message = 'Failed to upload audio file';
            
            // Get more detailed error information
            switch ($audio_file['error']) {
                case UPLOAD_ERR_INI_SIZE:
                    $error_message .= ' - File exceeds upload_max_filesize directive in php.ini';
                    break;
                case UPLOAD_ERR_FORM_SIZE:
                    $error_message .= ' - File exceeds MAX_FILE_SIZE directive in the HTML form';
                    break;
                case UPLOAD_ERR_PARTIAL:
                    $error_message .= ' - File was only partially uploaded';
                    break;
                case UPLOAD_ERR_NO_FILE:
                    $error_message .= ' - No file was uploaded';
                    break;
                case UPLOAD_ERR_NO_TMP_DIR:
                    $error_message .= ' - Missing a temporary folder';
                    break;
                case UPLOAD_ERR_CANT_WRITE:
                    $error_message .= ' - Failed to write file to disk';
                    break;
                case UPLOAD_ERR_EXTENSION:
                    $error_message .= ' - A PHP extension stopped the file upload';
                    break;
            }
            
            // Log the error for debugging
            error_log("Audio upload error: " . $error_message . " - Path: " . $audio_target);
            
            setMessage($error_message, 'error');
            header('Location: ../index.php?page=edit_book&id=' . $book_id);
            exit();
        }
        
        // Delete old audio file if it exists
        if (!empty($book['audio_path']) && file_exists('../' . $book['audio_path'])) {
            unlink('../' . $book['audio_path']);
        }
        
        $audio_path = 'uploads/audio/' . $audio_name;
    }
    
    // Update book in database
    $stmt = $conn->prepare("UPDATE books SET 
                           title = :title, 
                           author = :author, 
                           description = :description, 
                           category = :category, 
                           cover_path = :cover_path, 
                           pdf_path = :pdf_path, 
                           audio_path = :audio_path, 
                           price = :price, 
                           download_allowed = :download_allowed, 
                           preview_enabled = :preview_enabled, 
                           terms_signed = :terms_signed
                           WHERE id = :id");
    
    $stmt->bindParam(':title', $title, PDO::PARAM_STR);
    $stmt->bindParam(':author', $author, PDO::PARAM_STR);
    $stmt->bindParam(':description', $description, PDO::PARAM_STR);
    $stmt->bindParam(':category', $category, PDO::PARAM_STR);
    $stmt->bindParam(':cover_path', $cover_path, PDO::PARAM_STR);
    $stmt->bindParam(':pdf_path', $pdf_path, PDO::PARAM_STR);
    $stmt->bindParam(':audio_path', $audio_path, PDO::PARAM_STR);
    $stmt->bindParam(':price', $price, PDO::PARAM_STR);
    $stmt->bindParam(':download_allowed', $download_allowed, PDO::PARAM_INT);
    $stmt->bindParam(':preview_enabled', $preview_enabled, PDO::PARAM_INT);
    $stmt->bindParam(':terms_signed', $terms_signed, PDO::PARAM_INT);
    $stmt->bindParam(':id', $book_id, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        setMessage('Book updated successfully', 'success');
    } else {
        setMessage('Failed to update book', 'error');
    }
    
} catch (PDOException $e) {
    error_log("Error updating book: " . $e->getMessage());
    setMessage('Database error: ' . $e->getMessage(), 'error');
}

// Redirect based on user role
if (isAdmin()) {
    header('Location: ../index.php?page=dashboard&section=admin#book-management');
} else {
    header('Location: ../index.php?page=dashboard#my-books');
}
exit();
?>
