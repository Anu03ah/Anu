<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    setMessage('Please login to apply for a license', 'error');
    header('Location: ../index.php?page=login');
    exit();
}

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    setMessage('Invalid request method', 'error');
    header('Location: ../index.php');
    exit();
}

// Get parameters
$license_type = isset($_POST['license_type']) ? sanitize($_POST['license_type']) : '';
$reason = isset($_POST['reason']) ? sanitize($_POST['reason']) : '';

// Validate license type
if ($license_type !== 'publisher' && $license_type !== 'moderator') {
    setMessage('Invalid license type', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Check if user already has this license
if (($license_type === 'publisher' && isPublisher()) || ($license_type === 'moderator' && isModerator())) {
    setMessage('You already have this license', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Check if user already has a pending application for this license type
$stmt = $conn->prepare("SELECT COUNT(*) FROM licenses WHERE user_id = :user_id AND type = :type AND status = 'pending'");
$stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
$stmt->bindParam(':type', $license_type, PDO::PARAM_STR);
$stmt->execute();

if ($stmt->fetchColumn() > 0) {
    setMessage('You already have a pending application for this license type', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Insert license application
$stmt = $conn->prepare("INSERT INTO licenses (user_id, type, reason, status) VALUES (:user_id, :type, :reason, 'pending')");
$stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
$stmt->bindParam(':type', $license_type, PDO::PARAM_STR);
$stmt->bindParam(':reason', $reason, PDO::PARAM_STR);

if ($stmt->execute()) {
    // Create notification for user
    createNotification($_SESSION['user_id'], 'license_application', 'Your application for ' . ucfirst($license_type) . ' license has been submitted and is pending approval.');
    
    // Create notification for admins/moderators
    if ($license_type === 'moderator') {
        // Notify admins for moderator license
        $stmt = $conn->prepare("SELECT id FROM users WHERE role = 'admin'");
        $stmt->execute();
        $admins = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        foreach ($admins as $admin_id) {
            createNotification($admin_id, 'license_request', 'A new Moderator license application has been submitted by ' . $_SESSION['user_name'] . '.');
        }
    } else {
        // Notify admins and moderators for publisher license
        $stmt = $conn->prepare("SELECT id FROM users WHERE role IN ('admin', 'moderator')");
        $stmt->execute();
        $approvers = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        foreach ($approvers as $approver_id) {
            createNotification($approver_id, 'license_request', 'A new Publisher license application has been submitted by ' . $_SESSION['user_name'] . '.');
        }
    }
    
    setMessage('Your license application has been submitted successfully', 'success');
} else {
    setMessage('Failed to submit your license application', 'error');
}

// Redirect back to dashboard
header('Location: ../index.php?page=dashboard');
exit();
?>
