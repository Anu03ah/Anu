<?php
/**
 * Promote user action for admin dashboard
 */
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and is an admin
if (!isLoggedIn() || !isAdmin()) {
    $_SESSION['message'] = "You don't have permission to access this page";
    $_SESSION['message_type'] = "error";
    header("Location: ../index.php");
    exit();
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $role = isset($_POST['role']) ? sanitize($_POST['role']) : '';
    
    // Validate role
    if (!in_array($role, ['moderator', 'publisher'])) {
        $_SESSION['message'] = "Invalid role specified";
        $_SESSION['message_type'] = "error";
        header("Location: ../index.php?page=dashboard#user-management");
        exit();
    }
    
    if ($user_id > 0) {
        global $conn;
        
        // Get user information
        $user = getUserById($user_id);
        
        if ($user) {
            // Cannot modify admin accounts
            if ($user['role'] === 'admin') {
                $_SESSION['message'] = "Admin accounts cannot be modified";
                $_SESSION['message_type'] = "error";
                header("Location: ../index.php?page=dashboard#user-management");
                exit();
            }
            
            // Update user role
            $stmt = $conn->prepare("UPDATE users SET role = :role WHERE id = :id");
            $stmt->bindParam(':role', $role, PDO::PARAM_STR);
            $stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                // Create notification for the user
                $notification_message = "Congratulations! Your account has been promoted to " . ucfirst($role) . ".";
                createNotification($user_id, 'account_status', $notification_message);
                
                $_SESSION['message'] = "User {$user['name']} has been promoted to " . ucfirst($role) . " successfully";
                $_SESSION['message_type'] = "success";
            } else {
                $_SESSION['message'] = "Failed to update user role";
                $_SESSION['message_type'] = "error";
            }
        } else {
            $_SESSION['message'] = "User not found";
            $_SESSION['message_type'] = "error";
        }
    } else {
        $_SESSION['message'] = "Invalid parameters";
        $_SESSION['message_type'] = "error";
    }
}

// Redirect back to admin dashboard
header("Location: ../index.php?page=dashboard#user-management");
exit();
?>
