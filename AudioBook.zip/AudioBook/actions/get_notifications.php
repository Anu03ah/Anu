<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode([
        'success' => false,
        'message' => 'User not logged in'
    ]);
    exit();
}

// Get parameters
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$size = isset($_GET['size']) ? intval($_GET['size']) : 5;

// Validate parameters
if ($page < 1) $page = 1;
if ($size < 1 || $size > 20) $size = 5;

// Calculate offset
$offset = ($page - 1) * $size;

// Get notifications
try {
    global $conn;
    
    // Get total count
    $stmt = $conn->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = :user_id");
    $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->execute();
    $total = $stmt->fetchColumn();
    
    // Get notifications
    $stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = :user_id ORDER BY created_at DESC LIMIT :offset, :size");
    $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindParam(':size', $size, PDO::PARAM_INT);
    $stmt->execute();
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check if there are more notifications
    $hasMore = ($offset + $size) < $total;
    
    // Return success
    echo json_encode([
        'success' => true,
        'notifications' => $notifications,
        'has_more' => $hasMore,
        'total' => $total,
        'page' => $page,
        'size' => $size
    ]);
} catch (Exception $e) {
    // Return error
    echo json_encode([
        'success' => false,
        'message' => 'Failed to get notifications: ' . $e->getMessage()
    ]);
}
?>
