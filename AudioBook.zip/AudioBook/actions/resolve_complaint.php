<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and has appropriate role
if (!isLoggedIn()) {
    setMessage('Please login to resolve complaints', 'error');
    header('Location: ../index.php?page=login');
    exit();
}

if (!isAdmin() && !isModerator()) {
    setMessage('You do not have permission to resolve complaints', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    setMessage('Invalid request method', 'error');
    header('Location: ../index.php');
    exit();
}

// Get parameters
$complaint_id = isset($_POST['complaint_id']) ? intval($_POST['complaint_id']) : 0;
$resolution = isset($_POST['resolution']) ? sanitize($_POST['resolution']) : '';
$action = isset($_POST['action']) ? sanitize($_POST['action']) : 'resolved';
$user_to_block = isset($_POST['user_to_block']) ? sanitize($_POST['user_to_block']) : '';
$block_duration = isset($_POST['block_duration']) ? sanitize($_POST['block_duration']) : 'temporary';

// Validate complaint ID
if ($complaint_id <= 0) {
    setMessage('Invalid complaint ID', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Validate resolution
if (empty($resolution)) {
    setMessage('Please provide a resolution message', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Get complaint details
$stmt = $conn->prepare("SELECT * FROM complaints WHERE id = :id AND status != 'resolved'");
$stmt->bindParam(':id', $complaint_id, PDO::PARAM_INT);
$stmt->execute();
$complaint = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$complaint) {
    setMessage('Complaint not found or already resolved', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Process complaint resolution
try {
    // Begin transaction
    $conn->beginTransaction();
    
    // Update complaint status
    $stmt = $conn->prepare("UPDATE complaints SET status = 'resolved', resolved_by = :resolved_by WHERE id = :id");
    $stmt->bindParam(':resolved_by', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->bindParam(':id', $complaint_id, PDO::PARAM_INT);
    $stmt->execute();
    
    // Create notification for user who submitted the complaint
    createNotification($complaint['user_id'], 'complaint_resolved', 'Your complaint has been resolved. Resolution: ' . $resolution);
    
    // Handle additional actions
    if ($action === 'block_user' || $action === 'block_publisher') {
        // Find user to block
        if (!empty($user_to_block)) {
            // Check if user_to_block is an email or ID
            if (filter_var($user_to_block, FILTER_VALIDATE_EMAIL)) {
                $stmt = $conn->prepare("SELECT id FROM users WHERE email = :email");
                $stmt->bindParam(':email', $user_to_block, PDO::PARAM_STR);
            } else {
                $stmt = $conn->prepare("SELECT id FROM users WHERE id = :id");
                $stmt->bindParam(':id', $user_to_block, PDO::PARAM_INT);
            }
            
            $stmt->execute();
            $user_id = $stmt->fetchColumn();
            
            if ($user_id) {
                // Block user
                $stmt = $conn->prepare("UPDATE users SET status = 'blocked' WHERE id = :id");
                $stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
                $stmt->execute();
                
                // Create notification for blocked user
                $block_message = ($block_duration === 'permanent') ? 
                    'Your account has been permanently blocked due to a violation.' : 
                    'Your account has been temporarily blocked for 7 days due to a violation.';
                
                createNotification($user_id, 'account_blocked', $block_message . ' Reason: ' . $resolution);
                
                // If temporary block, schedule unblock (in a real system, this would be handled by a cron job)
                if ($block_duration === 'temporary') {
                    // For demonstration purposes, we're just noting this in the notification
                    createNotification($user_id, 'account_unblock_scheduled', 'Your account will be automatically unblocked in 7 days.');
                }
            } else {
                // User not found, add a note to the transaction
                $stmt = $conn->prepare("INSERT INTO notifications (user_id, type, message) 
                                      VALUES (:user_id, 'system_note', 'Failed to block user: User not found with identifier \"' . :identifier . '\"')");
                $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
                $stmt->bindParam(':identifier', $user_to_block, PDO::PARAM_STR);
                $stmt->execute();
            }
        }
    }
    
    // Commit transaction
    $conn->commit();
    
    setMessage('Complaint has been resolved successfully', 'success');
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollBack();
    
    setMessage('An error occurred while resolving the complaint: ' . $e->getMessage(), 'error');
}

// Redirect back to dashboard
header('Location: ../index.php?page=dashboard');
exit();
?>
