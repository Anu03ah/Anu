<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get parameters
$book_id = isset($_POST['book_id']) ? intval($_POST['book_id']) : 0;
$page = isset($_POST['page']) && !empty($_POST['page']) ? intval($_POST['page']) : null;
$position = isset($_POST['position']) && !empty($_POST['position']) ? intval($_POST['position']) : null;

// Validate book_id
if ($book_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid book ID']);
    exit();
}

// Check if user has purchased this book
if (!hasPurchasedBook($_SESSION['user_id'], $book_id)) {
    echo json_encode(['success' => false, 'message' => 'User has not purchased this book']);
    exit();
}

// Save bookmark
$result = saveBookmark($_SESSION['user_id'], $book_id, $page, $position);

if ($result) {
    echo json_encode(['success' => true, 'message' => 'Bookmark saved successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to save bookmark']);
}
?>
