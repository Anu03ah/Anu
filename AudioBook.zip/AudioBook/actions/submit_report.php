<?php
/**
 * Handle report submissions
 */
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    setMessage('Please login to submit a report', 'error');
    $_SESSION['redirect_after_login'] = 'index.php?page=' . (isset($_SERVER['HTTP_REFERER']) ? parse_url($_SERVER['HTTP_REFERER'], PHP_URL_PATH) : '');
    header('Location: ../index.php?page=login');
    exit();
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $report_type = sanitize($_POST['report_type']);
    $target_id = (int)$_POST['target_id'];
    $reason = sanitize($_POST['reason']);
    $details = isset($_POST['details']) ? sanitize($_POST['details']) : '';
    
    // Validate input
    if (empty($report_type) || empty($target_id) || empty($reason)) {
        setMessage('Please fill in all required fields', 'error');
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit();
    }
    
    // Validate report type
    if (!in_array($report_type, ['book', 'user', 'review'])) {
        setMessage('Invalid report type', 'error');
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit();
    }
    
    // Check if target exists
    $target_exists = false;
    switch ($report_type) {
        case 'book':
            $book = getBookById($target_id);
            $target_exists = ($book !== false);
            break;
            
        case 'user':
            $user = getUserById($target_id);
            $target_exists = ($user !== false);
            break;
            
        case 'review':
            // Check if review exists
            $stmt = $conn->prepare("SELECT * FROM feedback WHERE id = :id");
            $stmt->bindParam(':id', $target_id, PDO::PARAM_INT);
            $stmt->execute();
            $target_exists = ($stmt->rowCount() > 0);
            break;
    }
    
    if (!$target_exists) {
        setMessage('The reported item does not exist', 'error');
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit();
    }
    
    // Create report
    $success = createReport($_SESSION['user_id'], $report_type, $target_id, $reason, $details);
    
    if ($success) {
        setMessage('Your report has been submitted successfully. Our team will review it shortly.', 'success');
    } else {
        setMessage('Failed to submit your report. Please try again later.', 'error');
    }
    
    // Redirect back to the previous page
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit();
} else {
    // Redirect if accessed directly
    header('Location: ../index.php');
    exit();
}
?>
