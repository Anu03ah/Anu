<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if user is logged in
if (!isLoggedIn()) {
    setMessage('You must be logged in to perform this action', 'error');
    header('Location: ../index.php');
    exit();
}

// Check if user is admin or publisher
if (!isAdmin() && !isPublisher()) {
    setMessage('You do not have permission to delete books', 'error');
    header('Location: ../index.php');
    exit();
}

// Check if book ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    setMessage('Invalid book ID', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

$book_id = intval($_GET['id']);

// Get book details
try {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM books WHERE id = :id");
    $stmt->bindParam(':id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    $book = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$book) {
        setMessage('Book not found', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Check if user is the publisher of the book or an admin
    if (!isAdmin() && $book['publisher_id'] != $_SESSION['user_id']) {
        setMessage('You do not have permission to delete this book', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Delete the book from the database
    $stmt = $conn->prepare("DELETE FROM books WHERE id = :id");
    $stmt->bindParam(':id', $book_id, PDO::PARAM_INT);
    $result = $stmt->execute();
    
    if ($result) {
        // Delete the files if they exist
        if (!empty($book['pdf_path']) && file_exists('../' . $book['pdf_path'])) {
            unlink('../' . $book['pdf_path']);
        }
        
        if (!empty($book['audio_path']) && file_exists('../' . $book['audio_path'])) {
            unlink('../' . $book['audio_path']);
        }
        
        if (!empty($book['cover_path']) && file_exists('../' . $book['cover_path'])) {
            unlink('../' . $book['cover_path']);
        }
        
        setMessage('Book deleted successfully', 'success');
    } else {
        setMessage('Failed to delete book', 'error');
    }
} catch (PDOException $e) {
    error_log("Error deleting book: " . $e->getMessage());
    setMessage('Database error: ' . $e->getMessage(), 'error');
}

// Redirect based on user role
if (isAdmin()) {
    header('Location: ../index.php?page=dashboard&section=admin');
} else {
    header('Location: ../index.php?page=dashboard');
}
exit();
?>
