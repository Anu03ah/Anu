<?php
/**
 * Handle report processing
 */
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and has appropriate role
if (!isLoggedIn() || (!isAdmin() && !isModerator())) {
    setMessage('You do not have permission to perform this action', 'error');
    header('Location: ../index.php');
    exit();
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $report_id = isset($_POST['report_id']) ? (int)$_POST['report_id'] : 0;
    $action = isset($_POST['action']) ? sanitize($_POST['action']) : '';
    $resolution_note = isset($_POST['resolution_note']) ? sanitize($_POST['resolution_note']) : '';
    $target_id = isset($_POST['target_id']) ? (int)$_POST['target_id'] : 0;
    $notify_reporter = isset($_POST['notify_reporter']) ? (bool)$_POST['notify_reporter'] : false;
    
    // Validate input
    if (empty($report_id) || empty($action)) {
        setMessage('Invalid request', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Add debug logging
    error_log("Processing report: ID=$report_id, Action=$action");
    
    // Get report details for special actions
    $report = null;
    if (in_array($action, ['remove_book', 'block_user', 'remove_review'])) {
        global $conn;
        try {
            // Check if the reports table exists
            $stmt = $conn->prepare("SHOW TABLES LIKE 'reports'");
            $stmt->execute();
            $tableExists = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($tableExists) {
                $stmt = $conn->prepare("SELECT * FROM reports WHERE id = :report_id");
                $stmt->bindParam(':report_id', $report_id, PDO::PARAM_INT);
                $stmt->execute();
                $report = $stmt->fetch(PDO::FETCH_ASSOC);
            } else {
                // Try using the complaints table instead
                $stmt = $conn->prepare("SELECT * FROM complaints WHERE id = :report_id");
                $stmt->bindParam(':report_id', $report_id, PDO::PARAM_INT);
                $stmt->execute();
                $report = $stmt->fetch(PDO::FETCH_ASSOC);
                
                error_log("Using complaints table instead of reports table");
            }
            
            if (!$report) {
                error_log("Report not found: ID=$report_id");
                setMessage('Report not found', 'error');
                header('Location: ../index.php?page=dashboard');
                exit();
            }
            
            // If target_id wasn't provided, use the one from the report
            if (empty($target_id)) {
                $target_id = $report['target_id'];
            }
        } catch (PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            setMessage('Database error: ' . $e->getMessage(), 'error');
            header('Location: ../index.php?page=dashboard');
            exit();
        }
    }
    
    $success = false;
    $message = '';
    
    // Handle different actions
    switch ($action) {
        case 'in_progress':
            // Mark report as in progress
            $success = processReport($report_id, 'in_progress', $_SESSION['user_id'], $resolution_note);
            $message = 'Report has been marked as in progress';
            break;
            
        case 'resolve':
            // Resolve the report
            $success = processReport($report_id, 'resolved', $_SESSION['user_id'], $resolution_note, $notify_reporter);
            $message = 'Report has been resolved';
            break;
            
        case 'dismiss':
            // Dismiss the report
            $success = processReport($report_id, 'dismissed', $_SESSION['user_id'], $resolution_note, $notify_reporter);
            $message = 'Report has been dismissed';
            break;
            
        case 'remove_book':
            // Get removal reason
            $removal_reason = isset($_POST['removal_reason']) ? sanitize($_POST['removal_reason']) : 'Violation of terms';
            
            // Simply delete the book from the database
            try {
                // Delete the book
                $stmt = $conn->prepare("DELETE FROM books WHERE id = :book_id");
                $stmt->bindParam(':book_id', $target_id, PDO::PARAM_INT);
                $success = $stmt->execute();
                
                if ($success) {
                    // Also resolve the report
                    $stmt = $conn->prepare("UPDATE reports SET status = 'resolved', resolved_by = :resolver_id, resolution_note = :note WHERE id = :report_id");
                    $stmt->bindParam(':resolver_id', $_SESSION['user_id'], PDO::PARAM_INT);
                    $stmt->bindParam(':note', $removal_reason, PDO::PARAM_STR);
                    $stmt->bindParam(':report_id', $report_id, PDO::PARAM_INT);
                    $stmt->execute();
                    
                    // Create notification for book owner
                    if (isset($report['target_owner_id'])) {
                        $notifyMessage = "Your book has been removed. Reason: {$removal_reason}";
                        createNotification($report['target_owner_id'], 'book_removed', $notifyMessage);
                    }
                    
                    $message = 'Book has been removed and report resolved';
                } else {
                    $message = 'Failed to remove book';
                }
            } catch (PDOException $e) {
                error_log("Error removing book: " . $e->getMessage());
                $success = false;
                $message = 'Database error occurred';
            }
            break;
            
        case 'block_user':
            // Get block reason
            $block_reason = isset($_POST['block_reason']) ? sanitize($_POST['block_reason']) : 'Violation of terms';
            
            // Simply update user status to blocked
            try {
                // Block the user
                $stmt = $conn->prepare("UPDATE users SET status = 'blocked' WHERE id = :user_id");
                $stmt->bindParam(':user_id', $target_id, PDO::PARAM_INT);
                $success = $stmt->execute();
                
                if ($success) {
                    // Also resolve the report
                    $stmt = $conn->prepare("UPDATE reports SET status = 'resolved', resolved_by = :resolver_id, resolution_note = :note WHERE id = :report_id");
                    $stmt->bindParam(':resolver_id', $_SESSION['user_id'], PDO::PARAM_INT);
                    $stmt->bindParam(':note', $block_reason, PDO::PARAM_STR);
                    $stmt->bindParam(':report_id', $report_id, PDO::PARAM_INT);
                    $stmt->execute();
                    
                    // Create notification for blocked user
                    $blockMessage = "Your account has been blocked. Reason: {$block_reason}";
                    createNotification($target_id, 'account_blocked', $blockMessage);
                    
                    $message = 'User has been blocked and report resolved';
                } else {
                    $message = 'Failed to block user';
                }
            } catch (PDOException $e) {
                error_log("Error blocking user: " . $e->getMessage());
                $success = false;
                $message = 'Database error occurred';
            }
            break;
            
        case 'remove_review':
            // Get removal reason
            $removal_reason = isset($_POST['removal_reason']) ? sanitize($_POST['removal_reason']) : 'Violation of terms';
            $notify_reviewer = isset($_POST['notify_reviewer']) ? (bool)$_POST['notify_reviewer'] : true;
            
            // Set confirmation to true since we're using a hidden field now
            $_POST['confirm_removal'] = 1;
            
            // Simply delete the review from the database
            try {
                // Get reviewer ID before deleting
                $stmt = $conn->prepare("SELECT user_id, book_id FROM feedback WHERE id = :review_id");
                $stmt->bindParam(':review_id', $target_id, PDO::PARAM_INT);
                $stmt->execute();
                $reviewData = $stmt->fetch(PDO::FETCH_ASSOC);
                $reviewerId = $reviewData ? $reviewData['user_id'] : null;
                $bookId = $reviewData ? $reviewData['book_id'] : null;
                
                // Delete the review
                $stmt = $conn->prepare("DELETE FROM feedback WHERE id = :review_id");
                $stmt->bindParam(':review_id', $target_id, PDO::PARAM_INT);
                $success = $stmt->execute();
                
                if ($success) {
                    // Also resolve the report
                    $stmt = $conn->prepare("UPDATE reports SET status = 'resolved', resolved_by = :resolver_id, resolution_note = :note WHERE id = :report_id");
                    $stmt->bindParam(':resolver_id', $_SESSION['user_id'], PDO::PARAM_INT);
                    $stmt->bindParam(':note', $removal_reason, PDO::PARAM_STR);
                    $stmt->bindParam(':report_id', $report_id, PDO::PARAM_INT);
                    $stmt->execute();
                    
                    // Create notification for reviewer
                    if ($notify_reviewer && $reviewerId) {
                        // Get book title
                        $bookTitle = "a book";
                        if ($bookId) {
                            $stmt = $conn->prepare("SELECT title FROM books WHERE id = :book_id");
                            $stmt->bindParam(':book_id', $bookId, PDO::PARAM_INT);
                            $stmt->execute();
                            $bookData = $stmt->fetch(PDO::FETCH_ASSOC);
                            if ($bookData) {
                                $bookTitle = $bookData['title'];
                            }
                        }
                        
                        $notifyMessage = "Your review for '{$bookTitle}' has been removed. Reason: {$removal_reason}";
                        createNotification($reviewerId, 'review_removed', $notifyMessage);
                    }
                    
                    $message = 'Review has been removed and report resolved';
                } else {
                    $message = 'Failed to remove review';
                }
            } catch (PDOException $e) {
                error_log("Error removing review: " . $e->getMessage());
                $success = false;
                $message = 'Database error occurred';
            }
            break;
            
        default:
            setMessage('Invalid action', 'error');
            header('Location: ../index.php?page=dashboard');
            exit();
    }
    
    if ($success) {
        setMessage($message, 'success');
    } else {
        setMessage('Failed to process report. Please try again.', 'error');
    }
    
    // Redirect back to dashboard
    header('Location: ../index.php?page=dashboard');
    exit();
} else {
    // Redirect if accessed directly
    header('Location: ../index.php');
    exit();
}
?>
