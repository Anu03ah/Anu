<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    setMessage('You must be logged in to remove books from your library', 'error');
    header('Location: ../index.php?page=login');
    exit();
}

// Check if book ID is provided
if (!isset($_POST['book_id']) || empty($_POST['book_id'])) {
    setMessage('Invalid book ID', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

$book_id = sanitize($_POST['book_id']);
$user_id = $_SESSION['user_id'];

try {
    // Start transaction
    $conn->beginTransaction();
    
    // Check if the book exists in the user's library
    $stmt = $conn->prepare("SELECT * FROM purchases WHERE user_id = :user_id AND book_id = :book_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    if ($stmt->rowCount() === 0) {
        throw new Exception('This book is not in your library');
    }
    
    // Delete from purchases table
    $stmt = $conn->prepare("DELETE FROM purchases WHERE user_id = :user_id AND book_id = :book_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    // Delete any bookmarks for this book
    $stmt = $conn->prepare("DELETE FROM bookmarks WHERE user_id = :user_id AND book_id = :book_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    
    // Commit transaction
    $conn->commit();
    
    setMessage('Book has been removed from your library successfully', 'success');
    
    // Redirect back to the dashboard
    header('Location: ../index.php?page=dashboard');
    exit();
    
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollBack();
    setMessage('Error: ' . $e->getMessage(), 'error');
    
    // Redirect back to the dashboard
    header('Location: ../index.php?page=dashboard');
    exit();
}
?>
