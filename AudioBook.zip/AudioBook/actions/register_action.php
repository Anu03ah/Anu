<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if this is an AJAX request
$isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

// Function to return JSON response for AJAX requests
function returnJsonResponse($success, $message, $redirect = null) {
    $response = [
        'success' => $success,
        'message' => $message
    ];
    
    if ($redirect) {
        $response['redirect'] = $redirect;
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $terms = isset($_POST['terms']) ? true : false;
    
    // Validate input
    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        if ($isAjax) {
            returnJsonResponse(false, 'Please fill in all fields');
        } else {
            setMessage('Please fill in all fields', 'error');
            header('Location: ../index.php?page=register');
            exit();
        }
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        if ($isAjax) {
            returnJsonResponse(false, 'Please enter a valid email address');
        } else {
            setMessage('Please enter a valid email address', 'error');
            header('Location: ../index.php?page=register');
            exit();
        }
    }
    
    if (strlen($password) < 8) {
        if ($isAjax) {
            returnJsonResponse(false, 'Password must be at least 8 characters long');
        } else {
            setMessage('Password must be at least 8 characters long', 'error');
            header('Location: ../index.php?page=register');
            exit();
        }
    }
    
    if ($password !== $confirm_password) {
        if ($isAjax) {
            returnJsonResponse(false, 'Passwords do not match');
        } else {
            setMessage('Passwords do not match', 'error');
            header('Location: ../index.php?page=register');
            exit();
        }
    }
    
    if (!$terms) {
        if ($isAjax) {
            returnJsonResponse(false, 'You must agree to the terms and conditions');
        } else {
            setMessage('You must agree to the terms and conditions', 'error');
            header('Location: ../index.php?page=register');
            exit();
        }
    }
    
    // Check if email already exists
    $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    
    if ($stmt->fetchColumn() > 0) {
        if ($isAjax) {
            returnJsonResponse(false, 'Email already in use');
        } else {
            setMessage('Email already in use', 'error');
            header('Location: ../index.php?page=register');
            exit();
        }
    }
    
    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert new user
    $stmt = $conn->prepare("INSERT INTO users (name, email, password, role, status) VALUES (:name, :email, :password, :role, :status)");
    $role = ROLE_USER;
    $status = 'active';
    
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $hashed_password);
    $stmt->bindParam(':role', $role);
    $stmt->bindParam(':status', $status);
    
    if ($stmt->execute()) {
        // Get the new user ID
        $user_id = $conn->lastInsertId();
        
        // Set session variables
        $_SESSION['user_id'] = $user_id;
        $_SESSION['user_name'] = $name;
        $_SESSION['user_email'] = $email;
        $_SESSION['user_role'] = $role;
        
        // Create welcome notification
        createNotification($user_id, 'welcome', 'Welcome to ' . APP_NAME . '! Start exploring our collection of books.');
        
        setMessage('Registration successful! Welcome to ' . APP_NAME, 'success');
        
        if ($isAjax) {
            returnJsonResponse(true, 'Registration successful! Welcome to ' . APP_NAME, 'http://localhost/AudioBook/index.php');
        } else {
            header('Location: http://localhost/AudioBook/index.php');
            exit();
        }
    } else {
        if ($isAjax) {
            returnJsonResponse(false, 'Registration failed. Please try again.');
        } else {
            setMessage('Registration failed. Please try again.', 'error');
            header('Location: ../index.php?page=register');
            exit();
        }
    }
} else {
    // Redirect if not POST request
    if ($isAjax) {
        returnJsonResponse(false, 'Invalid request method');
    } else {
        header('Location: ../index.php?page=register');
        exit();
    }
}
?>
