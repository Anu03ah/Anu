<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Get parameters
$book_id = isset($_GET['book_id']) ? intval($_GET['book_id']) : 0;
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Validate parameters
if ($book_id <= 0) {
    exit('Invalid book ID');
}

// Set session variables for auth modal
$_SESSION['keep_auth_modal_open'] = true;

// Set appropriate message based on action
if ($action == 'purchase') {
    $_SESSION['auth_action_message'] = 'Please login or register to purchase this book';
} else {
    $_SESSION['auth_action_message'] = 'Please login or register to continue';
}

// Set redirect URL for after login
$_SESSION['redirect_after_login'] = 'index.php?page=book&id=' . $book_id;

// Return success
echo 'success';
?>
