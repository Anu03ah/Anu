<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and is a publisher
if (!isLoggedIn()) {
    setMessage('Please login to upload books', 'error');
    header('Location: ../index.php?page=login');
    exit();
}

if (!isPublisher() && !isAdmin()) {
    setMessage('You do not have permission to upload books', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    setMessage('Invalid request method', 'error');
    header('Location: ../index.php');
    exit();
}

// Get form data
$title = isset($_POST['title']) ? sanitize($_POST['title']) : '';
$author = isset($_POST['author']) ? sanitize($_POST['author']) : '';
$category = isset($_POST['category']) ? sanitize($_POST['category']) : '';
$price = isset($_POST['price']) ? floatval($_POST['price']) : 0;
$description = isset($_POST['description']) ? sanitize($_POST['description']) : '';
$preview_enabled = isset($_POST['preview_enabled']) ? 1 : 0;
$download_allowed = isset($_POST['download_allowed']) ? 1 : 0;
$terms_signed = isset($_POST['terms_signed']) ? 1 : 0;

// Validate required fields
if (empty($title) || empty($author) || empty($category) || $price < 0 || empty($description)) {
    setMessage('Please fill in all required fields', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Validate that at least one file is uploaded
if (empty($_FILES['pdf_file']['name']) && empty($_FILES['audio_file']['name'])) {
    setMessage('Please upload at least one file (PDF or Audio)', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// If download is allowed, check if terms are signed
if ($download_allowed && !$terms_signed) {
    // Set download_allowed to false if terms not signed
    $download_allowed = 0;
}

// Initialize file paths
$pdf_path = null;
$audio_path = null;
$cover_path = null;

// Create directories if they don't exist with proper error handling
$upload_dirs = [UPLOAD_DIR, PDF_DIR, AUDIO_DIR, COVER_DIR];

foreach ($upload_dirs as $dir) {
    if (!file_exists($dir)) {
        if (!mkdir($dir, 0777, true)) {
            error_log("Failed to create directory: " . $dir);
            setMessage('Failed to create upload directories. Please contact the administrator.', 'error');
            header('Location: ../index.php?page=dashboard');
            exit();
        }
        // Ensure proper permissions
        chmod($dir, 0777);
    }
}

// Process cover image upload
if (!empty($_FILES['cover']['name'])) {
    $cover_file = $_FILES['cover'];
    $cover_name = time() . '_' . basename($cover_file['name']);
    $cover_target = COVER_DIR . $cover_name;
    
    // Check if file is an image
    $check = getimagesize($cover_file['tmp_name']);
    if ($check === false) {
        setMessage('Cover file is not an image', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Check file size (max 5MB)
    if ($cover_file['size'] > 5 * 1024 * 1024) {
        setMessage('Cover file is too large (max 5MB)', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Upload file with better error handling
    if (!move_uploaded_file($cover_file['tmp_name'], $cover_target)) {
        $error_message = 'Failed to upload cover image';
        
        // Get more detailed error information
        switch ($cover_file['error']) {
            case UPLOAD_ERR_INI_SIZE:
                $error_message .= ' - File exceeds upload_max_filesize directive in php.ini';
                break;
            case UPLOAD_ERR_FORM_SIZE:
                $error_message .= ' - File exceeds MAX_FILE_SIZE directive in the HTML form';
                break;
            case UPLOAD_ERR_PARTIAL:
                $error_message .= ' - File was only partially uploaded';
                break;
            case UPLOAD_ERR_NO_FILE:
                $error_message .= ' - No file was uploaded';
                break;
            case UPLOAD_ERR_NO_TMP_DIR:
                $error_message .= ' - Missing a temporary folder';
                break;
            case UPLOAD_ERR_CANT_WRITE:
                $error_message .= ' - Failed to write file to disk';
                break;
            case UPLOAD_ERR_EXTENSION:
                $error_message .= ' - A PHP extension stopped the file upload';
                break;
        }
        
        // Log the error for debugging
        error_log("Cover upload error: " . $error_message . " - Path: " . $cover_target);
        
        setMessage($error_message, 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    $cover_path = 'uploads/covers/' . $cover_name;
} else {
    // Cover image is required
    setMessage('Please upload a cover image', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Process PDF upload
if (!empty($_FILES['pdf_file']['name'])) {
    $pdf_file = $_FILES['pdf_file'];
    $pdf_name = time() . '_' . basename($pdf_file['name']);
    $pdf_target = PDF_DIR . $pdf_name;
    
    // Check file type
    $pdf_file_type = strtolower(pathinfo($pdf_target, PATHINFO_EXTENSION));
    if ($pdf_file_type !== 'pdf') {
        setMessage('Only PDF files are allowed for PDF upload', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Check file size (max 50MB)
    if ($pdf_file['size'] > 50 * 1024 * 1024) {
        setMessage('PDF file is too large (max 50MB)', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Upload file with better error handling
    if (!move_uploaded_file($pdf_file['tmp_name'], $pdf_target)) {
        $error_message = 'Failed to upload PDF file';
        
        // Get more detailed error information
        switch ($pdf_file['error']) {
            case UPLOAD_ERR_INI_SIZE:
                $error_message .= ' - File exceeds upload_max_filesize directive in php.ini';
                break;
            case UPLOAD_ERR_FORM_SIZE:
                $error_message .= ' - File exceeds MAX_FILE_SIZE directive in the HTML form';
                break;
            case UPLOAD_ERR_PARTIAL:
                $error_message .= ' - File was only partially uploaded';
                break;
            case UPLOAD_ERR_NO_FILE:
                $error_message .= ' - No file was uploaded';
                break;
            case UPLOAD_ERR_NO_TMP_DIR:
                $error_message .= ' - Missing a temporary folder';
                break;
            case UPLOAD_ERR_CANT_WRITE:
                $error_message .= ' - Failed to write file to disk';
                break;
            case UPLOAD_ERR_EXTENSION:
                $error_message .= ' - A PHP extension stopped the file upload';
                break;
        }
        
        // Log the error for debugging
        error_log("PDF upload error: " . $error_message . " - Path: " . $pdf_target);
        
        setMessage($error_message, 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    $pdf_path = 'uploads/pdf/' . $pdf_name;
}

// Process audio upload
if (!empty($_FILES['audio_file']['name'])) {
    $audio_file = $_FILES['audio_file'];
    $audio_name = time() . '_' . basename($audio_file['name']);
    $audio_target = AUDIO_DIR . $audio_name;
    
    // Check file type
    $audio_file_type = strtolower(pathinfo($audio_target, PATHINFO_EXTENSION));
    if ($audio_file_type !== 'mp3' && $audio_file_type !== 'wav') {
        setMessage('Only MP3 and WAV files are allowed for audio upload', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Check file size (max 100MB)
    if ($audio_file['size'] > 100 * 1024 * 1024) {
        setMessage('Audio file is too large (max 100MB)', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Upload file with better error handling
    if (!move_uploaded_file($audio_file['tmp_name'], $audio_target)) {
        $error_message = 'Failed to upload audio file';
        
        // Get more detailed error information
        switch ($audio_file['error']) {
            case UPLOAD_ERR_INI_SIZE:
                $error_message .= ' - File exceeds upload_max_filesize directive in php.ini';
                break;
            case UPLOAD_ERR_FORM_SIZE:
                $error_message .= ' - File exceeds MAX_FILE_SIZE directive in the HTML form';
                break;
            case UPLOAD_ERR_PARTIAL:
                $error_message .= ' - File was only partially uploaded';
                break;
            case UPLOAD_ERR_NO_FILE:
                $error_message .= ' - No file was uploaded';
                break;
            case UPLOAD_ERR_NO_TMP_DIR:
                $error_message .= ' - Missing a temporary folder';
                break;
            case UPLOAD_ERR_CANT_WRITE:
                $error_message .= ' - Failed to write file to disk';
                break;
            case UPLOAD_ERR_EXTENSION:
                $error_message .= ' - A PHP extension stopped the file upload';
                break;
        }
        
        // Log the error for debugging
        error_log("Audio upload error: " . $error_message . " - Path: " . $audio_target);
        
        setMessage($error_message, 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    $audio_path = 'uploads/audio/' . $audio_name;
}

// Insert book into database
try {
    $stmt = $conn->prepare("INSERT INTO books (title, author, description, category, cover_path, pdf_path, audio_path, price, publisher_id, download_allowed, preview_enabled, terms_signed) 
                           VALUES (:title, :author, :description, :category, :cover_path, :pdf_path, :audio_path, :price, :publisher_id, :download_allowed, :preview_enabled, :terms_signed)");
    
    $stmt->bindParam(':title', $title, PDO::PARAM_STR);
    $stmt->bindParam(':author', $author, PDO::PARAM_STR);
    $stmt->bindParam(':description', $description, PDO::PARAM_STR);
    $stmt->bindParam(':category', $category, PDO::PARAM_STR);
    $stmt->bindParam(':cover_path', $cover_path, PDO::PARAM_STR);
    $stmt->bindParam(':pdf_path', $pdf_path, PDO::PARAM_STR);
    $stmt->bindParam(':audio_path', $audio_path, PDO::PARAM_STR);
    $stmt->bindParam(':price', $price, PDO::PARAM_STR);
    $stmt->bindParam(':publisher_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->bindParam(':download_allowed', $download_allowed, PDO::PARAM_INT);
    $stmt->bindParam(':preview_enabled', $preview_enabled, PDO::PARAM_INT);
    $stmt->bindParam(':terms_signed', $terms_signed, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        $book_id = $conn->lastInsertId();
        
        // Create notification for publisher
        createNotification($_SESSION['user_id'], 'book_uploaded', 'Your book "' . $title . '" has been uploaded successfully.');
        
        setMessage('Book uploaded successfully!', 'success');
        header('Location: ../index.php?page=book&id=' . $book_id);
        exit();
    } else {
        setMessage('Failed to upload book', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
} catch (Exception $e) {
    setMessage('An error occurred: ' . $e->getMessage(), 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}
?>
