<?php
/**
 * Handle bookmark actions (save, delete)
 */

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Include database configuration
require_once '../config/config.php';
require_once '../includes/functions.php';

// For debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Log the request for debugging
file_put_contents('../logs/bookmark_debug.log', date('Y-m-d H:i:s') . ' - Request: ' . print_r($_POST, true) . "\n", FILE_APPEND);

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'You must be logged in to save bookmarks']);
    exit;
}

// Get action
$action = isset($_POST['action']) ? $_POST['action'] : '';

// Handle save bookmark action
if ($action == 'save') {
    $book_id = isset($_POST['book_id']) ? intval($_POST['book_id']) : 0;
    $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
    $position = isset($_POST['position']) ? intval($_POST['position']) : null;
    
    // Log the parameters
    file_put_contents('../logs/bookmark_debug.log', date('Y-m-d H:i:s') . " - Processing: book_id=$book_id, page=$page, position=$position, user_id={$_SESSION['user_id']}\n", FILE_APPEND);
    
    // Validate book ID
    if ($book_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid book ID']);
        exit;
    }
    
    // Check if user has purchased this book
    if (!hasPurchasedBook($_SESSION['user_id'], $book_id)) {
        echo json_encode(['success' => false, 'message' => 'You must purchase this book to save bookmarks']);
        exit;
    }
    
    try {
        global $conn;
        
        // Check if bookmark exists
        $stmt = $conn->prepare("SELECT * FROM bookmarks WHERE user_id = :user_id AND book_id = :book_id");
        $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
        $stmt->execute();
        
        $bookmark = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($bookmark) {
            // Update existing bookmark with position if provided
            if ($position !== null) {
                $stmt = $conn->prepare("UPDATE bookmarks SET 
                                   last_read_page = :page,
                                   last_listen_position = :position,
                                   updated_at = NOW()
                                   WHERE user_id = :user_id AND book_id = :book_id");
                $stmt->bindParam(':position', $position, PDO::PARAM_INT);
            } else {
                // Just update the page
                $stmt = $conn->prepare("UPDATE bookmarks SET 
                                   last_read_page = :page,
                                   updated_at = NOW()
                                   WHERE user_id = :user_id AND book_id = :book_id");
            }
        } else {
            // Create new bookmark
            if ($position !== null) {
                $stmt = $conn->prepare("INSERT INTO bookmarks 
                                   (user_id, book_id, last_read_page, last_listen_position, created_at, updated_at)
                                   VALUES (:user_id, :book_id, :page, :position, NOW(), NOW())");
                $stmt->bindParam(':position', $position, PDO::PARAM_INT);
            } else {
                $stmt = $conn->prepare("INSERT INTO bookmarks 
                                   (user_id, book_id, last_read_page, created_at, updated_at)
                                   VALUES (:user_id, :book_id, :page, NOW(), NOW())");
            }
        }
        
        $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
        $stmt->bindParam(':page', $page, PDO::PARAM_INT);
        
        $result = $stmt->execute();
        
        // Log the result
        file_put_contents('../logs/bookmark_debug.log', date('Y-m-d H:i:s') . " - Result: " . ($result ? "Success" : "Failed") . "\n", FILE_APPEND);
        
        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Bookmark saved successfully', 'page' => $page, 'position' => $position]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to save bookmark: Database error']);
        }
    } catch (Exception $e) {
        // Log the error
        file_put_contents('../logs/bookmark_debug.log', date('Y-m-d H:i:s') . " - Error: " . $e->getMessage() . "\n", FILE_APPEND);
        echo json_encode(['success' => false, 'message' => 'Exception: ' . $e->getMessage()]);
    }
    
    exit;
}

// Handle delete bookmark action
if ($action == 'delete') {
    $book_id = isset($_POST['book_id']) ? intval($_POST['book_id']) : 0;
    
    // Validate book ID
    if ($book_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid book ID']);
        exit;
    }
    
    // Delete bookmark (set page to null)
    $result = saveBookmark($_SESSION['user_id'], $book_id, null);
    
    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Bookmark deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete bookmark']);
    }
    exit;
}

// Invalid action
echo json_encode(['success' => false, 'message' => 'Invalid action']);
exit;
