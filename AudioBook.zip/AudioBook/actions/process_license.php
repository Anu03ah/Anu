<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and has appropriate role
if (!isLoggedIn()) {
    setMessage('Please login to process license applications', 'error');
    header('Location: ../index.php?page=login');
    exit();
}

// Verify user has permission to process licenses
$license_type = '';
$stmt = $conn->prepare("SELECT type FROM licenses WHERE id = :license_id");
$stmt->bindParam(':license_id', $_POST['license_id'], PDO::PARAM_INT);
$stmt->execute();
$license_type = $stmt->fetchColumn();

if ($license_type === 'moderator' && !isAdmin()) {
    setMessage('Only administrators can process moderator license applications', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
} elseif ($license_type === 'publisher' && !isAdmin() && !isModerator()) {
    setMessage('Only administrators and moderators can process publisher license applications', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    setMessage('Invalid request method', 'error');
    header('Location: ../index.php');
    exit();
}

// Get parameters
$license_id = isset($_POST['license_id']) ? intval($_POST['license_id']) : 0;
$status = isset($_POST['status']) ? sanitize($_POST['status']) : '';
$rejection_reason = isset($_POST['rejection_reason']) ? sanitize($_POST['rejection_reason']) : '';

// Validate license ID
if ($license_id <= 0) {
    setMessage('Invalid license ID', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Validate status
if ($status !== 'approved' && $status !== 'rejected') {
    setMessage('Invalid status', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Get license details
$stmt = $conn->prepare("SELECT * FROM licenses WHERE id = :license_id AND status = 'pending'");
$stmt->bindParam(':license_id', $license_id, PDO::PARAM_INT);
$stmt->execute();
$license = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$license) {
    setMessage('License application not found or already processed', 'error');
    header('Location: ../index.php?page=dashboard');
    exit();
}

// Process license application
try {
    // Begin transaction
    $conn->beginTransaction();
    
    // Update license status
    $stmt = $conn->prepare("UPDATE licenses SET status = :status, approved_by = :approved_by WHERE id = :license_id");
    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    $stmt->bindParam(':approved_by', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->bindParam(':license_id', $license_id, PDO::PARAM_INT);
    $stmt->execute();
    
    // If approved, update user role
    if ($status === 'approved') {
        $stmt = $conn->prepare("UPDATE users SET role = :role WHERE id = :user_id");
        $stmt->bindParam(':role', $license['type'], PDO::PARAM_STR);
        $stmt->bindParam(':user_id', $license['user_id'], PDO::PARAM_INT);
        $stmt->execute();
        
        // Create notification for user
        createNotification($license['user_id'], 'license_approved', 'Your application for ' . ucfirst($license['type']) . ' license has been approved. You now have ' . ucfirst($license['type']) . ' privileges.');
    } else {
        // Create notification for user with rejection reason
        createNotification($license['user_id'], 'license_rejected', 'Your application for ' . ucfirst($license['type']) . ' license has been rejected. Reason: ' . $rejection_reason);
    }
    
    // Commit transaction
    $conn->commit();
    
    setMessage('License application has been ' . $status . ' successfully', 'success');
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollBack();
    
    setMessage('An error occurred while processing the license application: ' . $e->getMessage(), 'error');
}

// Redirect back to dashboard
header('Location: ../index.php?page=dashboard');
exit();
?>
