<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and is an admin
if (!isLoggedIn() || !isAdmin()) {
    setMessage('You do not have permission to perform this action.', 'error');
    header('Location: http://localhost/AudioBook/index.php');
    exit();
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $user_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
    $delete_confirmation = isset($_POST['delete_confirmation']) ? $_POST['delete_confirmation'] : '';
    $delete_reason = isset($_POST['delete_reason']) ? sanitize($_POST['delete_reason']) : '';
    
    // Validate input
    if (empty($user_id) || empty($delete_confirmation) || empty($delete_reason)) {
        setMessage('All fields are required.', 'error');
        header('Location: http://localhost/AudioBook/index.php?page=dashboard');
        exit();
    }
    
    // Check confirmation text
    if ($delete_confirmation !== 'DELETE') {
        setMessage('Incorrect confirmation text. User account was not deleted.', 'error');
        header('Location: http://localhost/AudioBook/index.php?page=dashboard');
        exit();
    }
    
    // Get user info before deletion
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        setMessage('User not found.', 'error');
        header('Location: http://localhost/AudioBook/index.php?page=dashboard');
        exit();
    }
    
    // Cannot delete admin accounts
    if ($user['role'] === 'admin') {
        setMessage('Admin accounts cannot be deleted.', 'error');
        header('Location: http://localhost/AudioBook/index.php?page=dashboard');
        exit();
    }
    
    try {
        // Begin transaction
        $conn->beginTransaction();
        
        // Log the deletion (to PHP error log since admin_logs table doesn't exist)
        $admin_id = $_SESSION['user_id'];
        $admin_name = $_SESSION['user_name'];
        $log_message = "User {$user['name']} (ID: {$user_id}, Email: {$user['email']}) was deleted by admin {$admin_name} (ID: {$admin_id}). Reason: {$delete_reason}";
        
        // Write to PHP error log instead of database
        error_log($log_message);
        
        // Delete user's data from related tables - using try/catch for each operation
        // to ensure we continue even if a table doesn't exist
        
        // 1. Delete feedback/reviews
        try {
            $stmt = $conn->prepare("DELETE FROM feedback WHERE user_id = :user_id");
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
        } catch (Exception $e) {
            error_log("Error deleting from feedback table: " . $e->getMessage());
            // Continue with the next operation
        }
        
        // 2. Delete bookmarks
        try {
            $stmt = $conn->prepare("DELETE FROM bookmarks WHERE user_id = :user_id");
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
        } catch (Exception $e) {
            error_log("Error deleting from bookmarks table: " . $e->getMessage());
            // Continue with the next operation
        }
        
        // 3. Delete notifications
        try {
            $stmt = $conn->prepare("DELETE FROM notifications WHERE user_id = :user_id");
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
        } catch (Exception $e) {
            error_log("Error deleting from notifications table: " . $e->getMessage());
            // Continue with the next operation
        }
        
        // 4. Delete purchases
        try {
            $stmt = $conn->prepare("DELETE FROM purchases WHERE user_id = :user_id");
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
        } catch (Exception $e) {
            error_log("Error deleting from purchases table: " . $e->getMessage());
            // Continue with the next operation
        }
        
        // 5. Delete licenses
        try {
            $stmt = $conn->prepare("DELETE FROM licenses WHERE user_id = :user_id");
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
        } catch (Exception $e) {
            error_log("Error deleting from licenses table: " . $e->getMessage());
            // Continue with the next operation
        }
        
        // 6. Handle books if user is a publisher
        if ($user['role'] === 'publisher') {
            try {
                // Get all books by this publisher
                $stmt = $conn->prepare("SELECT id FROM books WHERE publisher_id = :user_id");
                $stmt->bindParam(':user_id', $user_id);
                $stmt->execute();
                $books = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                foreach ($books as $book_id) {
                    // Delete book feedback
                    try {
                        $stmt = $conn->prepare("DELETE FROM feedback WHERE book_id = :book_id");
                        $stmt->bindParam(':book_id', $book_id);
                        $stmt->execute();
                    } catch (Exception $e) {
                        error_log("Error deleting book feedback: " . $e->getMessage());
                    }
                    
                    // Delete book bookmarks
                    try {
                        $stmt = $conn->prepare("DELETE FROM bookmarks WHERE book_id = :book_id");
                        $stmt->bindParam(':book_id', $book_id);
                        $stmt->execute();
                    } catch (Exception $e) {
                        error_log("Error deleting book bookmarks: " . $e->getMessage());
                    }
                    
                    // Delete book purchases
                    try {
                        $stmt = $conn->prepare("DELETE FROM purchases WHERE book_id = :book_id");
                        $stmt->bindParam(':book_id', $book_id);
                        $stmt->execute();
                    } catch (Exception $e) {
                        error_log("Error deleting book purchases: " . $e->getMessage());
                    }
                }
                
                // Delete the books
                $stmt = $conn->prepare("DELETE FROM books WHERE publisher_id = :user_id");
                $stmt->bindParam(':user_id', $user_id);
                $stmt->execute();
            } catch (Exception $e) {
                error_log("Error handling publisher books: " . $e->getMessage());
                // Continue with user deletion
            }
        }
        
        // 7. Finally, delete the user
        $stmt = $conn->prepare("DELETE FROM users WHERE id = :user_id");
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        
        // Commit transaction
        $conn->commit();
        
        setMessage("User account for {$user['name']} has been permanently deleted.", 'success');
        header('Location: http://localhost/AudioBook/index.php?page=dashboard');
        exit();
        
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollBack();
        
        // Log the error
        error_log("Error deleting user (ID: {$user_id}): " . $e->getMessage());
        
        setMessage('An error occurred while deleting the user account. Please try again.', 'error');
        header('Location: http://localhost/AudioBook/index.php?page=dashboard');
        exit();
    }
    
} else {
    // Redirect if not POST request
    setMessage('Invalid request method.', 'error');
    header('Location: http://localhost/AudioBook/index.php?page=dashboard');
    exit();
}
?>
