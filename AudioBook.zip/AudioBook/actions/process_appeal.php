<?php
/**
 * Process account unblock appeals
 */
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and has appropriate role
if (!isLoggedIn() || (!isAdmin() && !isModerator())) {
    setMessage('You do not have permission to perform this action', 'error');
    header('Location: ../index.php');
    exit();
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $appeal_id = isset($_POST['appeal_id']) ? (int)$_POST['appeal_id'] : 0;
    $action = isset($_POST['action']) ? sanitize($_POST['action']) : '';
    $response = isset($_POST['response']) ? sanitize($_POST['response']) : '';
    
    // Validate input
    if (empty($appeal_id) || empty($action)) {
        setMessage('Invalid request', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Get appeal details to check if user has permission to process it
    $appeal = getAppealById($appeal_id);
    
    if (!$appeal) {
        setMessage('Appeal not found', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Check if user has permission to process this appeal
    // Admins can process all appeals, moderators can only process non-moderator appeals
    if (!isAdmin() && $appeal['role'] === 'moderator') {
        setMessage('You do not have permission to process this appeal', 'error');
        header('Location: ../index.php?page=dashboard');
        exit();
    }
    
    // Process the appeal
    $status = ($action === 'approve') ? 'approved' : 'rejected';
    $success = processAppeal($appeal_id, $status, $_SESSION['user_id'], $response);
    
    if ($success) {
        $message = ($action === 'approve') 
            ? 'Appeal approved. User account has been unblocked.' 
            : 'Appeal rejected. User account remains blocked.';
        setMessage($message, 'success');
    } else {
        setMessage('Failed to process appeal. Please try again.', 'error');
    }
    
    // Redirect back to dashboard
    header('Location: ../index.php?page=dashboard');
    exit();
} else {
    // Redirect if accessed directly
    header('Location: ../index.php');
    exit();
}
?>
