<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: ../index.php?page=login');
    exit();
}

// Get the action
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Handle different actions
switch ($action) {
    case 'mark_read':
        // Mark a single notification as read
        if (isset($_GET['id'])) {
            $notification_id = intval($_GET['id']);
            // Mark notification as read without showing toast
            markNotificationAsRead($notification_id);
        }
        break;
        
    case 'mark_all_read':
        // Mark all notifications as read
        global $conn;
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = :user_id");
        $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        
        // Mark all notifications as read without showing toast
        $stmt->execute();
        break;
        
    case 'delete':
        // Delete a notification
        if (isset($_GET['id'])) {
            $notification_id = intval($_GET['id']);
            
            // Verify the notification belongs to the user
            global $conn;
            $stmt = $conn->prepare("SELECT COUNT(*) FROM notifications WHERE id = :id AND user_id = :user_id");
            $stmt->bindParam(':id', $notification_id, PDO::PARAM_INT);
            $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
            $stmt->execute();
            
            if ($stmt->fetchColumn() > 0) {
                // Delete the notification
                $stmt = $conn->prepare("DELETE FROM notifications WHERE id = :id");
                $stmt->bindParam(':id', $notification_id, PDO::PARAM_INT);
                
                // Delete notification without showing toast
                $stmt->execute();
            }
        }
        break;
        
    default:
        // No valid action
        setMessage('Invalid action', 'error');
}

// Redirect back
$redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'notifications';
header("Location: ../index.php?page=" . $redirect);
exit();
?>
