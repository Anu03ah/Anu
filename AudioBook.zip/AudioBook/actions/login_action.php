<?php
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if this is an AJAX request
$isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

// Function to return JSON response for AJAX requests
function returnJsonResponse($success, $message, $redirect = null) {
    $response = [
        'success' => $success,
        'message' => $message
    ];
    
    if ($redirect) {
        $response['redirect'] = $redirect;
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']) ? true : false;
    
    // Validate input
    if (empty($email) || empty($password)) {
        if ($isAjax) {
            returnJsonResponse(false, 'Please fill in all fields');
        } else {
            setMessage('Please fill in all fields', 'error');
            header('Location: ../index.php?page=login');
            exit();
        }
    }
    
    // Check if user exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && password_verify($password, $user['password'])) {
        // Check if user is blocked
        if ($user['status'] === 'blocked') {
            $_SESSION['blocked_account'] = true;
            $_SESSION['blocked_email'] = $email;
            $_SESSION['keep_auth_modal_open'] = true;
            
            if ($isAjax) {
                returnJsonResponse(false, 'Your account has been blocked. Please contact support.', '../index.php');
            } else {
                header('Location: ../index.php');
                exit();
            }
        }
        
        // Set session variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        
        // Set remember me cookie if requested
        if ($remember) {
            $token = bin2hex(random_bytes(32));
            $expires = time() + (86400 * 30); // 30 days
            
            // Store token in database
            $stmt = $conn->prepare("UPDATE users SET remember_token = :token WHERE id = :id");
            $stmt->bindParam(':token', $token);
            $stmt->bindParam(':id', $user['id']);
            $stmt->execute();
            
            // Set cookie
            setcookie('remember_token', $token, $expires, '/');
            setcookie('user_id', $user['id'], $expires, '/');
        }
        
        // Set welcome message
        setMessage('Welcome back, ' . $user['name'] . '!', 'success');
        
        // Get the base URL of the AudioBook application
        $base_url = 'http://' . $_SERVER['HTTP_HOST'] . '/AudioBook/';
        
        // Always redirect to AudioBook homepage after login
        $redirect = $base_url . 'index.php';
        
        // Only use specific redirects if they're not pointing to the dashboard
        if (isset($_SESSION['redirect_after_login']) && !empty($_SESSION['redirect_after_login'])) {
            if (strpos($_SESSION['redirect_after_login'], 'dashboard') === false) {
                // Make sure we're still within the AudioBook application
                $redirect = $base_url . ltrim($_SESSION['redirect_after_login'], '/');
            }
            unset($_SESSION['redirect_after_login']); // Clear the redirect URL
        }
        
        if ($isAjax) {
            // For AJAX requests, explicitly set the absolute homepage URL
            returnJsonResponse(true, 'Login successful', $base_url . 'index.php');
        } else {
            header('Location: ' . $redirect);
            exit();
        }
    } else {
        if ($isAjax) {
            returnJsonResponse(false, 'Invalid email or password');
        } else {
            setMessage('Invalid email or password', 'error');
            $_SESSION['keep_auth_modal_open'] = true;
            header('Location: ../index.php');
            exit();
        }
    }
} else {
    // Redirect if not POST request
    if ($isAjax) {
        returnJsonResponse(false, 'Invalid request method');
    } else {
        header('Location: ../index.php');
        exit();
    }
}
?>
