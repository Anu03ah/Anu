<?php
/**
 * Unblock user action for admin dashboard
 */
session_start();
require_once '../config/config.php';
require_once '../includes/functions.php';

// Check if user is logged in and is an admin
if (!isLoggedIn() || !isAdmin()) {
    $_SESSION['message'] = "You don't have permission to access this page";
    $_SESSION['message_type'] = "error";
    header("Location: ../index.php?page=login");
    exit();
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    
    if ($user_id > 0) {
        global $conn;
        
        // Get user information
        $user = getUserById($user_id);
        
        if ($user) {
            $status = 'active';
            
            // Update user status
            $stmt = $conn->prepare("UPDATE users SET status = :status WHERE id = :id");
            $stmt->bindParam(':status', $status, PDO::PARAM_STR);
            $stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                // Create notification for the user
                $notification_message = "Your account has been unblocked by an administrator.";
                createNotification($user_id, 'account_status', $notification_message);
                
                $_SESSION['message'] = "User {$user['name']} has been unblocked successfully";
                $_SESSION['message_type'] = "success";
            } else {
                $_SESSION['message'] = "Failed to update user status";
                $_SESSION['message_type'] = "error";
            }
        } else {
            $_SESSION['message'] = "User not found";
            $_SESSION['message_type'] = "error";
        }
    } else {
        $_SESSION['message'] = "Invalid parameters";
        $_SESSION['message_type'] = "error";
    }
}

// Redirect back to admin dashboard
header("Location: ../index.php?page=dashboard#user-management");
exit();
?>
