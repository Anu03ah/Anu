<?php
require_once 'config/config.php';

// Check if admin user exists
$stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE email = 'admin@audiobook.com' AND role = 'admin'");
$stmt->execute();
$admin_exists = $stmt->fetchColumn();

echo "Admin user exists: " . ($admin_exists ? "Yes" : "No") . "<br>";

// Check if users table exists
try {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM users");
    $stmt->execute();
    $user_count = $stmt->fetchColumn();
    echo "Total users in database: " . $user_count . "<br>";
} catch (PDOException $e) {
    echo "Error: Users table might not exist<br>";
}

// If admin doesn't exist, create one
if (!$admin_exists) {
    try {
        $admin_password = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES ('Admin', 'admin@audiobook.com', :password, 'admin')");
        $stmt->bindParam(':password', $admin_password);
        $stmt->execute();
        echo "Admin user created successfully!<br>";
    } catch (PDOException $e) {
        echo "Error creating admin user: " . $e->getMessage() . "<br>";
    }
}
?>
