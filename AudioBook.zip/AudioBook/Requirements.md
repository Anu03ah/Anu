# Audiobook Web Application - Requirements Document

## Overview

A dynamic audiobook and e-book web application that allows users to read books as PDFs or listen to audiobooks. It will support a four-tier user system with different access levels and responsibilities.

---

## User Roles

### 1. **Admin**

* Full access to all functionalities.
* Promote/Demote users to/from moderators or publishers.
* Block/Unblock users and publishers.
* Manage books (add/edit/delete).
* Access and manage all complaints and user reports.
* View system analytics (optional).
* Approve or reject moderator and publisher license applications.

### 2. **Moderators**

* Handle and respond to user complaints.
* Take action against misusers/frauds.
* Block users or publishers temporarily or permanently.
* Solve general queries.
* Approve or reject publisher license applications.

### 3. **Publishers**

* All features available to regular users.
* Upload new books (PDF and/or audio) **from their dedicated dashboard**.
* Edit book details (title, author, price, category, etc).
* Delete books.
* Adjust book pricing.
* Choose whether book downloads are allowed or not.

  * If download is enabled, the publisher must sign a digital agreement acknowledging the risks of piracy and accepting sole responsibility in case of piracy.
* Enable book previews (first few PDF pages or first audio minute).

### 4. **Users**

* Register/Login/Logout.
* Browse and purchase books.
* Read books via embedded PDF viewer.
* Listen to books via embedded audio player.
* Submit feedback/reviews with star ratings.
* View purchased books in personal dashboard.
* Submit complaints or queries.
* Apply for Publisher or Moderator License.

  * Moderator license can only be approved by Admin.
  * Publisher license can be approved by Admin or Moderators.
  * Issued licenses will be shown as cards on the user’s dashboard.
* Bookmark last read page or last listened position.

---

## Core Functional Features

### General Features:

* Mobile-responsive and dynamic design.
* SEO-friendly URLs.
* Email notifications for important actions (optional).
* Real-time notification system for feedback, complaint resolution, approvals, and purchases.

### Homepage:

* Display trending books.
* Showcase new releases.
* Search bar (with filters by genre, author, etc).
* Navigation bar with:

  * Dashboard
  * Notifications
  * Login/Register
  * Search

### Dashboard:

* Personalized for each user role.
* Users see purchased books, feedback status, bookmarked positions, and any applied or approved licenses as cards.
* Publishers see books they uploaded, preview settings, download permissions, and earnings (optional).

  * **Book uploads are handled entirely from this dashboard.**
* Moderators see unresolved complaints.
* Admin sees system stats and user management tools.
* License cards shown on user dashboard.
* License application status tracking panel.

---

## Technical Requirements

### Frontend:

* HTML5, CSS3, JavaScript
* Optional: Bootstrap or TailwindCSS for responsiveness
* Optional: AJAX for dynamic page updates

### Backend:

* PHP 8+
* MySQL 5.7+
* File upload and handling (PDFs and MP3s)
* Secure user authentication and role-based access control

### PDF & Audio:

* **PDF**: Embedded viewer using PDF.js
* **Audio**: HTML5 `<audio>` player with preview support
* Preview for books: First few pages (PDF) or first minute (audio)

### Payment Integration:

* Simulated payment gateway logic for book purchases.
* Record transaction details for analytics.

### Database Design (Simplified):

**Tables:**

* `users` (id, name, email, password, role, status)
* `books` (id, title, author, pdf\_path, audio\_path, price, publisher\_id, download\_allowed, preview\_enabled, terms\_signed, created\_at)
* `purchases` (id, user\_id, book\_id, purchase\_date)
* `feedback` (id, user\_id, book\_id, rating, comment, created\_at)
* `complaints` (id, user\_id, message, status, resolved\_by, created\_at)
* `notifications` (id, user\_id, type, message, is\_read, created\_at)
* `licenses` (id, user\_id, type, status, approved\_by, created\_at)
* `bookmarks` (id, user\_id, book\_id, last\_read\_page, last\_listen\_position)
* `transactions` (id, user\_id, book\_id, amount, payment\_status, created\_at)

---

## Non-Functional Requirements

* **Responsiveness:** Fully functional on mobile, tablet, and desktop.
* **Security:** Input validation, password hashing, file access protection.
* **Scalability:** Modular code to support future features.
* **Performance:** Efficient DB queries and file streaming.
* **Usability:** Clean UI/UX with intuitive navigation.

---