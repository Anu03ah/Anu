<?php
session_start();
require_once 'config/config.php';
require_once 'includes/functions.php';

// Set default page
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

// Include header
include_once 'includes/header.php';

// Load appropriate page
switch ($page) {
    case 'home':
        include_once 'pages/home.php';
        break;
    case 'login':
        include_once 'pages/login.php';
        break;
    case 'register':
        include_once 'pages/register.php';
        break;
    case 'dashboard':
        // Check if user is logged in
        if (!isLoggedIn()) {
            $_SESSION['message'] = "Please login to access dashboard";
            $_SESSION['message_type'] = "error";
            header("Location: index.php?page=login");
            exit();
        }
        include_once 'pages/dashboard.php';
        break;
    case 'book':
        include_once 'pages/book.php';
        break;
    case 'search':
        include_once 'pages/search.php';
        break;
    case 'profile':
        // Check if user is logged in
        if (!isLoggedIn()) {
            $_SESSION['message'] = "Please login to access your profile";
            $_SESSION['message_type'] = "error";
            header("Location: index.php?page=login");
            exit();
        }
        include_once 'pages/profile.php';
        break;
    // Logout is now handled by logout.php
    case 'read':
        include_once 'pages/read.php';
        break;
    case 'listen':
        include_once 'pages/listen.php';
        break;
    case 'preview':
        include_once 'pages/preview.php';
        break;
    case 'notifications':
        // Check if user is logged in
        if (!isLoggedIn()) {
            $_SESSION['message'] = "Please login to view your notifications";
            $_SESSION['message_type'] = "error";
            header("Location: index.php?page=login");
            exit();
        }
        include_once 'pages/notifications.php';
        break;
    case 'edit_book':
        // Check if user is logged in and is admin or publisher
        if (!isLoggedIn()) {
            $_SESSION['message'] = "Please login to edit books";
            $_SESSION['message_type'] = "error";
            header("Location: index.php?page=login");
            exit();
        }
        if (!isAdmin() && !isPublisher()) {
            $_SESSION['message'] = "You do not have permission to edit books";
            $_SESSION['message_type'] = "error";
            header("Location: index.php");
            exit();
        }
        include_once 'pages/edit_book.php';
        break;
    default:
        include_once 'pages/404.php';
}

// Include footer
include_once 'includes/footer.php';
?>
