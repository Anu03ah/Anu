<?php
/**
 * Create appeals table for storing account block appeals
 */
session_start();
require_once 'config.php';

try {
    // Check if the appeals table already exists
    $stmt = $conn->prepare("SHOW TABLES LIKE 'appeals'");
    $stmt->execute();
    
    if ($stmt->rowCount() == 0) {
        // Create appeals table
        $conn->exec("CREATE TABLE appeals (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            type VARCHAR(50) NOT NULL,
            reason TEXT NOT NULL,
            additional_info TEXT,
            status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
            reviewed_by INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
        )");
        
        echo "Appeals table created successfully!";
        
        // Add the table to database_setup.php for future installations
        $setup_file = file_get_contents('database_setup.php');
        $position = strrpos($setup_file, '?>');
        
        if ($position !== false) {
            $appeals_table_sql = <<<EOT

// Create appeals table
\$conn->exec("CREATE TABLE appeals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type VARCHAR(50) NOT NULL,
    reason TEXT NOT NULL,
    additional_info TEXT,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    reviewed_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
)");

EOT;
            $new_content = substr_replace($setup_file, $appeals_table_sql, $position, 0);
            file_put_contents('database_setup.php', $new_content);
            
            echo "<br>Database setup file updated successfully!";
        }
    } else {
        echo "Appeals table already exists.";
    }
    
    // Set success message
    $_SESSION['message'] = "Database updated successfully!";
    $_SESSION['message_type'] = "success";
} catch (PDOException $e) {
    // Set error message
    $_SESSION['message'] = "Database error: " . $e->getMessage();
    $_SESSION['message_type'] = "error";
}

// Redirect back to homepage
header("Location: ../index.php");
exit();
?>
