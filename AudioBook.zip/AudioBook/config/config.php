<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'audiobook_db');

// Application configuration
define('APP_NAME', 'AudioBook');
define('APP_URL', 'http://localhost/AudioBook');
define('UPLOAD_DIR', $_SERVER['DOCUMENT_ROOT'] . '/AudioBook/uploads/');
define('PDF_DIR', UPLOAD_DIR . 'pdf/');
define('AUDIO_DIR', UPLOAD_DIR . 'audio/');
define('COVER_DIR', UPLOAD_DIR . 'covers/');

// User roles
define('ROLE_ADMIN', 'admin');
define('ROLE_MODERATOR', 'moderator');
define('ROLE_PUBLISHER', 'publisher');
define('ROLE_USER', 'user');

// Connect to database
try {
    $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // If database doesn't exist, create it
    if($e->getCode() == 1049) {
        $conn = new PDO("mysql:host=" . DB_HOST, DB_USER, DB_PASS);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Create database
        $conn->exec("CREATE DATABASE " . DB_NAME);
        $conn->exec("USE " . DB_NAME);
        
        // Include database setup script
        require_once 'database_setup.php';
    } else {
        die("Connection failed: " . $e->getMessage());
    }
}
?>
