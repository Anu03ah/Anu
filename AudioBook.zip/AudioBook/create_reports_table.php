<?php
/**
 * Create reports table for storing user reports
 */
session_start();
require_once 'config/config.php';
require_once 'includes/functions.php';

try {
    // Check if the reports table already exists
    $stmt = $conn->prepare("SHOW TABLES LIKE 'reports'");
    $stmt->execute();
    
    if ($stmt->rowCount() == 0) {
        // Create reports table
        $conn->exec("CREATE TABLE reports (
            id INT AUTO_INCREMENT PRIMARY KEY,
            reporter_id INT NOT NULL,
            report_type ENUM('book', 'user', 'review') NOT NULL,
            target_id INT NOT NULL,
            reason VARCHAR(255) NOT NULL,
            details TEXT,
            status ENUM('pending', 'in_progress', 'resolved', 'dismissed') DEFAULT 'pending',
            resolved_by INT,
            resolution_note TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL
        )");
        
        echo "<div style='font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);'>";
        echo "<h2 style='color: #4CAF50;'>Success!</h2>";
        echo "<p>Reports table created successfully!</p>";
        
        // Add the table to database_setup.php for future installations
        $setup_file = file_get_contents('config/database_setup.php');
        $position = strrpos($setup_file, '?>');
        
        if ($position !== false) {
            $reports_table_sql = <<<EOT

// Create reports table
\$conn->exec("CREATE TABLE reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reporter_id INT NOT NULL,
    report_type ENUM('book', 'user', 'review') NOT NULL,
    target_id INT NOT NULL,
    reason VARCHAR(255) NOT NULL,
    details TEXT,
    status ENUM('pending', 'in_progress', 'resolved', 'dismissed') DEFAULT 'pending',
    resolved_by INT,
    resolution_note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL
)");

EOT;
            $new_content = substr_replace($setup_file, $reports_table_sql, $position, 0);
            file_put_contents('config/database_setup.php', $new_content);
            
            echo "<p>Database setup file updated successfully!</p>";
        }
        
        echo "<p>You can now <a href='index.php' style='color: #2196F3; text-decoration: none;'>return to the homepage</a> and start using the reporting system.</p>";
        echo "</div>";
    } else {
        echo "<div style='font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);'>";
        echo "<h2 style='color: #2196F3;'>Information</h2>";
        echo "<p>Reports table already exists.</p>";
        echo "<p>You can <a href='index.php' style='color: #2196F3; text-decoration: none;'>return to the homepage</a>.</p>";
        echo "</div>";
    }
} catch (PDOException $e) {
    echo "<div style='font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);'>";
    echo "<h2 style='color: #F44336;'>Error</h2>";
    echo "<p>Database error: " . $e->getMessage() . "</p>";
    echo "<p>You can <a href='index.php' style='color: #2196F3; text-decoration: none;'>return to the homepage</a>.</p>";
    echo "</div>";
}
?>
