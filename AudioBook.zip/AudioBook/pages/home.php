<!-- Hero Section -->
<section class="hero text-center">
    <div class="container">
        <h1 class="display-4 fw-bold mb-4">Your Digital Reading & Listening Experience</h1>
        <p class="lead mb-5">Access thousands of books in both PDF and audio formats. Read or listen anytime, anywhere.</p>
        <div class="d-flex justify-content-center gap-3">
            <a href="index.php?page=search" class="btn btn-primary btn-lg">Browse Books</a>
            <?php if (!isLoggedIn()): ?>
            <a href="index.php?page=register" class="btn btn-outline-light btn-lg">Sign Up</a>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Trending Books Section -->
<section class="mb-5">
    <div class="container">
        <div class="book-section-header">
            <h2>Trending Books</h2>
            <a href="index.php?page=search&trending=1" class="btn btn-sm btn-outline-primary view-all">View All</a>
        </div>
        
        <div class="book-grid">
            <?php
            $trendingBooks = getTrendingBooks(6);
            if (count($trendingBooks) > 0):
                foreach ($trendingBooks as $book):
            ?>
            <div class="book-item">
                <div class="modern-book-card">
                    <div class="card-img-container">
                        <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" class="card-img-top" alt="<?php echo $book['title']; ?>">
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $book['title']; ?></h5>
                        <p class="card-author"><?php echo $book['author']; ?></p>
                        
                        <div class="book-format-badges">
                            <?php if ($book['pdf_path']): ?>
                                <span class="book-format-badge bg-info"><i class="fas fa-file-pdf"></i> PDF</span>
                            <?php endif; ?>
                            
                            <?php if ($book['audio_path']): ?>
                                <span class="book-format-badge bg-warning"><i class="fas fa-headphones"></i> Audio</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="book-meta">
                            <div class="book-rating">
                                <?php
                                $rating = getAverageRating($book['id']);
                                for ($i = 1; $i <= 5; $i++) {
                                    if ($i <= $rating) {
                                        echo '<i class="fas fa-star"></i>';
                                    } elseif ($i - 0.5 <= $rating) {
                                        echo '<i class="fas fa-star-half-alt"></i>';
                                    } else {
                                        echo '<i class="far fa-star"></i>';
                                    }
                                }
                                ?>
                                <span>(<?php echo getRatingCount($book['id']); ?>)</span>
                            </div>
                            <?php if ($book['price'] > 0): ?>
                                <span class="book-price"><?php echo formatPrice($book['price']); ?></span>
                            <?php else: ?>
                                <span class="book-free">Free</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="book-actions">
                            <a href="index.php?page=book&id=<?php echo $book['id']; ?>" class="btn btn-primary btn-action">
                                <i class="fas fa-eye"></i> View
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php
                endforeach;
            else:
            ?>
            <div class="col-12">
                <div class="alert alert-info">No trending books available at the moment.</div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Free Books Section -->
<section class="mb-5 free-books-section">
    <div class="container">
        <div class="book-section-header">
            <h2>Free Books</h2>
            <a href="index.php?page=search&free=1" class="btn btn-sm btn-outline-primary view-all">View All</a>
        </div>
        
        <div class="book-grid">
            <?php
            $freeBooks = getFreeBooks(6);
            if (count($freeBooks) > 0):
                foreach ($freeBooks as $book):
            ?>
            <div class="book-item">
                <div class="modern-book-card">
                    <a href="index.php?page=book&id=<?php echo $book['id']; ?>" class="card-link">View <?php echo $book['title']; ?></a>
                    <div class="card-img-container">
                        <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" class="card-img-top" alt="<?php echo $book['title']; ?>">
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $book['title']; ?></h5>
                        <p class="card-author"><?php echo $book['author']; ?></p>
                        
                        <div class="book-format-badges">
                            <?php if ($book['pdf_path']): ?>
                                <span class="book-format-badge bg-info"><i class="fas fa-file-pdf"></i> PDF</span>
                            <?php endif; ?>
                            
                            <?php if ($book['audio_path']): ?>
                                <span class="book-format-badge bg-warning"><i class="fas fa-headphones"></i> Audio</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="book-meta">
                            <div class="book-rating">
                                <?php
                                $rating = getAverageRating($book['id']);
                                for ($i = 1; $i <= 5; $i++) {
                                    if ($i <= $rating) {
                                        echo '<i class="fas fa-star"></i>';
                                    } elseif ($i - 0.5 <= $rating) {
                                        echo '<i class="fas fa-star-half-alt"></i>';
                                    } else {
                                        echo '<i class="far fa-star"></i>';
                                    }
                                }
                                ?>
                                <span>(<?php echo getRatingCount($book['id']); ?>)</span>
                            </div>
                            <span class="book-free">Free</span>
                        </div>
                    </div>
                </div>
            </div>
            <?php
                endforeach;
            else:
            ?>
            <div class="col-12">
                <div class="alert alert-info">
                    No free books available at the moment. Check back later!
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- New Releases Section -->
<section class="mb-5">
    <div class="container">
        <div class="book-section-header">
            <h2>New Releases</h2>
            <a href="index.php?page=search&new_release=1" class="btn btn-sm btn-outline-primary view-all">View All</a>
        </div>
        
        <div class="book-grid">
            <?php
            $newReleases = getNewReleases(6);
            if (count($newReleases) > 0):
                foreach ($newReleases as $book):
            ?>
            <div class="book-item">
                <div class="modern-book-card">
                    <div class="card-img-container">
                        <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" class="card-img-top" alt="<?php echo $book['title']; ?>">
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $book['title']; ?></h5>
                        <p class="card-author"><?php echo $book['author']; ?></p>
                        
                        <div class="book-format-badges">
                            <?php if ($book['pdf_path']): ?>
                                <span class="book-format-badge bg-info"><i class="fas fa-file-pdf"></i> PDF</span>
                            <?php endif; ?>
                            
                            <?php if ($book['audio_path']): ?>
                                <span class="book-format-badge bg-warning"><i class="fas fa-headphones"></i> Audio</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="book-meta">
                            <div class="book-rating">
                                <?php
                                $rating = getAverageRating($book['id']);
                                for ($i = 1; $i <= 5; $i++) {
                                    if ($i <= $rating) {
                                        echo '<i class="fas fa-star"></i>';
                                    } elseif ($i - 0.5 <= $rating) {
                                        echo '<i class="fas fa-star-half-alt"></i>';
                                    } else {
                                        echo '<i class="far fa-star"></i>';
                                    }
                                }
                                ?>
                                <span>(<?php echo getRatingCount($book['id']); ?>)</span>
                            </div>
                            <?php if ($book['price'] > 0): ?>
                                <span class="book-price"><?php echo formatPrice($book['price']); ?></span>
                            <?php else: ?>
                                <span class="book-free">Free</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="book-actions">
                            <a href="index.php?page=book&id=<?php echo $book['id']; ?>" class="btn btn-primary btn-action">
                                <i class="fas fa-eye"></i> View
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php
                endforeach;
            else:
            ?>
            <div class="col-12">
                <div class="alert alert-info">
                    No new releases available at the moment. Check back later!
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="bg-light py-5 mb-5">
    <div class="container">
        <h2 class="text-center mb-5">Why Choose <?php echo APP_NAME; ?>?</h2>
        
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="display-4 text-primary mb-3">
                            <i class="fas fa-book"></i>
                        </div>
                        <h4>Extensive Library</h4>
                        <p class="text-muted">Access thousands of books across various genres and categories.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="display-4 text-primary mb-3">
                            <i class="fas fa-headphones"></i>
                        </div>
                        <h4>Audio & PDF Formats</h4>
                        <p class="text-muted">Choose between reading or listening to your favorite books.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="display-4 text-primary mb-3">
                            <i class="fas fa-bookmark"></i>
                        </div>
                        <h4>Smart Bookmarking</h4>
                        <p class="text-muted">Never lose your place with our automatic bookmarking system.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="mb-5">
    <div class="container">
        <div class="card bg-primary text-white">
            <div class="card-body p-5 text-center">
                <h2 class="mb-3">Ready to start your reading journey?</h2>
                <p class="lead mb-4">Join thousands of readers and listeners today.</p>
                <?php if (!isLoggedIn()): ?>
                <div class="d-flex justify-content-center gap-3">
                    <a href="index.php?page=register" class="btn btn-light btn-lg">Sign Up Now</a>
                    <a href="index.php?page=login" class="btn btn-outline-light btn-lg">Login</a>
                </div>
                <?php else: ?>
                <a href="index.php?page=search" class="btn btn-light btn-lg">Browse Books</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
