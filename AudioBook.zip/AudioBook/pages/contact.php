<?php
/**
 * Contact page with support for account block appeals
 */
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h2 class="mb-0">Contact Support</h2>
                </div>
                <div class="card-body">
                    <?php if (isset($_GET['appeal']) && $_GET['appeal'] === 'block'): ?>
                    <!-- Block Appeal Form -->
                    <div class="alert alert-info mb-4">
                        <p class="mb-0"><i class="fas fa-info-circle me-2"></i> Please provide details about your account block appeal. Our team will review your request and respond within 24-48 hours.</p>
                    </div>
                    
                    <form action="actions/submit_appeal.php" method="post">
                        <input type="hidden" name="appeal_type" value="block">
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo isset($_GET['email']) ? htmlspecialchars($_GET['email']) : ''; ?>" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Full Name</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="reason" class="form-label">Why should we unblock your account?</label>
                            <textarea class="form-control" id="reason" name="reason" rows="5" placeholder="Please explain why you believe your account should be unblocked..." required></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="additional" class="form-label">Additional Information (Optional)</label>
                            <textarea class="form-control" id="additional" name="additional" rows="3" placeholder="Any additional information that might help us with your appeal..."></textarea>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Submit Appeal</button>
                        </div>
                    </form>
                    
                    <?php else: ?>
                    <!-- Regular Contact Form -->
                    <form action="actions/submit_contact.php" method="post">
                        <div class="mb-3">
                            <label for="name" class="form-label">Full Name</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="subject" class="form-label">Subject</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-heading"></i></span>
                                <input type="text" class="form-control" id="subject" name="subject" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="message" class="form-label">Message</label>
                            <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Send Message</button>
                        </div>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
