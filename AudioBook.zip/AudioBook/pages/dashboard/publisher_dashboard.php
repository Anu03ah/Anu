<?php
// Get publisher's books
$publisherBooks = getPublisherBooks($_SESSION['user_id']);
?>

<h2 class="mb-4">Publisher Dashboard</h2>

<div class="row mb-4">
    <div class="col-md-4">
        <div class="card dashboard-card">
            <div class="card-body text-center">
                <i class="fas fa-book fa-3x mb-3 text-primary"></i>
                <h5 class="card-title">Total Books</h5>
                <p class="card-text display-6"><?php echo count($publisherBooks); ?></p>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card dashboard-card">
            <div class="card-body text-center">
                <i class="fas fa-shopping-cart fa-3x mb-3 text-success"></i>
                <h5 class="card-title">Total Sales</h5>
                <p class="card-text display-6"><?php echo getPublisherTotalSales($_SESSION['user_id']); ?></p>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card dashboard-card">
            <div class="card-body text-center">
                <i class="fas fa-rupee-sign fa-3x mb-3 text-warning"></i>
                <h5 class="card-title">Revenue</h5>
                <p class="card-text display-6">₹<?php echo number_format(getPublisherRevenue($_SESSION['user_id']), 2); ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Upload New Book Section -->
<div class="card mb-4">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Upload New Book</h5>
        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#uploadBookForm" aria-expanded="false" aria-controls="uploadBookForm">
            <i class="fas fa-plus me-1"></i> New Book
        </button>
    </div>
    <div class="collapse" id="uploadBookForm">
        <div class="card-body">
            <form action="actions/upload_book.php" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="title" class="form-label">Book Title</label>
                            <input type="text" class="form-control" id="title" name="title" required>
                            <div class="invalid-feedback">
                                Please enter a book title.
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="author" class="form-label">Author</label>
                            <input type="text" class="form-control" id="author" name="author" required>
                            <div class="invalid-feedback">
                                Please enter the author's name.
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="category" class="form-label">Category</label>
                            <select class="form-select" id="category" name="category" required>
                                <option value="">Select a category</option>
                                <option value="Fiction">Fiction</option>
                                <option value="Non-Fiction">Non-Fiction</option>
                                <option value="Science Fiction">Science Fiction</option>
                                <option value="Fantasy">Fantasy</option>
                                <option value="Mystery">Mystery</option>
                                <option value="Romance">Romance</option>
                                <option value="Thriller">Thriller</option>
                                <option value="Biography">Biography</option>
                                <option value="History">History</option>
                                <option value="Self-Help">Self-Help</option>
                                <option value="Business">Business</option>
                                <option value="Children">Children</option>
                                <option value="Young Adult">Young Adult</option>
                                <option value="Other">Other</option>
                            </select>
                            <div class="invalid-feedback">
                                Please select a category.
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="price" class="form-label">Price (₹)</label>
                            <input type="number" class="form-control" id="price" name="price" min="0" step="0.01" required>
                            <div class="invalid-feedback">
                                Please enter a valid price.
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="description" class="form-label">Book Description</label>
                            <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
                            <div class="invalid-feedback">
                                Please enter a book description.
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="cover" class="form-label">Cover Image</label>
                            <input type="file" class="form-control" id="cover" name="cover" accept="image/*" onchange="previewCover(this)" required>
                            <div class="invalid-feedback">
                                Please upload a cover image.
                            </div>
                            <div id="cover-preview-container" class="mt-2" style="display: none;">
                                <img id="cover-preview" src="#" alt="Cover Preview" class="img-thumbnail" style="max-height: 200px;">
                            </div>
                        </div>
                    </div>
                </div>
                
                <hr>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="pdf_file" class="form-label">PDF File</label>
                            <input type="file" class="form-control" id="pdf_file" name="pdf_file" accept=".pdf">
                            <div class="form-text">Upload a PDF version of your book (optional if you're uploading audio).</div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="audio_file" class="form-label">Audio File</label>
                            <input type="file" class="form-control" id="audio_file" name="audio_file" accept=".mp3,.wav">
                            <div class="form-text">Upload an audio version of your book (optional if you're uploading PDF).</div>
                        </div>
                    </div>
                </div>
                
                <div class="alert alert-warning">
                    <strong>Note:</strong> You must upload at least one format (PDF or Audio) for your book.
                </div>
                
                <hr>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="preview_enabled" name="preview_enabled">
                            <label class="form-check-label" for="preview_enabled">Enable Preview</label>
                            <div class="form-text">Allow users to preview the first few pages or first minute of audio before purchasing.</div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="download_allowed" name="download_allowed" onchange="toggleAgreement(this)">
                            <label class="form-check-label" for="download_allowed">Allow Downloads</label>
                            <div class="form-text">Allow users to download the book after purchase.</div>
                        </div>
                    </div>
                </div>
                
                <div id="download-agreement" style="display: none;">
                    <div class="alert alert-danger">
                        <h6>Download Permission Agreement</h6>
                        <p>By enabling downloads for your book, you acknowledge the following:</p>
                        <ol>
                            <li>You understand that allowing downloads increases the risk of unauthorized distribution (piracy).</li>
                            <li>You accept full responsibility for any piracy or unauthorized distribution of your content.</li>
                            <li>AudioBook platform will not be held liable for any piracy or unauthorized distribution of your content.</li>
                        </ol>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="terms_signed" name="terms_signed">
                            <label class="form-check-label" for="terms_signed">I agree to these terms</label>
                            <div class="invalid-feedback">
                                You must agree to the terms to allow downloads.
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="button" class="btn btn-secondary" data-bs-toggle="collapse" data-bs-target="#uploadBookForm">Cancel</button>
                    <button type="submit" class="btn btn-primary">Upload Book</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- My Published Books Section -->
<div class="card mb-4" id="my-books">
    <div class="card-header bg-white">
        <h5 class="mb-0">My Published Books</h5>
    </div>
    <div class="card-body">
        <?php if (count($publisherBooks) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Cover</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Sales</th>
                            <th>Revenue</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($publisherBooks as $book): ?>
                        <tr>
                            <td>
                                <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" alt="<?php echo $book['title']; ?>" class="img-thumbnail" style="width: 50px;">
                            </td>
                            <td><?php echo $book['title']; ?></td>
                            <td><?php echo $book['category']; ?></td>
                            <td>
                                <?php if ($book['price'] > 0): ?>
                                ₹<?php echo number_format($book['price'], 2); ?>
                                <?php else: ?>
                                <span class="badge bg-success">Free</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo getBookSales($book['id']); ?></td>
                            <td>₹<?php echo number_format(getBookRevenue($book['id']), 2); ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="index.php?page=book&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-primary" data-bs-toggle="tooltip" title="View Book">
                                        <i class="fas fa-eye" style="font-size: 1.4rem;"></i>
                                    </a>
                                    <a href="index.php?page=edit_book&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-secondary" data-bs-toggle="tooltip" title="Edit Book">
                                        <i class="fas fa-edit" style="font-size: 1.4rem;"></i>
                                    </a>
                                    <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteBookModal<?php echo $book['id']; ?>" data-bs-toggle="tooltip" title="Delete Book">
                                        <i class="fas fa-trash-alt" style="font-size: 1.4rem;"></i>
                                    </button>
                                </div>
                                
                                <!-- Delete Book Modal -->
                                <div class="modal fade" id="deleteBookModal<?php echo $book['id']; ?>" tabindex="-1" aria-labelledby="deleteBookModalLabel<?php echo $book['id']; ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="deleteBookModalLabel<?php echo $book['id']; ?>">Confirm Deletion</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Are you sure you want to delete "<?php echo $book['title']; ?>"?</p>
                                                <p class="text-danger">This action cannot be undone.</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <a href="actions/remove_book.php?id=<?php echo $book['id']; ?>" class="btn btn-danger">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <p>You haven't published any books yet. Use the "Upload New Book" button to get started.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Sales Statistics Section -->
<div class="card mb-4" id="sales-stats">
    <div class="card-header bg-white">
        <h5 class="mb-0">Sales Statistics</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <canvas id="monthlySalesChart"></canvas>
            </div>
            <div class="col-md-6">
                <canvas id="categoryDistributionChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- User Library Section -->
<div class="card mb-4">
    <div class="card-header bg-white">
        <h5 class="mb-0">My Library</h5>
    </div>
    <div class="card-body">
        <?php
        $purchasedBooks = getPurchasedBooks($_SESSION['user_id']);
        if (count($purchasedBooks) > 0):
        ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Cover</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Format</th>
                            <th>Progress</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($purchasedBooks as $book): ?>
                        <tr>
                            <td>
                                <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" alt="<?php echo $book['title']; ?>" class="img-thumbnail" style="width: 50px;">
                            </td>
                            <td><?php echo $book['title']; ?></td>
                            <td><?php echo $book['author']; ?></td>
                            <td>
                                <?php if ($book['pdf_path']): ?>
                                <span class="badge bg-info"><i class="fas fa-file-pdf me-1" style="font-size: 1.4rem;"></i> PDF</span>
                                <?php endif; ?>
                                
                                <?php if ($book['audio_path']): ?>
                                <span class="badge bg-warning"><i class="fas fa-headphones me-1" style="font-size: 1.4rem;"></i> Audio</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                // Get bookmark if exists
                                $bookmark = getBookmark($_SESSION['user_id'], $book['id']);
                                if ($bookmark):
                                ?>
                                <small>
                                    <?php if ($bookmark['last_read_page']): ?>
                                    <span class="badge bg-light text-dark"><i class="fas fa-bookmark me-1"></i> Page <?php echo $bookmark['last_read_page']; ?></span>
                                    <?php endif; ?>
                                    
                                    <?php if ($bookmark['last_listen_position']): ?>
                                    <span class="badge bg-light text-dark"><i class="fas fa-headphones me-1"></i> 
                                    <?php 
                                    $minutes = floor($bookmark['last_listen_position'] / 60);
                                    $seconds = $bookmark['last_listen_position'] % 60;
                                    echo $minutes . ':' . ($seconds < 10 ? '0' : '') . $seconds;
                                    ?>
                                    </span>
                                    <?php endif; ?>
                                </small>
                                <?php else: ?>
                                <span class="text-muted">Not started</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="index.php?page=book&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-primary" data-bs-toggle="tooltip" title="View Book">
                                        <i class="fas fa-eye" style="font-size: 1.4rem;"></i>
                                    </a>
                                    
                                    <?php if ($book['pdf_path']): ?>
                                    <a href="index.php?page=read&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-success" data-bs-toggle="tooltip" title="Read Book">
                                        <i class="fas fa-book-reader" style="font-size: 1.4rem;"></i>
                                    </a>
                                    <?php endif; ?>
                                    
                                    <?php if ($book['audio_path']): ?>
                                    <a href="index.php?page=listen&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-warning" data-bs-toggle="tooltip" title="Listen to Book">
                                        <i class="fas fa-headphones" style="font-size: 1.4rem;"></i>
                                    </a>
                                    <?php endif; ?>
                                    
                                    <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#removeBookModal<?php echo $book['id']; ?>" title="Remove from Library">
                                        <i class="fas fa-trash-alt" style="font-size: 1.4rem;"></i>
                                    </button>
                                </div>
                                
                                <!-- Remove Book Modal -->
                                <div class="modal fade" id="removeBookModal<?php echo $book['id']; ?>" tabindex="-1" aria-labelledby="removeBookModalLabel<?php echo $book['id']; ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="removeBookModalLabel<?php echo $book['id']; ?>">Confirm Removal</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="alert alert-warning">
                                                    <i class="fas fa-exclamation-triangle me-2"></i> Warning
                                                </div>
                                                <p>Are you sure you want to remove <strong><?php echo $book['title']; ?></strong> from your library?</p>
                                                <p class="text-danger"><strong>This action cannot be undone.</strong> If you want to access this book again in the future, you will need to purchase it again.</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <form action="actions/remove_from_library.php" method="post">
                                                    <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
                                                    <button type="submit" class="btn btn-danger">Remove Book</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <p>You haven't purchased any books yet.</p>
                <a href="index.php?page=search" class="btn btn-primary mt-2">Browse Books</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Function to toggle the download agreement section
function toggleAgreement(checkbox) {
    const agreementSection = document.getElementById('download-agreement');
    if (checkbox.checked) {
        agreementSection.style.display = 'block';
    } else {
        agreementSection.style.display = 'none';
        // Uncheck the terms agreement checkbox when download is disabled
        document.getElementById('terms_signed').checked = false;
    }
}

// Function to preview cover image
function previewCover(input) {
    const previewContainer = document.getElementById('cover-preview-container');
    const preview = document.getElementById('cover-preview');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            preview.src = e.target.result;
            previewContainer.style.display = 'block';
        }
        
        reader.readAsDataURL(input.files[0]);
    } else {
        previewContainer.style.display = 'none';
    }
}
</script>
