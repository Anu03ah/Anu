<h2 class="mb-4">Moderator Dashboard</h2>

<div class="row mb-4">
    <div class="col-md-3">
        <div class="card dashboard-card">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <div class="dashboard-icon me-3">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <div>
                        <h5 class="card-title mb-0">Moderator Account</h5>
                        <p class="text-muted mb-0"><?php echo $_SESSION['user_name']; ?></p>
                    </div>
                </div>
                <a href="index.php?page=profile" class="btn btn-outline-primary btn-sm">Edit Profile</a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card dashboard-card">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <div class="dashboard-icon me-3">
                        <i class="fas fa-exclamation-circle"></i>
                    </div>
                    <div>
                        <?php
                        $pendingComplaints = getPendingComplaints();
                        $complaintCount = count($pendingComplaints);
                        ?>
                        <h5 class="card-title mb-0"><?php echo $complaintCount; ?> Complaints</h5>
                        <p class="text-muted mb-0">Pending Resolution</p>
                    </div>
                </div>
                <a href="#complaints" class="btn btn-outline-primary btn-sm">View Complaints</a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card dashboard-card">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <div class="dashboard-icon me-3">
                        <i class="fas fa-id-card"></i>
                    </div>
                    <div>
                        <?php
                        $pendingPublisherLicenses = getPendingLicenses('publisher');
                        $licenseCount = count($pendingPublisherLicenses);
                        ?>
                        <h5 class="card-title mb-0"><?php echo $licenseCount; ?> Applications</h5>
                        <p class="text-muted mb-0">Publisher Licenses</p>
                    </div>
                </div>
                <a href="#licenses" class="btn btn-outline-primary btn-sm">View Applications</a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card dashboard-card">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <div class="dashboard-icon me-3">
                        <i class="fas fa-unlock-alt"></i>
                    </div>
                    <div>
                        <?php
                        $userAppeals = getPendingAppeals('non_moderator');
                        $appealCount = count($userAppeals);
                        ?>
                        <h5 class="card-title mb-0"><?php echo $appealCount; ?> Appeals</h5>
                        <p class="text-muted mb-0">Account Unblock</p>
                    </div>
                </div>
                <a href="#appeals" class="btn btn-outline-primary btn-sm">View Appeals</a>
            </div>
        </div>
    </div>
</div>

<!-- Unblock Appeals Section for Users and Publishers -->
<div class="card mb-4" id="appeals">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Unblock Appeals</h5>
        <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" data-bs-target="#appealsCollapse" aria-expanded="true" aria-controls="appealsCollapse">
            <i class="fas fa-chevron-down"></i>
        </button>
    </div>
    <div class="collapse show" id="appealsCollapse">
        <div class="card-body">
            <?php
            // Get pending appeals from users and publishers (non-moderators)
            $userAppeals = getPendingAppeals('non_moderator');
            
            if (count($userAppeals) > 0):
            ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Role</th>
                                <th>Date Submitted</th>
                                <th>Type</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($userAppeals as $appeal): ?>
                            <tr>
                                <td>
                                    <div>
                                        <strong><?php echo $appeal['name']; ?></strong>
                                    </div>
                                    <small class="text-muted"><?php echo $appeal['email']; ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo ($appeal['role'] == 'publisher') ? 'info' : 'secondary'; ?>">
                                        <?php echo ucfirst($appeal['role']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y H:i', strtotime($appeal['created_at'])); ?></td>
                                <td><span class="badge bg-secondary"><?php echo ucfirst($appeal['type']); ?></span></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#viewAppealModal<?php echo $appeal['id']; ?>">
                                        <i class="fas fa-eye" style="font-size: 1.4rem;"></i> View
                                    </button>
                                    
                                    <!-- View Appeal Modal -->
                                    <div class="modal fade" id="viewAppealModal<?php echo $appeal['id']; ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header bg-primary text-white">
                                                    <h5 class="modal-title">
                                                        <i class="fas fa-unlock-alt me-2" style="font-size: 1.4rem;"></i>
                                                        Account Unblock Appeal
                                                    </h5>
                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row mb-4">
                                                        <div class="col-md-6">
                                                            <h6 class="fw-bold">User Information</h6>
                                                            <div class="mb-2">
                                                                <strong>Name:</strong> <?php echo $appeal['name']; ?>
                                                            </div>
                                                            <div class="mb-2">
                                                                <strong>Email:</strong> <?php echo $appeal['email']; ?>
                                                            </div>
                                                            <div>
                                                                <strong>Role:</strong> <?php echo ucfirst($appeal['role']); ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <h6 class="fw-bold">Appeal Information</h6>
                                                            <div class="mb-2">
                                                                <strong>Submitted:</strong> <?php echo date('F d, Y H:i', strtotime($appeal['created_at'])); ?>
                                                            </div>
                                                            <div>
                                                                <strong>Appeal Type:</strong> <?php echo ucfirst($appeal['type']); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="mb-4">
                                                        <h6 class="fw-bold">Appeal Reason</h6>
                                                        <div class="p-3 bg-light rounded">
                                                            <?php echo nl2br($appeal['reason']); ?>
                                                        </div>
                                                    </div>
                                                    
                                                    <?php if (!empty($appeal['additional_info'])): ?>
                                                    <div class="mb-4">
                                                        <h6 class="fw-bold">Additional Information</h6>
                                                        <div class="p-3 bg-light rounded">
                                                            <?php echo nl2br($appeal['additional_info']); ?>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                    
                                                    <form action="actions/process_appeal.php" method="post">
                                                        <input type="hidden" name="appeal_id" value="<?php echo $appeal['id']; ?>">
                                                        
                                                        <div class="mb-3">
                                                            <label for="response<?php echo $appeal['id']; ?>" class="form-label">Response Message (Optional)</label>
                                                            <textarea class="form-control" id="response<?php echo $appeal['id']; ?>" name="response" rows="3" placeholder="Enter a message to send to the user..."></textarea>
                                                            <div class="form-text">This message will be included in the notification sent to the user.</div>
                                                        </div>
                                                        
                                                        <div class="d-flex justify-content-end gap-2">
                                                            <button type="submit" name="action" value="reject" class="btn btn-danger">
                                                                <i class="fas fa-times-circle me-2"></i> Reject Appeal
                                                            </button>
                                                            <button type="submit" name="action" value="approve" class="btn btn-success">
                                                                <i class="fas fa-check-circle me-2"></i> Approve & Unblock
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <p class="mb-0"><i class="fas fa-info-circle me-2" style="font-size: 1.4rem;"></i> No pending unblock appeals from users or publishers at the moment.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Reports Section -->
<div class="card mb-4" id="reports">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Reports</h5>
    </div>
    <div class="card-body">
                <?php 
                // Get pending reports
                $pendingReports = getPendingReports();
                
                if (count($pendingReports) > 0): 
                ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>Reported By</th>
                                    <th>Reported Item</th>
                                    <th>Reason</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pendingReports as $report): ?>
                                <tr>
                                    <td>
                                        <?php if ($report['report_type'] === 'book'): ?>
                                            <span class="badge bg-primary">Book</span>
                                        <?php elseif ($report['report_type'] === 'user'): ?>
                                            <span class="badge bg-warning">User</span>
                                        <?php elseif ($report['report_type'] === 'review'): ?>
                                            <span class="badge bg-info">Review</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo htmlspecialchars($report['target_name'] ?? 'Unknown'); ?>
                                        <?php if (isset($report['target_link'])): ?>
                                            <a href="<?php echo $report['target_link']; ?>" class="ms-1" target="_blank"><i class="fas fa-external-link-alt small"></i></a>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($report['reporter_name']); ?></td>
                                    <td>
                                        <?php if ($report['status'] === 'pending'): ?>
                                            <span class="badge bg-secondary">Pending</span>
                                        <?php elseif ($report['status'] === 'in_progress'): ?>
                                            <span class="badge bg-primary">In Progress</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($report['created_at'])); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#reportModal<?php echo $report['id']; ?>">
                                            <i class="fas fa-eye" style="font-size: 1.4rem;"></i> View
                                        </button>
                                        
                                        <!-- Report View Modal -->
                                        <div class="modal fade" id="reportModal<?php echo $report['id']; ?>" tabindex="-1" aria-labelledby="reportModalLabel<?php echo $report['id']; ?>" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="reportModalLabel<?php echo $report['id']; ?>">
                                                            Report #<?php echo $report['id']; ?> - 
                                                            <?php if ($report['report_type'] === 'book'): ?>Book Report
                                                            <?php elseif ($report['report_type'] === 'user'): ?>User Report
                                                            <?php elseif ($report['report_type'] === 'review'): ?>Review Report
                                                            <?php endif; ?>
                                                        </h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <h6 class="fw-bold">Report Information</h6>
                                                                <p><strong>Reported by:</strong> <?php echo htmlspecialchars($report['reporter_name']); ?> (<?php echo htmlspecialchars($report['reporter_email']); ?>)</p>
                                                                <p><strong>Date Reported:</strong> <?php echo date('F d, Y h:i A', strtotime($report['created_at'])); ?></p>
                                                                <p><strong>Status:</strong> 
                                                                    <?php if ($report['status'] === 'pending'): ?>
                                                                        <span class="badge bg-secondary">Pending</span>
                                                                    <?php elseif ($report['status'] === 'in_progress'): ?>
                                                                        <span class="badge bg-primary">In Progress</span>
                                                                    <?php endif; ?>
                                                                </p>
                                                                <p><strong>Reason:</strong> <?php echo htmlspecialchars($report['reason']); ?></p>
                                                                <?php if (!empty($report['details'])): ?>
                                                                    <p><strong>Additional Details:</strong> <?php echo nl2br(htmlspecialchars($report['details'])); ?></p>
                                                                <?php endif; ?>
                                                            </div>
                                                            
                                                            <div class="col-md-6">
                                                                <h6 class="fw-bold">Reported Item Details</h6>
                                                                <?php if ($report['report_type'] === 'book'): ?>
                                                                    <p><strong>Book Title:</strong> <?php echo htmlspecialchars($report['target_name']); ?></p>
                                                                    <p><strong>Details:</strong> <?php echo htmlspecialchars($report['target_details']); ?></p>
                                                                    <?php if (isset($report['target_link'])): ?>
                                                                        <p><a href="<?php echo $report['target_link']; ?>" class="btn btn-sm btn-outline-primary" target="_blank"><i class="fas fa-book"></i> View Book</a></p>
                                                                    <?php endif; ?>
                                                                    
                                                                <?php elseif ($report['report_type'] === 'user'): ?>
                                                                    <p><strong>User:</strong> <?php echo htmlspecialchars($report['target_name']); ?></p>
                                                                    <p><strong>Details:</strong> <?php echo htmlspecialchars($report['target_details']); ?></p>
                                                                    <?php if (isset($report['target_link'])): ?>
                                                                        <p><a href="<?php echo $report['target_link']; ?>" class="btn btn-sm btn-outline-primary" target="_blank"><i class="fas fa-user"></i> View User</a></p>
                                                                    <?php endif; ?>
                                                                    
                                                                <?php elseif ($report['report_type'] === 'review'): ?>
                                                                    <p><strong>Review:</strong> <?php echo isset($report['target_name']) ? htmlspecialchars($report['target_name']) : 'Review information unavailable'; ?></p>
                                                                    <p><strong>Details:</strong> <?php echo isset($report['target_details']) ? htmlspecialchars($report['target_details']) : 'Details unavailable (review may have been deleted)'; ?></p>
                                                                    <?php if (isset($report['review_content'])): ?>
                                                                        <div class="card mb-3">
                                                                            <div class="card-header bg-light">Review Content</div>
                                                                            <div class="card-body">
                                                                                <p class="mb-0"><?php echo nl2br(htmlspecialchars($report['review_content'])); ?></p>
                                                                            </div>
                                                                        </div>
                                                                    <?php else: ?>
                                                                        <div class="alert alert-info">
                                                                            <p class="mb-0">Review content is no longer available. The review may have been deleted.</p>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <?php if (isset($report['target_link'])): ?>
                                                                        <p><a href="<?php echo $report['target_link']; ?>" class="btn btn-sm btn-outline-primary" target="_blank"><i class="fas fa-book"></i> View Book</a></p>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Action Section -->
                                                    <div class="border-top pt-4 mt-4 px-3 pb-3">
                                                        <h5 class="mb-3">Available Actions</h5>
                                                        
                                                        <!-- Action Buttons -->
                                                        <div class="mb-4 p-3 bg-light rounded">
                                                            <div class="d-flex flex-wrap gap-3">
                                                                <?php if ($report['status'] === 'pending'): ?>
                                                                    <button type="button" class="btn btn-outline-primary action-btn" data-action="in-progress" data-report-id="<?php echo $report['id']; ?>">
                                                                        <i class="fas fa-hourglass-half me-2" style="font-size: 1.4rem;"></i> Mark In Progress
                                                                    </button>
                                                                <?php endif; ?>
                                                                <button type="button" class="btn btn-outline-success action-btn" data-action="resolve" data-report-id="<?php echo $report['id']; ?>">
                                                                    <i class="fas fa-check-circle me-2" style="font-size: 1.4rem;"></i> Resolve
                                                                </button>
                                                                <button type="button" class="btn btn-outline-danger action-btn" data-action="dismiss" data-report-id="<?php echo $report['id']; ?>">
                                                                    <i class="fas fa-times-circle me-2" style="font-size: 1.4rem;"></i> Dismiss
                                                                </button>
                                                                
                                                                <?php if ($report['report_type'] === 'book'): ?>
                                                                <button type="button" class="btn btn-outline-danger action-btn" data-action="remove-book" data-report-id="<?php echo $report['id']; ?>">
                                                                    <i class="fas fa-trash-alt me-2" style="font-size: 1.4rem;"></i> Remove Book
                                                                </button>
                                                                <?php elseif ($report['report_type'] === 'user'): ?>
                                                                <button type="button" class="btn btn-outline-danger action-btn" data-action="block-user" data-report-id="<?php echo $report['id']; ?>">
                                                                    <i class="fas fa-ban me-2" style="font-size: 1.4rem;"></i> Block User
                                                                </button>
                                                                <?php elseif ($report['report_type'] === 'review'): ?>
                                                                <button type="button" class="btn btn-outline-danger action-btn" data-action="remove-review" data-report-id="<?php echo $report['id']; ?>">
                                                                    <i class="fas fa-trash-alt me-2" style="font-size: 1.4rem;"></i> Remove Review
                                                                </button>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        
                                                        <!-- Action Forms Container -->
                                                        <div id="actionForms<?php echo $report['id']; ?>" class="action-forms-container">
                                                            <!-- In Progress Form -->
                                                            <div class="action-form" id="inProgressForm<?php echo $report['id']; ?>" style="display: none;">
                                                                <div class="p-3 border rounded mb-3">
                                                                    <h6 class="mb-3"><i class="fas fa-hourglass-half me-2"></i> Mark as In Progress</h6>
                                                                    <form action="actions/process_report.php" method="POST">
                                                                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                                        <input type="hidden" name="action" value="in_progress">
                                                                        <div class="mb-3">
                                                                            <label for="note<?php echo $report['id']; ?>" class="form-label">Internal Note (Optional)</label>
                                                                            <textarea class="form-control" id="note<?php echo $report['id']; ?>" name="note" rows="3" placeholder="Add any notes about your investigation..."></textarea>
                                                                        </div>
                                                                        <div class="d-flex justify-content-end gap-2">
                                                                            <button type="button" class="btn btn-sm btn-secondary cancel-action" data-report-id="<?php echo $report['id']; ?>">Cancel</button>
                                                                            <button type="submit" class="btn btn-sm btn-primary">Submit</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                            
                                                            <!-- Resolve Form -->
                                                            <div class="action-form" id="resolveForm<?php echo $report['id']; ?>" style="display: none;">
                                                                <div class="p-3 border rounded mb-3">
                                                                    <h6 class="mb-3"><i class="fas fa-check-circle me-2"></i> Resolve Report</h6>
                                                                    <form action="actions/process_report.php" method="POST">
                                                                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                                        <input type="hidden" name="action" value="resolve">
                                                                        <div class="mb-3">
                                                                            <label for="resolution_note<?php echo $report['id']; ?>" class="form-label">Resolution Note</label>
                                                                            <textarea class="form-control" id="resolution_note<?php echo $report['id']; ?>" name="resolution_note" rows="3" placeholder="Explain how this report was resolved..." required></textarea>
                                                                        </div>
                                                                        <div class="mb-3">
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="checkbox" id="notify_reporter<?php echo $report['id']; ?>" name="notify_reporter" value="1" checked>
                                                                                <label class="form-check-label" for="notify_reporter<?php echo $report['id']; ?>">
                                                                                    Notify reporter about resolution
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="d-flex justify-content-end gap-2">
                                                                            <button type="button" class="btn btn-sm btn-secondary cancel-action" data-report-id="<?php echo $report['id']; ?>">Cancel</button>
                                                                            <button type="submit" class="btn btn-sm btn-success">Submit</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                            
                                                            <!-- Dismiss Form -->
                                                            <div class="action-form" id="dismissForm<?php echo $report['id']; ?>" style="display: none;">
                                                                <div class="p-3 border rounded mb-3">
                                                                    <h6 class="mb-3"><i class="fas fa-times-circle me-2"></i> Dismiss Report</h6>
                                                                    <form action="actions/process_report.php" method="POST">
                                                                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                                        <input type="hidden" name="action" value="dismiss">
                                                                        <div class="mb-3">
                                                                            <label for="dismiss_reason<?php echo $report['id']; ?>" class="form-label">Reason for Dismissal</label>
                                                                            <textarea class="form-control" id="dismiss_reason<?php echo $report['id']; ?>" name="dismiss_reason" rows="3" placeholder="Explain why this report is being dismissed..." required></textarea>
                                                                        </div>
                                                                        <div class="mb-3">
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="checkbox" id="notify_reporter_dismiss<?php echo $report['id']; ?>" name="notify_reporter" value="1" checked>
                                                                                <label class="form-check-label" for="notify_reporter_dismiss<?php echo $report['id']; ?>">
                                                                                    Notify reporter about dismissal
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="d-flex justify-content-end gap-2">
                                                                            <button type="button" class="btn btn-sm btn-secondary cancel-action" data-report-id="<?php echo $report['id']; ?>">Cancel</button>
                                                                            <button type="submit" class="btn btn-sm btn-danger">Submit</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                            
                                                            <!-- Remove Book Form -->
                                                            <?php if ($report['report_type'] === 'book'): ?>
                                                            <div class="action-form" id="removeBookForm<?php echo $report['id']; ?>" style="display: none;">
                                                                <div class="p-3 border rounded mb-3 border-danger">
                                                                    <h6 class="mb-3 text-danger"><i class="fas fa-trash-alt me-2"></i> Remove Book</h6>
                                                                    <form action="actions/process_report.php" method="POST">
                                                                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                                        <input type="hidden" name="action" value="remove_book">
                                                                        <input type="hidden" name="target_id" value="<?php echo $report['target_id']; ?>">
                                                                        <div class="alert alert-warning">
                                                                            <p><strong>Notice:</strong> You are about to remove the book "<?php echo htmlspecialchars($report['target_name']); ?>".</p>
                                                                            <p>The book will be deleted and the publisher will be notified with your reason.</p>
                                                                        </div>
                                                                        <div class="mb-3">
                                                                            <label for="removal_reason<?php echo $report['id']; ?>" class="form-label">Reason for Removal</label>
                                                                            <textarea class="form-control" id="removal_reason<?php echo $report['id']; ?>" name="removal_reason" rows="3" placeholder="Explain why this book is being removed..." required></textarea>
                                                                        </div>
                                                                        <!-- Hidden input to ensure notification is sent -->
                                                                        <input type="hidden" name="notify_publisher" value="1">
                                                                        <!-- Hidden input to ensure confirmation is always set -->
                                                                        <input type="hidden" name="confirm_removal" value="1">
                                                                        <div class="d-flex justify-content-end gap-2">
                                                                            <button type="button" class="btn btn-sm btn-secondary cancel-action" data-report-id="<?php echo $report['id']; ?>">Cancel</button>
                                                                            <button type="submit" class="btn btn-sm btn-danger">Remove Book</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                            <?php endif; ?>
                                                            
                                                            <!-- Block User Form -->
                                                            <?php if ($report['report_type'] === 'user'): ?>
                                                            <div class="action-form" id="blockUserForm<?php echo $report['id']; ?>" style="display: none;">
                                                                <div class="p-3 border rounded mb-3 border-danger">
                                                                    <h6 class="mb-3 text-danger"><i class="fas fa-ban me-2"></i> Block User</h6>
                                                                    <form action="actions/process_report.php" method="POST">
                                                                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                                        <input type="hidden" name="action" value="block_user">
                                                                        <input type="hidden" name="target_id" value="<?php echo $report['target_id']; ?>">
                                                                        <div class="alert alert-warning">
                                                                            <p><strong>Notice:</strong> You are about to block the user "<?php echo htmlspecialchars($report['target_name']); ?>".</p>
                                                                            <p>The user will be blocked and notified with your reason.</p>
                                                                        </div>
                                                                        <!-- Block is always permanent until manually unblocked -->
                                                                        <input type="hidden" name="block_duration" value="permanent">
                                                                        <div class="mb-3">
                                                                            <label for="block_reason<?php echo $report['id']; ?>" class="form-label">Reason for Block</label>
                                                                            <textarea class="form-control" id="block_reason<?php echo $report['id']; ?>" name="block_reason" rows="3" placeholder="Explain why this user is being blocked..." required></textarea>
                                                                        </div>
                                                                        <!-- Hidden input to ensure notification is sent -->
                                                                        <input type="hidden" name="notify_user" value="1">
                                                                        <!-- Hidden input to ensure confirmation is always set -->
                                                                        <input type="hidden" name="confirm_block" value="1">
                                                                        <div class="d-flex justify-content-end gap-2">
                                                                            <button type="button" class="btn btn-sm btn-secondary cancel-action" data-report-id="<?php echo $report['id']; ?>">Cancel</button>
                                                                            <button type="submit" class="btn btn-sm btn-danger">Block User</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                            <?php endif; ?>
                                                            
                                                            <!-- Remove Review Form -->
                                                            <?php if ($report['report_type'] === 'review'): ?>
                                                            <div class="action-form" id="removeReviewForm<?php echo $report['id']; ?>" style="display: none;">
                                                                <div class="p-3 border rounded mb-3 border-danger">
                                                                    <h6 class="mb-3 text-danger"><i class="fas fa-trash-alt me-2"></i> Remove Review</h6>
                                                                    <form action="actions/process_report.php" method="POST">
                                                                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                                        <input type="hidden" name="action" value="remove_review">
                                                                        <input type="hidden" name="target_id" value="<?php echo $report['target_id']; ?>">
                                                                        <div class="alert alert-warning">
                                                                            <p><strong>Notice:</strong> You are about to remove a review from "<?php echo htmlspecialchars($report['target_name']); ?>".</p>
                                                                            <p>The review will be deleted and the reviewer will be notified with your reason.</p>
                                                                        </div>
                                                                        <div class="mb-3">
                                                                            <label for="removal_reason_review<?php echo $report['id']; ?>" class="form-label">Reason for Removal</label>
                                                                            <textarea class="form-control" id="removal_reason_review<?php echo $report['id']; ?>" name="removal_reason" rows="3" placeholder="Explain why this review is being removed..." required></textarea>
                                                                        </div>
                                                                        <!-- Hidden input to ensure notification is sent -->
                                                                        <input type="hidden" name="notify_reviewer" value="1">
                                                                        <!-- Hidden input to ensure confirmation is always set -->
                                                                        <input type="hidden" name="confirm_removal" value="1">
                                                                        <div class="d-flex justify-content-end gap-2">
                                                                            <button type="button" class="btn btn-sm btn-secondary cancel-action" data-report-id="<?php echo $report['id']; ?>">Cancel</button>
                                                                            <button type="submit" class="btn btn-sm btn-danger">Remove Review</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Mark In Progress Modal -->
                                        <div class="modal fade" id="markInProgressModal<?php echo $report['id']; ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Mark Report as In Progress</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form action="actions/process_report.php" method="POST">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                            <input type="hidden" name="action" value="in_progress">
                                                            <p>You are about to mark this report as "In Progress". This indicates that you are actively investigating this report.</p>
                                                            <div class="mb-3">
                                                                <label for="note<?php echo $report['id']; ?>" class="form-label">Internal Note (Optional)</label>
                                                                <textarea class="form-control" id="note<?php echo $report['id']; ?>" name="note" rows="3" placeholder="Add any notes about your investigation..."></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-primary">Mark as In Progress</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Resolve Report Modal -->
                                        <div class="modal fade" id="resolveReportModal<?php echo $report['id']; ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Resolve Report</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form action="actions/process_report.php" method="POST">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                            <input type="hidden" name="action" value="resolve">
                                                            <p>You are about to mark this report as "Resolved". This indicates that appropriate action has been taken.</p>
                                                            <div class="mb-3">
                                                                <label for="resolution_note<?php echo $report['id']; ?>" class="form-label">Resolution Note</label>
                                                                <textarea class="form-control" id="resolution_note<?php echo $report['id']; ?>" name="resolution_note" rows="3" placeholder="Explain how this report was resolved..." required></textarea>
                                                            </div>
                                                            <div class="mb-3">
                                                                <div class="form-check">
                                                                    <input class="form-check-input" type="checkbox" id="notify_reporter<?php echo $report['id']; ?>" name="notify_reporter" value="1" checked>
                                                                    <label class="form-check-label" for="notify_reporter<?php echo $report['id']; ?>">
                                                                        Notify reporter about resolution
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-success">Resolve Report</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Dismiss Report Modal -->
                                        <div class="modal fade" id="dismissReportModal<?php echo $report['id']; ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Dismiss Report</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form action="actions/process_report.php" method="POST">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                            <input type="hidden" name="action" value="dismiss">
                                                            <p>You are about to dismiss this report. This indicates that no action is needed.</p>
                                                            <div class="mb-3">
                                                                <label for="dismissal_reason<?php echo $report['id']; ?>" class="form-label">Dismissal Reason</label>
                                                                <textarea class="form-control" id="dismissal_reason<?php echo $report['id']; ?>" name="resolution_note" rows="3" placeholder="Explain why this report is being dismissed..." required></textarea>
                                                            </div>
                                                            <div class="mb-3">
                                                                <div class="form-check">
                                                                    <input class="form-check-input" type="checkbox" id="notify_reporter_dismiss<?php echo $report['id']; ?>" name="notify_reporter" value="1" checked>
                                                                    <label class="form-check-label" for="notify_reporter_dismiss<?php echo $report['id']; ?>">
                                                                        Notify reporter about dismissal
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-danger">Dismiss Report</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <?php if ($report['report_type'] === 'book'): ?>
                                        <!-- Remove Book Modal -->
                                        <div class="modal fade" id="removeBookModal<?php echo $report['id']; ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-danger text-white">
                                                        <h5 class="modal-title">
                                                            <i class="fas fa-exclamation-triangle me-2"></i>
                                                            Remove Book
                                                        </h5>
                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form action="actions/process_report.php" method="POST">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                            <input type="hidden" name="action" value="remove_book">
                                                            <input type="hidden" name="target_id" value="<?php echo $report['target_id']; ?>">
                                                            
                                                            <div class="alert alert-warning">
                                                                <p class="mb-0"><strong>Warning:</strong> You are about to remove the book "<?php echo htmlspecialchars($report['target_name']); ?>".</p>
                                                            </div>
                                                            
                                                            <p>This action will:</p>
                                                            <ul>
                                                                <li>Remove the book from the platform</li>
                                                                <li>Make it unavailable to all users</li>
                                                                <li>Notify the publisher about the removal</li>
                                                            </ul>
                                                            
                                                            <div class="mb-3">
                                                                <label for="removal_reason<?php echo $report['id']; ?>" class="form-label">Removal Reason</label>
                                                                <textarea class="form-control" id="removal_reason<?php echo $report['id']; ?>" name="resolution_note" rows="3" placeholder="Explain why this book is being removed..." required></textarea>
                                                            </div>
                                                            
                                                            <div class="form-check mb-3">
                                                                <input class="form-check-input" type="checkbox" id="confirm_removal<?php echo $report['id']; ?>" name="confirm_removal" value="1" required>
                                                                <label class="form-check-label" for="confirm_removal<?php echo $report['id']; ?>">
                                                                    I confirm that I want to remove this book
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-danger">Remove Book</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <?php elseif ($report['report_type'] === 'user'): ?>
                                        <!-- Block User Modal -->
                                        <div class="modal fade" id="blockUserModal<?php echo $report['id']; ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-danger text-white">
                                                        <h5 class="modal-title">
                                                            <i class="fas fa-ban me-2"></i>
                                                            Block User
                                                        </h5>
                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form action="actions/process_report.php" method="POST">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                            <input type="hidden" name="action" value="block_user">
                                                            <input type="hidden" name="target_id" value="<?php echo $report['target_id']; ?>">
                                                            
                                                            <div class="alert alert-warning">
                                                                <p class="mb-0"><strong>Warning:</strong> You are about to block the user "<?php echo htmlspecialchars($report['target_name']); ?>".</p>
                                                            </div>
                                                            
                                                            <p>This action will:</p>
                                                            <ul>
                                                                <li>Prevent the user from logging in</li>
                                                                <li>Hide their content from other users</li>
                                                                <li>Send them an email notification about the block</li>
                                                            </ul>
                                                            
                                                            <div class="mb-3">
                                                                <label for="block_duration<?php echo $report['id']; ?>" class="form-label">Block Duration</label>
                                                                <select class="form-select" id="block_duration<?php echo $report['id']; ?>" name="block_duration" required>
                                                                    <option value="7">7 days</option>
                                                                    <option value="30">30 days</option>
                                                                    <option value="90">90 days</option>
                                                                    <option value="permanent">Permanent</option>
                                                                </select>
                                                            </div>
                                                            
                                                            <div class="mb-3">
                                                                <label for="block_reason<?php echo $report['id']; ?>" class="form-label">Block Reason</label>
                                                                <textarea class="form-control" id="block_reason<?php echo $report['id']; ?>" name="resolution_note" rows="3" placeholder="Explain why this user is being blocked..." required></textarea>
                                                            </div>
                                                            
                                                            <div class="form-check mb-3">
                                                                <input class="form-check-input" type="checkbox" id="confirm_block<?php echo $report['id']; ?>" name="confirm_block" value="1" required>
                                                                <label class="form-check-label" for="confirm_block<?php echo $report['id']; ?>">
                                                                    I confirm that I want to block this user
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-danger">Block User</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <?php elseif ($report['report_type'] === 'review'): ?>
                                        <!-- Remove Review Modal -->
                                        <div class="modal fade" id="removeReviewModal<?php echo $report['id']; ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-danger text-white">
                                                        <h5 class="modal-title">
                                                            <i class="fas fa-trash-alt me-2"></i>
                                                            Remove Review
                                                        </h5>
                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form action="actions/process_report.php" method="POST">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                            <input type="hidden" name="action" value="remove_review">
                                                            <input type="hidden" name="target_id" value="<?php echo $report['target_id']; ?>">
                                                            
                                                            <div class="alert alert-warning">
                                                                <p class="mb-0"><strong>Warning:</strong> You are about to remove a review by "<?php echo htmlspecialchars($report['target_name']); ?>".</p>
                                                            </div>
                                                            
                                                            <?php if (isset($report['review_content'])): ?>
                                                                <div class="card mb-3">
                                                                    <div class="card-header bg-light">Review Content to be Removed</div>
                                                                    <div class="card-body">
                                                                        <p class="mb-0"><?php echo nl2br(htmlspecialchars($report['review_content'])); ?></p>
                                                                    </div>
                                                                </div>
                                                            <?php endif; ?>
                                                            
                                                            <div class="mb-3">
                                                                <label for="removal_reason<?php echo $report['id']; ?>" class="form-label">Removal Reason</label>
                                                                <textarea class="form-control" id="removal_reason<?php echo $report['id']; ?>" name="resolution_note" rows="3" placeholder="Explain why this review is being removed..." required></textarea>
                                                            </div>
                                                            
                                                            <div class="form-check mb-3">
                                                                <input class="form-check-input" type="checkbox" id="notify_reviewer<?php echo $report['id']; ?>" name="notify_reviewer" value="1" checked>
                                                                <label class="form-check-label" for="notify_reviewer<?php echo $report['id']; ?>">
                                                                    Notify reviewer about removal
                                                                </label>
                                                            </div>
                                                            
                                                            <div class="form-check mb-3">
                                                                <input class="form-check-input" type="checkbox" id="confirm_removal<?php echo $report['id']; ?>" name="confirm_removal" value="1" required>
                                                                <label class="form-check-label" for="confirm_removal<?php echo $report['id']; ?>">
                                                                    I confirm that I want to remove this review
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-danger">Remove Review</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted mb-0">No pending reports.</p>
                <?php endif; ?>
                
                <div class="text-end mt-3">
                    <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#reportHistoryModal">
                        <i class="fas fa-history" style="font-size: 1.4rem;"></i> View Report History
                    </button>
                </div>
                
                <?php include_once 'includes/report_history_modal.php'; ?>
    </div>
</div>

<!-- Publisher License Applications Section -->
<div class="card mb-4" id="licenses">
    <div class="card-header bg-white">
        <h5 class="mb-0">Publisher License Applications</h5>
    </div>
    <div class="card-body">
        <?php if (count($pendingPublisherLicenses) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Application Date</th>
                            <th>Reason</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pendingPublisherLicenses as $license): ?>
                        <tr>
                            <td>
                                <div>
                                    <strong><?php echo $license['user_name']; ?></strong>
                                </div>
                                <small class="text-muted"><?php echo $license['user_email']; ?></small>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($license['created_at'])); ?></td>
                            <td><?php echo $license['reason'] ?? 'No reason provided'; ?></td>
                            <td>
                                <div class="btn-group">
                                    <form action="actions/process_license.php" method="POST">
                                        <input type="hidden" name="license_id" value="<?php echo $license['id']; ?>">
                                        <input type="hidden" name="status" value="approved">
                                        <button type="submit" class="btn btn-sm btn-success me-2">Approve</button>
                                    </form>
                                    
                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#rejectLicenseModal<?php echo $license['id']; ?>">
                                        Reject
                                    </button>
                                </div>
                                
                                <!-- Reject License Modal -->
                                <div class="modal fade" id="rejectLicenseModal<?php echo $license['id']; ?>" tabindex="-1" aria-labelledby="rejectLicenseModalLabel<?php echo $license['id']; ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="rejectLicenseModalLabel<?php echo $license['id']; ?>">Reject Publisher License</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="actions/process_license.php" method="POST">
                                                <div class="modal-body">
                                                    <input type="hidden" name="license_id" value="<?php echo $license['id']; ?>">
                                                    <input type="hidden" name="status" value="rejected">
                                                    
                                                    <div class="mb-3">
                                                        <label for="rejection_reason<?php echo $license['id']; ?>" class="form-label">Reason for Rejection:</label>
                                                        <textarea class="form-control" id="rejection_reason<?php echo $license['id']; ?>" name="rejection_reason" rows="4" required></textarea>
                                                        <div class="form-text">This message will be sent to the user as a notification.</div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" class="btn btn-danger">Reject Application</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <p>No pending publisher license applications at the moment.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- User Management Section -->
<div class="card mb-4" id="user-management">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">User Management</h5>
        <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" data-bs-target="#userManagementCollapse" aria-expanded="true" aria-controls="userManagementCollapse">
            <i class="fas fa-chevron-down"></i>
        </button>
    </div>
    <div class="collapse show" id="userManagementCollapse">
        <div class="card-body">
            <form action="actions/search_users.php" method="GET" class="mb-4">
                <div class="row g-3">
                    <div class="col-md-5">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" class="form-control" name="query" placeholder="Search by name or email..." value="<?php echo isset($_SESSION['user_search_query']) ? htmlspecialchars($_SESSION['user_search_query']) : ''; ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" name="role">
                            <option value="">All Roles</option>
                            <option value="user" <?php echo (isset($_SESSION['user_search_role']) && $_SESSION['user_search_role'] === 'user') ? 'selected' : ''; ?>>Regular Users</option>
                            <option value="publisher" <?php echo (isset($_SESSION['user_search_role']) && $_SESSION['user_search_role'] === 'publisher') ? 'selected' : ''; ?>>Publishers</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" name="status">
                            <option value="">All Status</option>
                            <option value="active" <?php echo (isset($_SESSION['user_search_status']) && $_SESSION['user_search_status'] === 'active') ? 'selected' : ''; ?>>Active</option>
                            <option value="blocked" <?php echo (isset($_SESSION['user_search_status']) && $_SESSION['user_search_status'] === 'blocked') ? 'selected' : ''; ?>>Blocked</option>
                            <option value="pending" <?php echo (isset($_SESSION['user_search_status']) && $_SESSION['user_search_status'] === 'pending') ? 'selected' : ''; ?>>Pending</option>
                        </select>
                    </div>
                    <div class="col-md-1">
                        <button class="btn btn-primary w-100" type="submit">
                            <i class="fas fa-filter"></i>
                        </button>
                    </div>
                </div>
            </form>
            
            <?php
            // Get users from search results or default to all users
            $users = isset($_SESSION['user_search_results']) ? $_SESSION['user_search_results'] : getUsersForModeration();
            ?>
            
            <?php if (count($users) > 0): ?>
                <div class="user-table-container custom-scrollbar">
                    <table class="table table-hover align-middle">
                        <thead class="sticky-top bg-white">
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Joined</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="user-avatar me-3">
                                            <i class="fas <?php echo $user['role'] === 'publisher' ? 'fa-user-tie' : 'fa-user'; ?>"></i>
                                        </div>
                                        <div>
                                            <div class="fw-bold"><?php echo htmlspecialchars($user['name']); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td>
                                    <?php if ($user['role'] === 'publisher'): ?>
                                        <span class="badge bg-primary">Publisher</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">User</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($user['status'] === 'active'): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php elseif ($user['status'] === 'blocked'): ?>
                                        <span class="badge bg-danger">Blocked</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                <td>
                                    <div class="d-flex gap-2">
                                        <?php if ($user['status'] === 'active'): ?>
                                            <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#blockUserModal<?php echo $user['id']; ?>">
                                                <i class="fas fa-ban"></i> Block
                                            </button>
                                        <?php else: ?>
                                            <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#unblockUserModal<?php echo $user['id']; ?>">
                                                <i class="fas fa-check"></i> Unblock
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Block User Modal -->
                                    <div class="modal fade" id="blockUserModal<?php echo $user['id']; ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Block User</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form action="actions/update_user_status.php" method="POST">
                                                    <div class="modal-body">
                                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                        <input type="hidden" name="action" value="block">
                                                        
                                                        <p>Are you sure you want to block <strong><?php echo htmlspecialchars($user['name']); ?></strong>?</p>
                                                        <p>This will prevent them from accessing their account until unblocked.</p>
                                                        
                                                        <div class="mb-3">
                                                            <label for="blockReason<?php echo $user['id']; ?>" class="form-label">Reason for blocking:</label>
                                                            <textarea class="form-control" id="blockReason<?php echo $user['id']; ?>" name="reason" rows="3" required></textarea>
                                                            <div class="form-text">This reason will be sent to the user.</div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-danger">Block User</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Unblock User Modal -->
                                    <div class="modal fade" id="unblockUserModal<?php echo $user['id']; ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Unblock User</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form action="actions/update_user_status.php" method="POST">
                                                    <div class="modal-body">
                                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                        <input type="hidden" name="action" value="unblock">
                                                        
                                                        <p>Are you sure you want to unblock <strong><?php echo htmlspecialchars($user['name']); ?></strong>?</p>
                                                        <p>This will restore their access to the platform.</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-success">Unblock User</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <p>No users found matching your search criteria.</p>
                </div>
            <?php endif; ?>
            
            <div class="alert alert-info mt-4">
                <h6><i class="fas fa-info-circle me-2"></i>Moderator Capabilities:</h6>
                <ul class="mb-0">
                    <li>Temporarily block users or publishers for violations</li>
                    <li>Approve or reject publisher license applications</li>
                    <li>Handle and resolve user complaints</li>
                    <li>Search for specific users to take action</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- User Library Section -->
<div class="card mb-4">
    <div class="card-header bg-white">
        <h5 class="mb-0">My Library</h5>
    </div>
    <div class="card-body">
        <?php
        $purchasedBooks = getPurchasedBooks($_SESSION['user_id']);
        if (count($purchasedBooks) > 0):
        ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Cover</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Format</th>
                            <th>Progress</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($purchasedBooks as $book): ?>
                        <tr>
                            <td>
                                <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" alt="<?php echo $book['title']; ?>" class="img-thumbnail" style="width: 50px;">
                            </td>
                            <td><?php echo $book['title']; ?></td>
                            <td><?php echo $book['author']; ?></td>
                            <td>
                                <?php if ($book['pdf_path']): ?>
                                <span class="badge bg-info"><i class="fas fa-file-pdf me-1" style="font-size: 1.4rem;"></i> PDF</span>
                                <?php endif; ?>
                                
                                <?php if ($book['audio_path']): ?>
                                <span class="badge bg-warning"><i class="fas fa-headphones me-1" style="font-size: 1.4rem;"></i> Audio</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                // Get bookmark if exists
                                $bookmark = getBookmark($_SESSION['user_id'], $book['id']);
                                if ($bookmark):
                                ?>
                                <small>
                                    <?php if ($bookmark['last_read_page']): ?>
                                    <span class="badge bg-light text-dark"><i class="fas fa-bookmark me-1"></i> Page <?php echo $bookmark['last_read_page']; ?></span>
                                    <?php endif; ?>
                                    
                                    <?php if ($bookmark['last_listen_position']): ?>
                                    <span class="badge bg-light text-dark"><i class="fas fa-headphones me-1"></i> 
                                    <?php 
                                    $minutes = floor($bookmark['last_listen_position'] / 60);
                                    $seconds = $bookmark['last_listen_position'] % 60;
                                    echo $minutes . ':' . ($seconds < 10 ? '0' : '') . $seconds;
                                    ?>
                                    </span>
                                    <?php endif; ?>
                                </small>
                                <?php else: ?>
                                <span class="text-muted">Not started</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="index.php?page=book&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-primary" data-bs-toggle="tooltip" title="View Book">
                                        <i class="fas fa-eye" style="font-size: 1.4rem;"></i>
                                    </a>
                                    
                                    <?php if ($book['pdf_path']): ?>
                                    <a href="index.php?page=read&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-success" data-bs-toggle="tooltip" title="Read Book">
                                        <i class="fas fa-book-reader" style="font-size: 1.4rem;"></i>
                                    </a>
                                    <?php endif; ?>
                                    
                                    <?php if ($book['audio_path']): ?>
                                    <a href="index.php?page=listen&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-warning" data-bs-toggle="tooltip" title="Listen to Book">
                                        <i class="fas fa-headphones" style="font-size: 1.4rem;"></i>
                                    </a>
                                    <?php endif; ?>
                                    
                                    <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#removeBookModal<?php echo $book['id']; ?>" title="Remove from Library">
                                        <i class="fas fa-trash-alt" style="font-size: 1.4rem;"></i>
                                    </button>
                                </div>
                                
                                <!-- Remove Book Modal -->
                                <div class="modal fade" id="removeBookModal<?php echo $book['id']; ?>" tabindex="-1" aria-labelledby="removeBookModalLabel<?php echo $book['id']; ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="removeBookModalLabel<?php echo $book['id']; ?>">Confirm Removal</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="alert alert-warning">
                                                    <i class="fas fa-exclamation-triangle me-2"></i> Warning
                                                </div>
                                                <p>Are you sure you want to remove <strong><?php echo $book['title']; ?></strong> from your library?</p>
                                                <p class="text-danger"><strong>This action cannot be undone.</strong> If you want to access this book again in the future, you will need to purchase it again.</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <form action="actions/remove_from_library.php" method="post">
                                                    <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
                                                    <button type="submit" class="btn btn-danger">Remove Book</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <p>You haven't purchased any books yet.</p>
                <a href="index.php?page=search" class="btn btn-primary mt-2">Browse Books</a>
            </div>
        <?php endif; ?>
    </div>
</div>
