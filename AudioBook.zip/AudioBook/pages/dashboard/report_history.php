<?php
/**
 * Report history page for admins and moderators
 * Shows history of resolved and dismissed reports
 */

// Check if user is logged in and has appropriate role
if (!isLoggedIn() || (!isAdmin() && !isModerator())) {
    setMessage('You do not have permission to access this page', 'error');
    header('Location: index.php');
    exit();
}

// Get filter parameters
$status = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$type = isset($_GET['type']) ? sanitize($_GET['type']) : '';
$dateRange = isset($_GET['date_range']) ? sanitize($_GET['date_range']) : '';

// Build query
$sql = "SELECT r.*, 
              u1.name as reporter_name, u1.email as reporter_email, 
              u2.name as resolver_name, u2.email as resolver_email 
       FROM reports r 
       JOIN users u1 ON r.reporter_id = u1.id 
       LEFT JOIN users u2 ON r.resolved_by = u2.id 
       WHERE 1=1";
$params = [];

// Add status filter
if (!empty($status)) {
    $sql .= " AND r.status = :status";
    $params[':status'] = $status;
} else {
    // Default to showing resolved and dismissed reports
    $sql .= " AND r.status IN ('resolved', 'dismissed')";
}

// Add type filter
if (!empty($type)) {
    $sql .= " AND r.report_type = :type";
    $params[':type'] = $type;
}

// Add date range filter
if (!empty($dateRange)) {
    switch ($dateRange) {
        case 'today':
            $sql .= " AND DATE(r.updated_at) = CURDATE()";
            break;
        case 'week':
            $sql .= " AND r.updated_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
            break;
        case 'month':
            $sql .= " AND r.updated_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
            break;
    }
}

// Order by updated date, newest first
$sql .= " ORDER BY r.updated_at DESC";

// Execute query
$stmt = $conn->prepare($sql);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get additional information for each report
foreach ($reports as &$report) {
    switch ($report['report_type']) {
        case 'book':
            $book = getBookById($report['target_id']);
            if ($book) {
                $report['target_name'] = $book['title'];
                $report['target_details'] = "Author: {$book['author']}";
                $report['target_link'] = "index.php?page=book&id={$report['target_id']}";
            }
            break;
            
        case 'user':
            $user = getUserById($report['target_id']);
            if ($user) {
                $report['target_name'] = $user['name'];
                $report['target_details'] = "Role: " . ucfirst($user['role']);
                $report['target_link'] = "index.php?page=user&id={$report['target_id']}";
            }
            break;
            
        case 'review':
            // Get review details
            $stmt = $conn->prepare("SELECT f.*, b.title as book_title, b.id as book_id, u.name as reviewer_name 
                                  FROM feedback f 
                                  JOIN books b ON f.book_id = b.id 
                                  JOIN users u ON f.user_id = u.id 
                                  WHERE f.id = :review_id");
            $stmt->bindParam(':review_id', $report['target_id'], PDO::PARAM_INT);
            $stmt->execute();
            $review = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($review) {
                $report['target_name'] = "Review by {$review['reviewer_name']}";
                $report['target_details'] = "Book: {$review['book_title']}";
                $report['target_link'] = "index.php?page=book&id={$review['book_id']}";
                $report['review_content'] = $review['comment'];
            }
            break;
    }
}
?>

<h2 class="mb-4">Report History</h2>

<div class="card mb-4">
    <div class="card-header bg-white">
        <form action="" method="GET" class="row g-3 align-items-end">
            <input type="hidden" name="page" value="dashboard">
            <input type="hidden" name="section" value="report_history">
            
            <div class="col-md-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="">All Statuses</option>
                    <option value="resolved" <?php echo $status === 'resolved' ? 'selected' : ''; ?>>Resolved</option>
                    <option value="dismissed" <?php echo $status === 'dismissed' ? 'selected' : ''; ?>>Dismissed</option>
                    <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="in_progress" <?php echo $status === 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                </select>
            </div>
            
            <div class="col-md-3">
                <label for="type" class="form-label">Type</label>
                <select class="form-select" id="type" name="type">
                    <option value="">All Types</option>
                    <option value="book" <?php echo $type === 'book' ? 'selected' : ''; ?>>Books</option>
                    <option value="user" <?php echo $type === 'user' ? 'selected' : ''; ?>>Users</option>
                    <option value="review" <?php echo $type === 'review' ? 'selected' : ''; ?>>Reviews</option>
                </select>
            </div>
            
            <div class="col-md-3">
                <label for="date_range" class="form-label">Date Range</label>
                <select class="form-select" id="date_range" name="date_range">
                    <option value="">All Time</option>
                    <option value="today" <?php echo $dateRange === 'today' ? 'selected' : ''; ?>>Today</option>
                    <option value="week" <?php echo $dateRange === 'week' ? 'selected' : ''; ?>>Last 7 Days</option>
                    <option value="month" <?php echo $dateRange === 'month' ? 'selected' : ''; ?>>Last 30 Days</option>
                </select>
            </div>
            
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-filter me-1"></i> Filter
                </button>
            </div>
        </form>
    </div>
    
    <div class="card-body">
        <?php if (count($reports) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Reported Item</th>
                            <th>Reporter</th>
                            <th>Status</th>
                            <th>Resolved By</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reports as $report): ?>
                        <tr>
                            <td>
                                <?php if ($report['report_type'] === 'book'): ?>
                                    <span class="badge bg-primary">Book</span>
                                <?php elseif ($report['report_type'] === 'user'): ?>
                                    <span class="badge bg-warning">User</span>
                                <?php elseif ($report['report_type'] === 'review'): ?>
                                    <span class="badge bg-info">Review</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($report['target_name'] ?? 'Unknown'); ?>
                                <?php if (isset($report['target_link'])): ?>
                                    <a href="<?php echo $report['target_link']; ?>" class="ms-1" target="_blank"><i class="fas fa-external-link-alt small"></i></a>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($report['reporter_name']); ?></td>
                            <td>
                                <?php if ($report['status'] === 'pending'): ?>
                                    <span class="badge bg-secondary">Pending</span>
                                <?php elseif ($report['status'] === 'in_progress'): ?>
                                    <span class="badge bg-primary">In Progress</span>
                                <?php elseif ($report['status'] === 'resolved'): ?>
                                    <span class="badge bg-success">Resolved</span>
                                <?php elseif ($report['status'] === 'dismissed'): ?>
                                    <span class="badge bg-danger">Dismissed</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $report['resolver_name'] ?? 'N/A'; ?></td>
                            <td><?php echo date('M d, Y', strtotime($report['updated_at'])); ?></td>
                            <td>
                                <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#historyReportModal<?php echo $report['id']; ?>">
                                    <i class="fas fa-eye"></i> View
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <p class="mb-0">No reports found matching your criteria.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Report History Modals -->
<?php foreach ($reports as $report): ?>
<div class="modal fade" id="historyReportModal<?php echo $report['id']; ?>" tabindex="-1" aria-labelledby="historyReportModalLabel<?php echo $report['id']; ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="historyReportModalLabel<?php echo $report['id']; ?>">
                    Report #<?php echo $report['id']; ?> - 
                    <?php if ($report['report_type'] === 'book'): ?>Book Report
                    <?php elseif ($report['report_type'] === 'user'): ?>User Report
                    <?php elseif ($report['report_type'] === 'review'): ?>Review Report
                    <?php endif; ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="fw-bold">Report Information</h6>
                        <p><strong>Reported by:</strong> <?php echo htmlspecialchars($report['reporter_name']); ?> (<?php echo htmlspecialchars($report['reporter_email']); ?>)</p>
                        <p><strong>Date Reported:</strong> <?php echo date('F d, Y h:i A', strtotime($report['created_at'])); ?></p>
                        <p><strong>Status:</strong> 
                            <?php if ($report['status'] === 'pending'): ?>
                                <span class="badge bg-secondary">Pending</span>
                            <?php elseif ($report['status'] === 'in_progress'): ?>
                                <span class="badge bg-primary">In Progress</span>
                            <?php elseif ($report['status'] === 'resolved'): ?>
                                <span class="badge bg-success">Resolved</span>
                            <?php elseif ($report['status'] === 'dismissed'): ?>
                                <span class="badge bg-danger">Dismissed</span>
                            <?php endif; ?>
                        </p>
                        <p><strong>Reason:</strong> <?php echo htmlspecialchars($report['reason']); ?></p>
                        <?php if (!empty($report['details'])): ?>
                            <p><strong>Additional Details:</strong> <?php echo nl2br(htmlspecialchars($report['details'])); ?></p>
                        <?php endif; ?>
                        
                        <?php if (!empty($report['resolution_note'])): ?>
                            <div class="alert alert-info">
                                <h6 class="fw-bold">Resolution Note:</h6>
                                <p class="mb-0"><?php echo nl2br(htmlspecialchars($report['resolution_note'])); ?></p>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($report['status'] === 'resolved' || $report['status'] === 'dismissed'): ?>
                            <p><strong>Resolved By:</strong> <?php echo htmlspecialchars($report['resolver_name']); ?></p>
                            <p><strong>Resolution Date:</strong> <?php echo date('F d, Y h:i A', strtotime($report['updated_at'])); ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-6">
                        <h6 class="fw-bold">Reported Item Details</h6>
                        <?php if ($report['report_type'] === 'book'): ?>
                            <p><strong>Book Title:</strong> <?php echo htmlspecialchars($report['target_name']); ?></p>
                            <p><strong>Details:</strong> <?php echo htmlspecialchars($report['target_details']); ?></p>
                            <?php if (isset($report['target_link'])): ?>
                                <p><a href="<?php echo $report['target_link']; ?>" class="btn btn-sm btn-outline-primary" target="_blank"><i class="fas fa-book"></i> View Book</a></p>
                            <?php endif; ?>
                            
                        <?php elseif ($report['report_type'] === 'user'): ?>
                            <p><strong>User:</strong> <?php echo htmlspecialchars($report['target_name']); ?></p>
                            <p><strong>Details:</strong> <?php echo htmlspecialchars($report['target_details']); ?></p>
                            <?php if (isset($report['target_link'])): ?>
                                <p><a href="<?php echo $report['target_link']; ?>" class="btn btn-sm btn-outline-primary" target="_blank"><i class="fas fa-user"></i> View User</a></p>
                            <?php endif; ?>
                            
                        <?php elseif ($report['report_type'] === 'review'): ?>
                            <p><strong>Review:</strong> <?php echo htmlspecialchars($report['target_name']); ?></p>
                            <p><strong>Details:</strong> <?php echo htmlspecialchars($report['target_details']); ?></p>
                            <?php if (isset($report['review_content'])): ?>
                                <div class="card mb-3">
                                    <div class="card-header bg-light">Review Content</div>
                                    <div class="card-body">
                                        <p class="mb-0"><?php echo nl2br(htmlspecialchars($report['review_content'])); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if (isset($report['target_link'])): ?>
                                <p><a href="<?php echo $report['target_link']; ?>" class="btn btn-sm btn-outline-primary" target="_blank"><i class="fas fa-book"></i> View Book</a></p>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>
