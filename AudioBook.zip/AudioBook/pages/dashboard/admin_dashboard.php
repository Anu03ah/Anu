<!-- Admin Dashboard -->
<h2 class="mb-4">Admin Dashboard</h2>

<div class="row mb-4">
    <div class="col-md-3">
        <div class="card dashboard-card">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <div class="dashboard-icon me-3">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <div>
                        <h5 class="card-title mb-0">Admin Account</h5>
                        <p class="text-muted mb-0"><?php echo $_SESSION['user_name']; ?></p>
                    </div>
                </div>
                <a href="index.php?page=profile" class="btn btn-outline-primary btn-sm">Edit Profile</a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card dashboard-card">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <div class="dashboard-icon me-3">
                        <i class="fas fa-users"></i>
                    </div>
                    <div>
                        <?php
                        // Get total users count
                        $stmt = $conn->prepare("SELECT COUNT(*) FROM users");
                        $stmt->execute();
                        $userCount = $stmt->fetchColumn();
                        ?>
                        <h5 class="card-title mb-0"><?php echo $userCount; ?> Users</h5>
                        <p class="text-muted mb-0">Registered</p>
                    </div>
                </div>
                <a href="#user-management" class="btn btn-outline-primary btn-sm">Manage Users</a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card dashboard-card">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <div class="dashboard-icon me-3">
                        <i class="fas fa-book"></i>
                    </div>
                    <div>
                        <?php
                        // Get total books count
                        $stmt = $conn->prepare("SELECT COUNT(*) FROM books");
                        $stmt->execute();
                        $bookCount = $stmt->fetchColumn();
                        ?>
                        <h5 class="card-title mb-0"><?php echo $bookCount; ?> Books</h5>
                        <p class="text-muted mb-0">Published</p>
                    </div>
                </div>
                <a href="#book-management" class="btn btn-outline-primary btn-sm">Manage Books</a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card dashboard-card">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <div class="dashboard-icon me-3">
                        <i class="fas fa-id-card"></i>
                    </div>
                    <div>
                        <?php
                        // Get pending moderator licenses count
                        $stmt = $conn->prepare("SELECT COUNT(*) FROM licenses WHERE type = 'moderator' AND status = 'pending'");
                        $stmt->execute();
                        $licenseCount = $stmt->fetchColumn();
                        ?>
                        <h5 class="card-title mb-0"><?php echo $licenseCount; ?> Pending</h5>
                        <p class="text-muted mb-0">Moderator Licenses</p>
                    </div>
                </div>
                <a href="#licenses" class="btn btn-outline-primary btn-sm">View Applications</a>
            </div>
        </div>
    </div>
</div>

<!-- System Statistics -->
<div class="card mb-4">
    <div class="card-header bg-white">
        <h5 class="mb-0">System Statistics</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-4">
                <div class="card bg-light">
                    <div class="card-body">
                        <h6 class="card-title">User Distribution</h6>
                        <?php
                        // Get user role distribution
                        $stmt = $conn->prepare("SELECT role, COUNT(*) as count FROM users GROUP BY role");
                        $stmt->execute();
                        $userRoles = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        // Calculate percentages
                        $totalUsers = array_sum(array_column($userRoles, 'count'));
                        foreach ($userRoles as $role):
                            $percentage = ($role['count'] / $totalUsers) * 100;
                        ?>
                        <div class="mb-2">
                            <div class="d-flex justify-content-between mb-1">
                                <span><?php echo ucfirst($role['role']); ?>s</span>
                                <span><?php echo $role['count']; ?> (<?php echo round($percentage); ?>%)</span>
                            </div>
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo $percentage; ?>%" aria-valuenow="<?php echo $percentage; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card bg-light">
                    <div class="card-body">
                        <h6 class="card-title">Book Categories</h6>
                        <?php
                        // Get book category distribution
                        $stmt = $conn->prepare("SELECT category, COUNT(*) as count FROM books GROUP BY category ORDER BY count DESC LIMIT 5");
                        $stmt->execute();
                        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        // Calculate percentages
                        $totalBooks = $bookCount;
                        foreach ($categories as $category):
                            $percentage = ($category['count'] / $totalBooks) * 100;
                        ?>
                        <div class="mb-2">
                            <div class="d-flex justify-content-between mb-1">
                                <span><?php echo $category['category']; ?></span>
                                <span><?php echo $category['count']; ?> (<?php echo round($percentage); ?>%)</span>
                            </div>
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $percentage; ?>%" aria-valuenow="<?php echo $percentage; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card bg-light">
                    <div class="card-body">
                        <h6 class="card-title">Recent Activity</h6>
                        <?php
                        // Get recent purchases
                        $stmt = $conn->prepare("SELECT p.purchase_date, u.name as user_name, b.title as book_title 
                                              FROM purchases p 
                                              JOIN users u ON p.user_id = u.id 
                                              JOIN books b ON p.book_id = b.id 
                                              ORDER BY p.purchase_date DESC LIMIT 5");
                        $stmt->execute();
                        $recentPurchases = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        if (count($recentPurchases) > 0):
                            foreach ($recentPurchases as $purchase):
                        ?>
                        <div class="mb-2 small">
                            <i class="fas fa-shopping-cart text-primary me-1"></i>
                            <strong><?php echo $purchase['user_name']; ?></strong> purchased 
                            <strong><?php echo $purchase['book_title']; ?></strong>
                            <div class="text-muted"><?php echo date('M d, H:i', strtotime($purchase['purchase_date'])); ?></div>
                        </div>
                        <?php 
                            endforeach;
                        else:
                        ?>
                        <p class="text-muted">No recent purchases</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Reports Section -->
<div class="card mb-4" id="reports">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Reports</h5>
    </div>
    <div class="card-body">
                <?php 
                // Get pending reports
                $pendingReports = getPendingReports();
                
                if (count($pendingReports) > 0): 
                ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Type</th>
                                    <th>Reported Item</th>
                                    <th>Reporter</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pendingReports as $report): ?>
                                <tr>
                                    <td>#<?php echo $report['id']; ?></td>
                                    <td>
                                        <?php if ($report['report_type'] === 'book'): ?>
                                            <span class="badge bg-primary">Book</span>
                                        <?php elseif ($report['report_type'] === 'user'): ?>
                                            <span class="badge bg-warning">User</span>
                                        <?php elseif ($report['report_type'] === 'review'): ?>
                                            <span class="badge bg-info">Review</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo htmlspecialchars($report['target_name'] ?? 'Unknown'); ?>
                                        <?php if (isset($report['target_link'])): ?>
                                            <a href="<?php echo $report['target_link']; ?>" class="ms-1" target="_blank"><i class="fas fa-external-link-alt small"></i></a>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($report['reporter_name']); ?></td>
                                    <td>
                                        <?php if ($report['status'] === 'pending'): ?>
                                            <span class="badge bg-secondary">Pending</span>
                                        <?php elseif ($report['status'] === 'in_progress'): ?>
                                            <span class="badge bg-primary">In Progress</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($report['created_at'])); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#reportModal<?php echo $report['id']; ?>">
                                            <i class="fas fa-eye"></i> View
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted mb-0">No pending reports.</p>
                <?php endif; ?>
                
                <div class="text-end mt-3">
                    <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#reportHistoryModal">
                        <i class="fas fa-history" style="font-size: 1.4rem;"></i> View Report History
                    </button>
                </div>
                
                <?php include_once 'includes/report_history_modal.php'; ?>
    </div>
</div>

<!-- Report Modals -->
<?php foreach ($pendingReports ?? [] as $report): ?>
<div class="modal fade" id="reportModal<?php echo $report['id']; ?>" tabindex="-1" aria-labelledby="reportModalLabel<?php echo $report['id']; ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="reportModalLabel<?php echo $report['id']; ?>">
                    Report #<?php echo $report['id']; ?> - 
                    <?php if ($report['report_type'] === 'book'): ?>Book Report
                    <?php elseif ($report['report_type'] === 'user'): ?>User Report
                    <?php elseif ($report['report_type'] === 'review'): ?>Review Report
                    <?php endif; ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="fw-bold">Report Information</h6>
                        <p><strong>Reported by:</strong> <?php echo htmlspecialchars($report['reporter_name']); ?> (<?php echo htmlspecialchars($report['reporter_email']); ?>)</p>
                        <p><strong>Date Reported:</strong> <?php echo date('F d, Y h:i A', strtotime($report['created_at'])); ?></p>
                        <p><strong>Status:</strong> 
                            <?php if ($report['status'] === 'pending'): ?>
                                <span class="badge bg-secondary">Pending</span>
                            <?php elseif ($report['status'] === 'in_progress'): ?>
                                <span class="badge bg-primary">In Progress</span>
                            <?php endif; ?>
                        </p>
                        <p><strong>Reason:</strong> <?php echo htmlspecialchars($report['reason']); ?></p>
                        <?php if (!empty($report['details'])): ?>
                            <p><strong>Additional Details:</strong> <?php echo nl2br(htmlspecialchars($report['details'])); ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-6">
                        <h6 class="fw-bold">Reported Item Details</h6>
                        <?php if ($report['report_type'] === 'book'): ?>
                            <p><strong>Book Title:</strong> <?php echo htmlspecialchars($report['target_name']); ?></p>
                            <p><strong>Details:</strong> <?php echo htmlspecialchars($report['target_details']); ?></p>
                            <?php if (isset($report['target_link'])): ?>
                                <p><a href="<?php echo $report['target_link']; ?>" class="btn btn-sm btn-outline-primary" target="_blank"><i class="fas fa-book"></i> View Book</a></p>
                            <?php endif; ?>
                            
                        <?php elseif ($report['report_type'] === 'user'): ?>
                            <p><strong>User:</strong> <?php echo htmlspecialchars($report['target_name']); ?></p>
                            <p><strong>Details:</strong> <?php echo htmlspecialchars($report['target_details']); ?></p>
                            
                        <?php elseif ($report['report_type'] === 'review'): ?>
                            <p><strong>Review:</strong> <?php echo htmlspecialchars($report['target_name']); ?></p>
                            <p><strong>Details:</strong> <?php echo htmlspecialchars($report['target_details']); ?></p>
                            <?php if (isset($report['review_content'])): ?>
                                <div class="card mb-3">
                                    <div class="card-header bg-light">Review Content</div>
                                    <div class="card-body">
                                        <p class="mb-0"><?php echo nl2br(htmlspecialchars($report['review_content'])); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if (isset($report['target_link'])): ?>
                                <p><a href="<?php echo $report['target_link']; ?>" class="btn btn-sm btn-outline-primary" target="_blank"><i class="fas fa-book"></i> View Book</a></p>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Action Section -->
                <div class="border-top pt-4 mt-4 px-3 pb-3">
                    <h5 class="mb-3">Available Actions</h5>
                    
                    <!-- General Report Actions -->
                    <div class="mb-4 p-3 bg-light rounded">
                        <h6 class="text-muted mb-3">Process Report</h6>
                        <div class="d-flex flex-wrap gap-3">
                            <?php if ($report['status'] === 'pending'): ?>
                                <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#markInProgressModal<?php echo $report['id']; ?>" data-bs-dismiss="modal">
                                    <i class="fas fa-hourglass-half me-2" style="font-size: 1.4rem;"></i> Mark In Progress
                                </button>
                            <?php endif; ?>
                            <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#resolveReportModal<?php echo $report['id']; ?>" data-bs-dismiss="modal">
                                <i class="fas fa-check-circle me-2" style="font-size: 1.4rem;"></i> Resolve
                            </button>
                            <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#dismissReportModal<?php echo $report['id']; ?>" data-bs-dismiss="modal">
                                <i class="fas fa-times-circle me-2" style="font-size: 1.4rem;"></i> Dismiss
                            </button>
                        </div>
                    </div>
                    
                    <!-- Content-Specific Actions -->
                    <?php if ($report['report_type'] === 'book' || $report['report_type'] === 'user' || $report['report_type'] === 'review'): ?>
                    <div class="p-3 bg-light rounded">
                        <h6 class="text-muted mb-3">Content Actions</h6>
                        <div class="d-flex flex-wrap gap-3">
                            <?php if ($report['report_type'] === 'book'): ?>
                                <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#removeBookModal<?php echo $report['id']; ?>" data-bs-dismiss="modal">
                                    <i class="fas fa-trash-alt me-2" style="font-size: 1.4rem;"></i> Remove Book
                                </button>
                            <?php elseif ($report['report_type'] === 'user'): ?>
                                <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#blockUserModal<?php echo $report['id']; ?>" data-bs-dismiss="modal">
                                    <i class="fas fa-ban me-2" style="font-size: 1.4rem;"></i> Block User
                                </button>
                            <?php elseif ($report['report_type'] === 'review'): ?>
                                <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#removeReviewModal<?php echo $report['id']; ?>" data-bs-dismiss="modal">
                                    <i class="fas fa-trash-alt me-2" style="font-size: 1.4rem;"></i> Remove Review
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>

<!-- Report Action Modals -->
<?php foreach ($pendingReports ?? [] as $report): ?>
    <!-- Mark In Progress Modal -->
    <div class="modal fade" id="markInProgressModal<?php echo $report['id']; ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-hourglass-half me-2"></i> Mark Report In Progress</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>You are about to mark this report as "In Progress". This indicates that you are actively investigating the report.</p>
                    
                    <form action="actions/process_report.php" method="post">
                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                        <input type="hidden" name="action" value="mark_in_progress">
                        
                        <div class="mb-3">
                            <label for="resolution_note<?php echo $report['id']; ?>_progress" class="form-label">Add a note (optional)</label>
                            <textarea class="form-control" id="resolution_note<?php echo $report['id']; ?>_progress" name="resolution_note" rows="3" placeholder="Add any notes about your investigation..."></textarea>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="notify_reporter" id="notify_reporter<?php echo $report['id']; ?>_progress" checked>
                            <label class="form-check-label" for="notify_reporter<?php echo $report['id']; ?>_progress">
                                Notify the reporter that their report is being reviewed
                            </label>
                        </div>
                        
                        <div class="d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Mark In Progress</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Resolve Report Modal -->
    <div class="modal fade" id="resolveReportModal<?php echo $report['id']; ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title"><i class="fas fa-check-circle me-2"></i> Resolve Report</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>You are about to mark this report as "Resolved". This indicates that appropriate action has been taken.</p>
                    
                    <form action="actions/process_report.php" method="post">
                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                        <input type="hidden" name="action" value="resolve">
                        
                        <div class="mb-3">
                            <label for="resolution_note<?php echo $report['id']; ?>_resolve" class="form-label">Resolution Note</label>
                            <textarea class="form-control" id="resolution_note<?php echo $report['id']; ?>_resolve" name="resolution_note" rows="3" placeholder="Explain how this report was resolved..."></textarea>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="notify_reporter" id="notify_reporter<?php echo $report['id']; ?>_resolve" checked>
                            <label class="form-check-label" for="notify_reporter<?php echo $report['id']; ?>_resolve">
                                Notify the reporter that their report has been resolved
                            </label>
                        </div>
                        
                        <div class="d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-success">Resolve Report</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Dismiss Report Modal -->
    <div class="modal fade" id="dismissReportModal<?php echo $report['id']; ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="fas fa-times-circle me-2"></i> Dismiss Report</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>You are about to dismiss this report. This indicates that no action is needed or the report is invalid.</p>
                    
                    <form action="actions/process_report.php" method="post">
                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                        <input type="hidden" name="action" value="dismiss">
                        
                        <div class="mb-3">
                            <label for="resolution_note<?php echo $report['id']; ?>_dismiss" class="form-label">Dismissal Reason</label>
                            <textarea class="form-control" id="resolution_note<?php echo $report['id']; ?>_dismiss" name="resolution_note" rows="3" placeholder="Explain why this report is being dismissed..."></textarea>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="notify_reporter" id="notify_reporter<?php echo $report['id']; ?>_dismiss" checked>
                            <label class="form-check-label" for="notify_reporter<?php echo $report['id']; ?>_dismiss">
                                Notify the reporter that their report has been dismissed
                            </label>
                        </div>
                        
                        <div class="d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-danger">Dismiss Report</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <?php if ($report['report_type'] === 'book'): ?>
    <!-- Remove Book Modal -->
    <div class="modal fade" id="removeBookModal<?php echo $report['id']; ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="fas fa-trash-alt me-2"></i> Remove Book</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i> <strong>Warning:</strong> You are about to remove the book "<?php echo htmlspecialchars($report['target_name']); ?>" from the platform. This action cannot be undone.
                    </div>
                    
                    <form action="actions/process_report.php" method="post">
                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                        <input type="hidden" name="action" value="remove_book">
                        <input type="hidden" name="book_id" value="<?php echo $report['target_id']; ?>">
                        
                        <div class="mb-3">
                            <label for="removal_reason<?php echo $report['id']; ?>" class="form-label">Removal Reason</label>
                            <textarea class="form-control" id="removal_reason<?php echo $report['id']; ?>" name="removal_reason" rows="3" placeholder="Explain why this book is being removed..." required></textarea>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="notify_publisher" id="notify_publisher<?php echo $report['id']; ?>" checked>
                            <label class="form-check-label" for="notify_publisher<?php echo $report['id']; ?>">
                                Notify the publisher about this removal
                            </label>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="resolve_report" id="resolve_report_book<?php echo $report['id']; ?>" checked>
                            <label class="form-check-label" for="resolve_report_book<?php echo $report['id']; ?>">
                                Mark the report as resolved
                            </label>
                        </div>
                        
                        <div class="d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-danger">Remove Book</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php elseif ($report['report_type'] === 'user'): ?>
    <!-- Block User Modal -->
    <div class="modal fade" id="blockUserModal<?php echo $report['id']; ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="fas fa-ban me-2"></i> Block User</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i> <strong>Warning:</strong> You are about to block the user "<?php echo htmlspecialchars($report['target_name']); ?>" from the platform.
                    </div>
                    
                    <form action="actions/process_report.php" method="post">
                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                        <input type="hidden" name="action" value="block_user">
                        <input type="hidden" name="user_id" value="<?php echo $report['target_id']; ?>">
                        
                        <!-- Block duration is now permanent by default -->
                        
                        <div class="mb-3">
                            <label for="block_reason<?php echo $report['id']; ?>" class="form-label">Block Reason</label>
                            <textarea class="form-control" id="block_reason<?php echo $report['id']; ?>" name="block_reason" rows="3" placeholder="Explain why this user is being blocked..." required></textarea>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="notify_user" id="notify_user<?php echo $report['id']; ?>" checked>
                            <label class="form-check-label" for="notify_user<?php echo $report['id']; ?>">
                                Notify the user about this block
                            </label>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="resolve_report" id="resolve_report_user<?php echo $report['id']; ?>" checked>
                            <label class="form-check-label" for="resolve_report_user<?php echo $report['id']; ?>">
                                Mark the report as resolved
                            </label>
                        </div>
                        
                        <div class="d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-danger">Block User</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php elseif ($report['report_type'] === 'review'): ?>
    <!-- Remove Review Modal -->
    <div class="modal fade" id="removeReviewModal<?php echo $report['id']; ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="fas fa-trash-alt me-2"></i> Remove Review</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i> <strong>Warning:</strong> You are about to remove a review from the platform. This action cannot be undone.
                    </div>
                    
                    <form action="actions/process_report.php" method="post">
                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                        <input type="hidden" name="action" value="remove_review">
                        <input type="hidden" name="review_id" value="<?php echo $report['target_id']; ?>">
                        
                        <div class="mb-3">
                            <label for="removal_reason<?php echo $report['id']; ?>_review" class="form-label">Removal Reason</label>
                            <textarea class="form-control" id="removal_reason<?php echo $report['id']; ?>_review" name="removal_reason" rows="3" placeholder="Explain why this review is being removed..." required></textarea>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="notify_reviewer" id="notify_reviewer<?php echo $report['id']; ?>" checked>
                            <label class="form-check-label" for="notify_reviewer<?php echo $report['id']; ?>">
                                Notify the reviewer about this removal
                            </label>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="resolve_report" id="resolve_report_review<?php echo $report['id']; ?>" checked>
                            <label class="form-check-label" for="resolve_report_review<?php echo $report['id']; ?>">
                                Mark the report as resolved
                            </label>
                        </div>
                        
                        <div class="d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-danger">Remove Review</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php endforeach; ?>

<!-- Unblock Appeals Section for Moderators -->
<div class="card mb-4" id="appeals">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Moderator Unblock Appeals</h5>
        <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" data-bs-target="#appealsCollapse" aria-expanded="true" aria-controls="appealsCollapse">
            <i class="fas fa-chevron-down"></i>
        </button>
    </div>
    <div class="collapse show" id="appealsCollapse">
        <div class="card-body">
            <?php
            // Get pending appeals from moderators
            $moderatorAppeals = getPendingAppeals('moderator');
            
            if (count($moderatorAppeals) > 0):
            ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Moderator</th>
                                <th>Date Submitted</th>
                                <th>Type</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($moderatorAppeals as $appeal): ?>
                            <tr>
                                <td>
                                    <div>
                                        <strong><?php echo $appeal['name']; ?></strong>
                                    </div>
                                    <small class="text-muted"><?php echo $appeal['email']; ?></small>
                                </td>
                                <td><?php echo date('M d, Y H:i', strtotime($appeal['created_at'])); ?></td>
                                <td><span class="badge bg-secondary"><?php echo ucfirst($appeal['type']); ?></span></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#viewAppealModal<?php echo $appeal['id']; ?>">
                                        <i class="fas fa-eye" style="font-size: 1.4rem;"></i> View
                                    </button>
                                    
                                    <!-- View Appeal Modal -->
                                    <div class="modal fade" id="viewAppealModal<?php echo $appeal['id']; ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header bg-primary text-white">
                                                    <h5 class="modal-title">
                                                        <i class="fas fa-unlock-alt me-2" style="font-size: 1.4rem;"></i>
                                                        Account Unblock Appeal
                                                    </h5>
                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row mb-4">
                                                        <div class="col-md-6">
                                                            <h6 class="fw-bold">Moderator Information</h6>
                                                            <div class="mb-2">
                                                                <strong>Name:</strong> <?php echo $appeal['name']; ?>
                                                            </div>
                                                            <div class="mb-2">
                                                                <strong>Email:</strong> <?php echo $appeal['email']; ?>
                                                            </div>
                                                            <div>
                                                                <strong>Role:</strong> <?php echo ucfirst($appeal['role']); ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <h6 class="fw-bold">Appeal Information</h6>
                                                            <div class="mb-2">
                                                                <strong>Submitted:</strong> <?php echo date('F d, Y H:i', strtotime($appeal['created_at'])); ?>
                                                            </div>
                                                            <div>
                                                                <strong>Appeal Type:</strong> <?php echo ucfirst($appeal['type']); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="mb-4">
                                                        <h6 class="fw-bold">Appeal Reason</h6>
                                                        <div class="p-3 bg-light rounded">
                                                            <?php echo nl2br($appeal['reason']); ?>
                                                        </div>
                                                    </div>
                                                    
                                                    <?php if (!empty($appeal['additional_info'])): ?>
                                                    <div class="mb-4">
                                                        <h6 class="fw-bold">Additional Information</h6>
                                                        <div class="p-3 bg-light rounded">
                                                            <?php echo nl2br($appeal['additional_info']); ?>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                    
                                                    <form action="actions/process_appeal.php" method="post">
                                                        <input type="hidden" name="appeal_id" value="<?php echo $appeal['id']; ?>">
                                                        
                                                        <div class="mb-3">
                                                            <label for="response<?php echo $appeal['id']; ?>" class="form-label">Response Message (Optional)</label>
                                                            <textarea class="form-control" id="response<?php echo $appeal['id']; ?>" name="response" rows="3" placeholder="Enter a message to send to the moderator..."></textarea>
                                                            <div class="form-text">This message will be included in the notification sent to the moderator.</div>
                                                        </div>
                                                        
                                                        <div class="d-flex justify-content-end gap-2">
                                                            <button type="submit" name="action" value="reject" class="btn btn-danger">
                                                                <i class="fas fa-times-circle me-2"></i> Reject Appeal
                                                            </button>
                                                            <button type="submit" name="action" value="approve" class="btn btn-success">
                                                                <i class="fas fa-check-circle me-2"></i> Approve & Unblock
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <p class="mb-0"><i class="fas fa-info-circle me-2" style="font-size: 1.4rem;"></i> No pending unblock appeals from moderators at the moment.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Moderator License Applications Section -->
<div class="card mb-4" id="licenses">
    <div class="card-header bg-white">
        <h5 class="mb-0">Moderator License Applications</h5>
    </div>
    <div class="card-body">
        <?php
        // Get pending moderator licenses
        $pendingModeratorLicenses = getPendingLicenses('moderator');
        
        if (count($pendingModeratorLicenses) > 0):
        ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Application Date</th>
                            <th>Reason</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pendingModeratorLicenses as $license): ?>
                        <tr>
                            <td>
                                <div>
                                    <strong><?php echo $license['user_name']; ?></strong>
                                </div>
                                <small class="text-muted"><?php echo $license['user_email']; ?></small>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($license['created_at'])); ?></td>
                            <td><?php echo $license['reason'] ?? 'No reason provided'; ?></td>
                            <td>
                                <div class="btn-group">
                                    <form action="actions/process_license.php" method="POST">
                                        <input type="hidden" name="license_id" value="<?php echo $license['id']; ?>">
                                        <input type="hidden" name="status" value="approved">
                                        <button type="submit" class="btn btn-sm btn-success me-2">Approve</button>
                                    </form>
                                    
                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#rejectLicenseModal<?php echo $license['id']; ?>">
                                        Reject
                                    </button>
                                </div>
                                
                                <!-- Reject License Modal -->
                                <div class="modal fade" id="rejectLicenseModal<?php echo $license['id']; ?>" tabindex="-1" aria-labelledby="rejectLicenseModalLabel<?php echo $license['id']; ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="rejectLicenseModalLabel<?php echo $license['id']; ?>">Reject Moderator License</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="actions/process_license.php" method="POST">
                                                <div class="modal-body">
                                                    <input type="hidden" name="license_id" value="<?php echo $license['id']; ?>">
                                                    <input type="hidden" name="status" value="rejected">
                                                    
                                                    <div class="mb-3">
                                                        <label for="rejection_reason<?php echo $license['id']; ?>" class="form-label">Reason for Rejection:</label>
                                                        <textarea class="form-control" id="rejection_reason<?php echo $license['id']; ?>" name="rejection_reason" rows="4" required></textarea>
                                                        <div class="form-text">This message will be sent to the user as a notification.</div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" class="btn btn-danger">Reject Application</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <p>No pending moderator license applications at the moment.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- User Management Section -->
<div class="card mb-4" id="user-management">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">User Management</h5>
        <form action="index.php" method="GET" class="d-flex">
            <input type="hidden" name="page" value="dashboard">
            <input type="text" class="form-control form-control-sm me-2" name="search_user" placeholder="Search users...">
            <button type="submit" class="btn btn-sm btn-primary">Search</button>
        </form>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Joined</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Get users with search filter if provided
                    $search = isset($_GET['search_user']) ? $_GET['search_user'] : '';
                    
                    if (!empty($search)) {
                        $stmt = $conn->prepare("SELECT * FROM users WHERE name LIKE :search OR email LIKE :search ORDER BY id DESC LIMIT 20");
                        $searchParam = "%$search%";
                        $stmt->bindParam(':search', $searchParam);
                    } else {
                        $stmt = $conn->prepare("SELECT * FROM users ORDER BY id DESC LIMIT 20");
                    }
                    
                    $stmt->execute();
                    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach ($users as $user):
                    ?>
                    <tr>
                        <td><?php echo $user['name']; ?></td>
                        <td><?php echo $user['email']; ?></td>
                        <td>
                            <span class="badge bg-<?php 
                                echo ($user['role'] == 'admin') ? 'danger' : 
                                    (($user['role'] == 'moderator') ? 'warning' : 
                                    (($user['role'] == 'publisher') ? 'info' : 'secondary')); 
                            ?>">
                                <?php echo ucfirst($user['role']); ?>
                            </span>
                        </td>
                        <td>
                            <span class="badge bg-<?php 
                                echo ($user['status'] == 'active') ? 'success' : 
                                    (($user['status'] == 'blocked') ? 'danger' : 'warning'); 
                            ?>">
                                <?php echo ucfirst($user['status']); ?>
                            </span>
                        </td>
                        <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="userActionDropdown<?php echo $user['id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                    Actions
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="userActionDropdown<?php echo $user['id']; ?>">
                                    <?php if ($user['role'] != 'admin'): // Cannot modify admin accounts ?>
                                        <?php if ($user['status'] == 'active'): ?>
                                            <li>
                                                <form action="actions/block_user.php" method="POST">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <button type="submit" class="dropdown-item text-danger">Block User</button>
                                                </form>
                                            </li>
                                        <?php else: ?>
                                            <li>
                                                <form action="actions/unblock_user.php" method="POST">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <button type="submit" class="dropdown-item text-success">Unblock User</button>
                                                </form>
                                            </li>
                                        <?php endif; ?>
                                        
                                        <?php if ($user['role'] == 'user'): ?>
                                            <li>
                                                <form action="actions/promote_user.php" method="POST">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <input type="hidden" name="role" value="moderator">
                                                    <button type="submit" class="dropdown-item">Promote to Moderator</button>
                                                </form>
                                            </li>
                                            <li>
                                                <form action="actions/promote_user.php" method="POST">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <input type="hidden" name="role" value="publisher">
                                                    <button type="submit" class="dropdown-item">Promote to Publisher</button>
                                                </form>
                                            </li>
                                        <?php elseif ($user['role'] == 'moderator' || $user['role'] == 'publisher'): ?>
                                            <li>
                                                <form action="actions/demote_user.php" method="POST">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <button type="submit" class="dropdown-item">Demote to User</button>
                                                </form>
                                            </li>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                    <li><button type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#userDetailsModal<?php echo $user['id']; ?>">View Details</button></li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- My Books Section -->
<div class="card mb-4" id="my-books">
    <div class="card-header bg-white">
        <h5 class="mb-0">My Books</h5>
    </div>
    <div class="card-body">
        <?php
        // Get admin's purchased books
        $stmt = $conn->prepare("SELECT b.* FROM books b JOIN purchases p ON b.id = p.book_id WHERE p.user_id = :user_id ORDER BY p.purchase_date DESC");
        $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $stmt->execute();
        $adminBooks = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($adminBooks) > 0): 
        ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Cover</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Format</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($adminBooks as $book): ?>
                        <tr>
                            <td>
                                <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" alt="<?php echo $book['title']; ?>" class="img-thumbnail" style="width: 50px;">
                            </td>
                            <td><?php echo $book['title']; ?></td>
                            <td><?php echo $book['category']; ?></td>
                            <td>
                                <?php if ($book['pdf_path']): ?>
                                <span class="badge bg-info"><i class="fas fa-file-pdf me-1" style="font-size: 1.4rem;"></i> PDF</span>
                                <?php endif; ?>
                                
                                <?php if ($book['audio_path']): ?>
                                <span class="badge bg-warning"><i class="fas fa-headphones me-1" style="font-size: 1.4rem;"></i> Audio</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="index.php?page=book&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-primary" data-bs-toggle="tooltip" title="View Book">
                                        <i class="fas fa-eye" style="font-size: 1.4rem;"></i>
                                    </a>
                                    <?php if ($book['pdf_path']): ?>
                                    <a href="index.php?page=read&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-success" data-bs-toggle="tooltip" title="Read Book">
                                        <i class="fas fa-book-reader" style="font-size: 1.4rem;"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if ($book['audio_path']): ?>
                                    <a href="index.php?page=listen&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-warning" data-bs-toggle="tooltip" title="Listen to Book">
                                        <i class="fas fa-headphones" style="font-size: 1.4rem;"></i>
                                    </a>
                                    <?php endif; ?>
                                    
                                    <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#removeBookModal<?php echo $book['id']; ?>" title="Remove from Library">
                                        <i class="fas fa-trash-alt" style="font-size: 1.4rem;"></i>
                                    </button>
                                </div>
                                
                                <!-- Remove Book Modal -->
                                <div class="modal fade" id="removeBookModal<?php echo $book['id']; ?>" tabindex="-1" aria-labelledby="removeBookModalLabel<?php echo $book['id']; ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="removeBookModalLabel<?php echo $book['id']; ?>">Confirm Removal</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="alert alert-warning">
                                                    <i class="fas fa-exclamation-triangle me-2"></i> Warning
                                                </div>
                                                <p>Are you sure you want to remove <strong><?php echo $book['title']; ?></strong> from your library?</p>
                                                <p class="text-danger"><strong>This action cannot be undone.</strong> If you want to access this book again in the future, you will need to purchase it again.</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <form action="actions/remove_from_library.php" method="post">
                                                    <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
                                                    <button type="submit" class="btn btn-danger">Remove Book</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <p>You haven't purchased any books yet. Browse the collection and add some books to your library.</p>
                <a href="index.php?page=search" class="btn btn-primary mt-2">Browse Books</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- User Details Modals -->
<?php foreach ($users as $user): ?>
<div class="modal fade" id="userDetailsModal<?php echo $user['id']; ?>" tabindex="-1" aria-labelledby="userDetailsModalLabel<?php echo $user['id']; ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="userDetailsModalLabel<?php echo $user['id']; ?>">User Details: <?php echo htmlspecialchars($user['name']); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="fw-bold mb-3">Basic Information</h6>
                        <div class="mb-3">
                            <p><strong>Name:</strong> <?php echo htmlspecialchars($user['name']); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                            <p><strong>Role:</strong> 
                                <span class="badge bg-<?php 
                                    echo ($user['role'] == 'admin') ? 'danger' : 
                                        (($user['role'] == 'moderator') ? 'warning' : 
                                        (($user['role'] == 'publisher') ? 'info' : 'secondary')); 
                                ?>">
                                    <?php echo ucfirst($user['role']); ?>
                                </span>
                            </p>
                            <p><strong>Status:</strong> 
                                <span class="badge bg-<?php 
                                    echo ($user['status'] == 'active') ? 'success' : 
                                        (($user['status'] == 'blocked') ? 'danger' : 'warning'); 
                                ?>">
                                    <?php echo ucfirst($user['status']); ?>
                                </span>
                            </p>
                            <p><strong>Joined:</strong> <?php echo date('F d, Y', strtotime($user['created_at'])); ?></p>
                            <?php if (isset($user['last_login'])): ?>
                                <p><strong>Last Login:</strong> <?php echo date('F d, Y H:i', strtotime($user['last_login'])); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <?php
                        // Get user activity stats
                        $stmt = $conn->prepare("SELECT COUNT(*) FROM purchases WHERE user_id = :user_id");
                        $stmt->bindParam(':user_id', $user['id']);
                        $stmt->execute();
                        $purchaseCount = $stmt->fetchColumn();
                        
                        $stmt = $conn->prepare("SELECT COUNT(*) FROM feedback WHERE user_id = :user_id");
                        $stmt->bindParam(':user_id', $user['id']);
                        $stmt->execute();
                        $reviewCount = $stmt->fetchColumn();
                        
                        // For publishers, get book count
                        $bookCount = 0;
                        if ($user['role'] == 'publisher') {
                            $stmt = $conn->prepare("SELECT COUNT(*) FROM books WHERE publisher_id = :user_id");
                            $stmt->bindParam(':user_id', $user['id']);
                            $stmt->execute();
                            $bookCount = $stmt->fetchColumn();
                        }
                        ?>
                        
                        <h6 class="fw-bold mb-3">User Activity</h6>
                        <div class="mb-3">
                            <p><strong>Books Purchased:</strong> <?php echo $purchaseCount; ?></p>
                            <p><strong>Reviews Written:</strong> <?php echo $reviewCount; ?></p>
                            <?php if ($user['role'] == 'publisher'): ?>
                                <p><strong>Books Published:</strong> <?php echo $bookCount; ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <hr>
                
                <!-- User Management Actions -->
                <?php if ($user['role'] != 'admin'): // Cannot modify admin accounts ?>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <h6 class="fw-bold mb-0">User Management Actions</h6>
                </div>
                
                <div class="row mt-3">
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <div class="card-header bg-light">Status Management</div>
                            <div class="card-body">
                                <?php if ($user['status'] == 'active'): ?>
                                    <form action="actions/block_user.php" method="POST">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <div class="mb-3">
                                            <label for="block_reason<?php echo $user['id']; ?>" class="form-label">Block Reason:</label>
                                            <textarea class="form-control" id="block_reason<?php echo $user['id']; ?>" name="block_reason" rows="2" required></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-danger">Block User</button>
                                    </form>
                                <?php else: ?>
                                    <form action="actions/unblock_user.php" method="POST">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <button type="submit" class="btn btn-success">Unblock User</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card mb-3">
                            <div class="card-header bg-light">Role Management</div>
                            <div class="card-body">
                                <?php if ($user['role'] == 'user'): ?>
                                    <div class="d-flex gap-2 mb-2">
                                        <form action="actions/promote_user.php" method="POST">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="role" value="moderator">
                                            <button type="submit" class="btn btn-warning">Promote to Moderator</button>
                                        </form>
                                        
                                        <form action="actions/promote_user.php" method="POST">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="role" value="publisher">
                                            <button type="submit" class="btn btn-info">Promote to Publisher</button>
                                        </form>
                                    </div>
                                <?php elseif ($user['role'] == 'moderator' || $user['role'] == 'publisher'): ?>
                                    <form action="actions/demote_user.php" method="POST">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <button type="submit" class="btn btn-secondary">Demote to User</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Delete User Option -->
                <div class="mt-3">
                    <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteUserModal<?php echo $user['id']; ?>" data-bs-dismiss="modal">
                        <i class="fas fa-trash-alt me-2"></i> Delete User Account
                    </button>
                </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Delete User Modal -->
<div class="modal fade" id="deleteUserModal<?php echo $user['id']; ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title"><i class="fas fa-exclamation-triangle me-2"></i> Delete User Account</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-danger">
                    <p><strong>Warning:</strong> You are about to permanently delete the account for <strong><?php echo htmlspecialchars($user['name']); ?></strong>.</p>
                    <p>This action cannot be undone. All user data, including purchases, reviews, and personal information will be permanently removed.</p>
                </div>
                
                <form action="actions/delete_user.php" method="POST">
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                    
                    <div class="mb-3">
                        <label for="delete_confirmation<?php echo $user['id']; ?>" class="form-label">Type "DELETE" to confirm:</label>
                        <input type="text" class="form-control" id="delete_confirmation<?php echo $user['id']; ?>" name="delete_confirmation" required pattern="DELETE">
                        <div class="form-text">Please type DELETE in all caps to confirm.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="delete_reason<?php echo $user['id']; ?>" class="form-label">Reason for deletion:</label>
                        <textarea class="form-control" id="delete_reason<?php echo $user['id']; ?>" name="delete_reason" rows="3" required></textarea>
                    </div>
                    
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#userDetailsModal<?php echo $user['id']; ?>">Cancel</button>
                        <button type="submit" class="btn btn-danger">Delete Account</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>

<!-- Book Management Section -->
<div class="card mb-4" id="book-management">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Book Management</h5>
        <form action="index.php" method="GET" class="d-flex">
            <input type="hidden" name="page" value="dashboard">
            <input type="text" name="search_book" class="form-control form-control-sm me-2" placeholder="Search books..." value="<?php echo isset($_GET['search_book']) ? htmlspecialchars($_GET['search_book']) : ''; ?>">
            <button type="submit" class="btn btn-sm btn-primary">Search</button>
        </form>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Cover</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Publisher</th>
                        <th>Price</th>
                        <th>Formats</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Get books with search filter if provided
                    $search = isset($_GET['search_book']) ? $_GET['search_book'] : '';
                    
                    if (!empty($search)) {
                        $stmt = $conn->prepare("SELECT b.*, u.name as publisher_name 
                                              FROM books b 
                                              JOIN users u ON b.publisher_id = u.id 
                                              WHERE b.title LIKE :search OR b.author LIKE :search 
                                              ORDER BY b.id DESC LIMIT 20");
                        $searchParam = "%$search%";
                        $stmt->bindParam(':search', $searchParam);
                    } else {
                        $stmt = $conn->prepare("SELECT b.*, u.name as publisher_name 
                                              FROM books b 
                                              JOIN users u ON b.publisher_id = u.id 
                                              ORDER BY b.id DESC LIMIT 20");
                    }
                    
                    $stmt->execute();
                    $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach ($books as $book):
                    ?>
                    <tr>
                        <td>
                            <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" alt="<?php echo $book['title']; ?>" class="img-thumbnail" style="width: 50px;">
                        </td>
                        <td><?php echo $book['title']; ?></td>
                        <td><?php echo $book['author']; ?></td>
                        <td><?php echo $book['publisher_name']; ?></td>
                        <td><?php echo formatPrice($book['price']); ?></td>
                        <td>
                            <?php if ($book['pdf_path']): ?>
                            <span class="badge bg-info"><i class="fas fa-file-pdf"></i> PDF</span>
                            <?php endif; ?>
                            
                            <?php if ($book['audio_path']): ?>
                            <span class="badge bg-warning"><i class="fas fa-headphones"></i> Audio</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group">
                                <a href="index.php?page=book&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-primary" data-bs-toggle="tooltip" title="View Book">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="index.php?page=edit_book&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-primary" data-bs-toggle="tooltip" title="Edit Book">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteBookModal<?php echo $book['id']; ?>" data-bs-toggle="tooltip" title="Delete Book">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                            
                            <!-- Delete Book Modal -->
                            <div class="modal fade" id="deleteBookModal<?php echo $book['id']; ?>" tabindex="-1" aria-labelledby="deleteBookModalLabel<?php echo $book['id']; ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="deleteBookModalLabel<?php echo $book['id']; ?>">Confirm Deletion</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Are you sure you want to delete <strong><?php echo $book['title']; ?></strong>?</p>
                                            <p class="text-danger">This action cannot be undone. All associated purchases, reviews, and bookmarks will also be deleted.</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <a href="actions/remove_book.php?id=<?php echo $book['id']; ?>" class="btn btn-danger">Delete Book</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>