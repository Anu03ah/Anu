<h2 class="mb-4">My Dashboard</h2>

<div class="row mb-4">
    <div class="col-md-6">
        <div class="card dashboard-card">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <div class="dashboard-icon me-3">
                        <i class="fas fa-user"></i>
                    </div>
                    <div>
                        <h5 class="card-title mb-0">Welcome, <?php echo $_SESSION['user_name']; ?></h5>
                        <p class="text-muted mb-0">User Account</p>
                    </div>
                </div>
                <a href="index.php?page=profile" class="btn btn-outline-primary btn-sm">Edit Profile</a>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card dashboard-card">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <div class="dashboard-icon me-3">
                        <i class="fas fa-book"></i>
                    </div>
                    <div>
                        <?php
                        $purchasedBooks = getPurchasedBooks($_SESSION['user_id']);
                        $bookCount = count($purchasedBooks);
                        ?>
                        <h5 class="card-title mb-0"><?php echo $bookCount; ?> Books</h5>
                        <p class="text-muted mb-0">In Your Library</p>
                    </div>
                </div>
                <a href="#my-books" class="btn btn-outline-primary btn-sm">View Library</a>
            </div>
        </div>
    </div>
</div>

<!-- License Applications -->
<div class="card mb-4">
    <div class="card-header bg-white">
        <h5 class="mb-0">My Licenses</h5>
    </div>
    <div class="card-body">
        <?php
        $licenses = getUserLicenses($_SESSION['user_id']);
        if (count($licenses) > 0):
        ?>
            <div class="row">
                <?php foreach ($licenses as $license): ?>
                <div class="col-md-6 mb-3">
                    <div class="card license-card <?php echo $license['status']; ?>">
                        <div class="card-body">
                            <h6 class="card-title"><?php echo ucfirst($license['type']); ?> License</h6>
                            <p class="card-text">
                                Status: <span class="badge bg-<?php echo ($license['status'] == 'approved') ? 'success' : (($license['status'] == 'rejected') ? 'danger' : 'warning'); ?>">
                                    <?php echo ucfirst($license['status']); ?>
                                </span>
                            </p>
                            <p class="card-text small text-muted">
                                Applied on: <?php echo date('M d, Y', strtotime($license['created_at'])); ?>
                                <?php if ($license['status'] != 'pending' && $license['approved_by']): ?>
                                <br>Processed by: <?php echo $license['approved_by_name']; ?>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p>You don't have any license applications yet.</p>
        <?php endif; ?>
        
        <div class="mt-3">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#applyLicenseModal">
                Apply for License
            </button>
        </div>
    </div>
</div>

<!-- My Books Section -->
<div class="card mb-4" id="my-books">
    <div class="card-header bg-white">
        <h5 class="mb-0">My Books</h5>
    </div>
    <div class="card-body">
        <?php if (count($purchasedBooks) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Cover</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Format</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($purchasedBooks as $book): ?>
                        <tr>
                            <td>
                                <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" alt="<?php echo $book['title']; ?>" class="img-thumbnail" style="width: 50px;">
                            </td>
                            <td><?php echo $book['title']; ?></td>
                            <td><?php echo $book['author']; ?></td>
                            <td>
                                <?php if ($book['pdf_path']): ?>
                                <span class="badge bg-info"><i class="fas fa-file-pdf me-1" style="font-size: 1.4rem;"></i> PDF</span>
                                <?php endif; ?>
                                
                                <?php if ($book['audio_path']): ?>
                                <span class="badge bg-warning"><i class="fas fa-headphones me-1" style="font-size: 1.4rem;"></i> Audio</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <div class="btn-group">
                                    <a href="index.php?page=book&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-primary" data-bs-toggle="tooltip" title="View Book">
                                        <i class="fas fa-eye" style="font-size: 1.4rem;"></i>
                                    </a>
                                    
                                    <?php if ($book['pdf_path']): ?>
                                    <a href="index.php?page=read&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-success" data-bs-toggle="tooltip" title="Read Book">
                                        <i class="fas fa-book-reader" style="font-size: 1.4rem;"></i>
                                    </a>
                                    <?php endif; ?>
                                    
                                    <?php if ($book['audio_path']): ?>
                                    <a href="index.php?page=listen&id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-warning" data-bs-toggle="tooltip" title="Listen to Book">
                                        <i class="fas fa-headphones" style="font-size: 1.4rem;"></i>
                                    </a>
                                    <?php endif; ?>
                                    
                                    <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#removeBookModal<?php echo $book['id']; ?>" title="Remove from Library">
                                        <i class="fas fa-trash-alt" style="font-size: 1.4rem;"></i>
                                    </button>
                                </div>
                                
                                <!-- Remove Book Modal -->
                                <div class="modal fade" id="removeBookModal<?php echo $book['id']; ?>" tabindex="-1" aria-labelledby="removeBookModalLabel<?php echo $book['id']; ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="removeBookModalLabel<?php echo $book['id']; ?>">Confirm Removal</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="alert alert-warning">
                                                    <i class="fas fa-exclamation-triangle me-2"></i> Warning
                                                </div>
                                                <p>Are you sure you want to remove <strong><?php echo $book['title']; ?></strong> from your library?</p>
                                                <p class="text-danger"><strong>This action cannot be undone.</strong> If you want to access this book again in the future, you will need to purchase it again.</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                <form action="actions/remove_from_library.php" method="post">
                                                    <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
                                                    <button type="submit" class="btn btn-danger">Remove Book</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <p>You haven't purchased any books yet.</p>
                <a href="index.php?page=search" class="btn btn-primary mt-2">Browse Books</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Apply for License Modal -->
<div class="modal fade" id="applyLicenseModal" tabindex="-1" aria-labelledby="applyLicenseModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="applyLicenseModalLabel">Apply for License</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="actions/apply_license.php" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="license_type" class="form-label">License Type</label>
                        <select class="form-select" id="license_type" name="license_type" required>
                            <option value="">Select license type</option>
                            <option value="publisher">Publisher License</option>
                            <option value="moderator">Moderator License</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="reason" class="form-label">Why do you want this license?</label>
                        <textarea class="form-control" id="reason" name="reason" rows="4" required></textarea>
                    </div>
                    
                    <div class="alert alert-info">
                        <h6>License Information:</h6>
                        <p><strong>Publisher License:</strong> Allows you to upload and sell books on our platform.</p>
                        <p><strong>Moderator License:</strong> Allows you to handle user complaints and manage publisher applications.</p>
                        <p>Note: Moderator licenses can only be approved by Admins, while Publisher licenses can be approved by Admins or Moderators.</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit Application</button>
                </div>
            </form>
        </div>
    </div>
</div>
