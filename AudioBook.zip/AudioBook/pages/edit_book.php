<?php
// Get book ID from URL
$book_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// If no book ID provided, redirect to dashboard
if ($book_id <= 0) {
    setMessage('Invalid book ID', 'error');
    header('Location: index.php?page=dashboard');
    exit();
}

// Get book details
$book = getBookById($book_id);

// If book not found, redirect to dashboard
if (!$book) {
    setMessage('Book not found', 'error');
    header('Location: index.php?page=dashboard');
    exit();
}

// Check if user has permission to edit this book (admin or publisher of the book)
if (!isAdmin() && (!isPublisher() || $book['publisher_id'] != $_SESSION['user_id'])) {
    setMessage('You do not have permission to edit this book', 'error');
    header('Location: index.php?page=dashboard');
    exit();
}
?>

<div class="container">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2>Edit Book: <?php echo $book['title']; ?></h2>
                <a href="<?php echo isAdmin() ? 'index.php?page=dashboard&section=admin' : 'index.php?page=dashboard'; ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <form action="actions/update_book.php" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                        <input type="hidden" name="book_id" value="<?php echo $book_id; ?>">
                        
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <div class="text-center mb-3">
                                    <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" alt="<?php echo $book['title']; ?>" class="img-fluid rounded" style="max-height: 300px;" id="cover-preview">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="cover" class="form-label">Change Cover Image</label>
                                    <input type="file" class="form-control" id="cover" name="cover" accept="image/*" onchange="previewCover(this)">
                                    <div class="form-text">Leave empty to keep current cover.</div>
                                </div>
                            </div>
                            
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="title" class="form-label">Book Title</label>
                                            <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($book['title']); ?>" required>
                                            <div class="invalid-feedback">
                                                Please enter a book title.
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="author" class="form-label">Author</label>
                                            <input type="text" class="form-control" id="author" name="author" value="<?php echo htmlspecialchars($book['author']); ?>" required>
                                            <div class="invalid-feedback">
                                                Please enter the author's name.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="category" class="form-label">Category</label>
                                            <select class="form-select" id="category" name="category" required>
                                                <option value="">Select a category</option>
                                                <?php
                                                $categories = [
                                                    'Fiction', 'Non-Fiction', 'Science Fiction', 'Fantasy', 
                                                    'Mystery', 'Romance', 'Thriller', 'Biography', 
                                                    'History', 'Self-Help', 'Business', 'Children', 
                                                    'Young Adult', 'Other'
                                                ];
                                                
                                                foreach ($categories as $category) {
                                                    $selected = ($book['category'] == $category) ? 'selected' : '';
                                                    echo "<option value=\"$category\" $selected>$category</option>";
                                                }
                                                ?>
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select a category.
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="price" class="form-label">Price (₹)</label>
                                            <input type="number" class="form-control" id="price" name="price" min="0" step="0.01" value="<?php echo $book['price']; ?>" required>
                                            <div class="invalid-feedback">
                                                Please enter a valid price.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="description" class="form-label">Book Description</label>
                                    <textarea class="form-control" id="description" name="description" rows="5" required><?php echo htmlspecialchars($book['description']); ?></textarea>
                                    <div class="invalid-feedback">
                                        Please enter a book description.
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="pdf_file" class="form-label">Replace PDF File</label>
                                    <input type="file" class="form-control" id="pdf_file" name="pdf_file" accept=".pdf">
                                    <div class="form-text">
                                        <?php if ($book['pdf_path']): ?>
                                            Current PDF: <?php echo basename($book['pdf_path']); ?><br>
                                            Leave empty to keep current PDF.
                                        <?php else: ?>
                                            No PDF currently uploaded. Upload one if desired.
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="audio_file" class="form-label">Replace Audio File</label>
                                    <input type="file" class="form-control" id="audio_file" name="audio_file" accept=".mp3,.wav">
                                    <div class="form-text">
                                        <?php if ($book['audio_path']): ?>
                                            Current Audio: <?php echo basename($book['audio_path']); ?><br>
                                            Leave empty to keep current audio.
                                        <?php else: ?>
                                            No audio currently uploaded. Upload one if desired.
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="preview_enabled" name="preview_enabled" <?php echo $book['preview_enabled'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="preview_enabled">Enable Preview</label>
                                    <div class="form-text">Allow users to preview the first few pages or first minute of audio before purchasing.</div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="download_allowed" name="download_allowed" <?php echo $book['download_allowed'] ? 'checked' : ''; ?> onchange="toggleAgreement(this)">
                                    <label class="form-check-label" for="download_allowed">Allow Downloads</label>
                                    <div class="form-text">Allow users to download the book after purchase.</div>
                                </div>
                            </div>
                        </div>
                        
                        <div id="download-agreement" style="display: <?php echo $book['download_allowed'] ? 'block' : 'none'; ?>;">
                            <div class="alert alert-danger">
                                <h6>Download Permission Agreement</h6>
                                <p>By enabling downloads for your book, you acknowledge the following:</p>
                                <ol>
                                    <li>You understand that allowing downloads increases the risk of unauthorized distribution (piracy).</li>
                                    <li>You accept full responsibility for any piracy or unauthorized distribution of your content.</li>
                                    <li>AudioBook platform will not be held liable for any piracy or unauthorized distribution of your content.</li>
                                </ol>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="terms_signed" name="terms_signed" <?php echo $book['terms_signed'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="terms_signed">I agree to these terms</label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                            <a href="<?php echo isAdmin() ? 'index.php?page=dashboard&section=admin' : 'index.php?page=dashboard'; ?>" class="btn btn-secondary">Cancel</a>
                            <button type="submit" class="btn btn-primary">Update Book</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Function to toggle the download agreement section
function toggleAgreement(checkbox) {
    const agreementSection = document.getElementById('download-agreement');
    if (checkbox.checked) {
        agreementSection.style.display = 'block';
    } else {
        agreementSection.style.display = 'none';
        // Uncheck the terms agreement checkbox when download is disabled
        document.getElementById('terms_signed').checked = false;
    }
}

// Function to preview cover image
function previewCover(input) {
    const preview = document.getElementById('cover-preview');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            preview.src = e.target.result;
        }
        
        reader.readAsDataURL(input.files[0]);
    }
}

// Form validation
(function() {
    'use strict';
    
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation');
    
    // Loop over them and prevent submission
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });
})();
</script>
