<?php
// Determine which dashboard to show based on user role
$role = $_SESSION['user_role'];

// Check if a specific section is requested
$section = isset($_GET['section']) ? sanitize($_GET['section']) : '';

// For admin and moderator, handle special sections
if (($role === ROLE_ADMIN || $role === ROLE_MODERATOR) && $section === 'report_history') {
    include_once 'dashboard/report_history.php';
} else {
    // Include appropriate dashboard
    switch ($role) {
        case ROLE_ADMIN:
            include_once 'dashboard/admin_dashboard.php';
            break;
        case ROLE_MODERATOR:
            include_once 'dashboard/moderator_dashboard.php';
            // Add special script for fixing modal conflicts in moderator dashboard
            echo '<script src="assets/js/report-modal-fix.js"></script>';
            break;
        case ROLE_PUBLISHER:
            include_once 'dashboard/publisher_dashboard.php';
            break;
        default:
            include_once 'dashboard/user_dashboard.php';
    }
}
?>
