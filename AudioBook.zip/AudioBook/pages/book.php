<?php
// Get book ID from URL
$book_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$show_auth = isset($_GET['show_auth']) ? true : false;

// If no book ID provided, redirect to home
if ($book_id <= 0) {
    setMessage('Invalid book ID', 'error');
    header('Location: index.php');
    exit();
}

// Get book details
$book = getBookById($book_id);

// If book not found, redirect to home
if (!$book) {
    setMessage('Book not found', 'error');
    header('Location: index.php');
    exit();
}

// Check if user has purchased this book or is the publisher
$hasPurchased = false;
$isPublisherOfBook = false;

if (isLoggedIn()) {
    $hasPurchased = hasPurchasedBook($_SESSION['user_id'], $book_id);
    
    // Check if the logged-in user is the publisher of this book
    if (isPublisher() && $book['publisher_id'] == $_SESSION['user_id']) {
        $isPublisherOfBook = true;
        // Publishers automatically have access to their own books
        $hasPurchased = true;
    }
}

// Get book ratings
$averageRating = getAverageRating($book_id);
$ratingCount = getRatingCount($book_id);

// Get book feedback/reviews
$stmt = $conn->prepare("SELECT f.*, u.name as user_name 
                       FROM feedback f 
                       JOIN users u ON f.user_id = u.id 
                       WHERE f.book_id = :book_id 
                       ORDER BY f.created_at DESC");
$stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
$stmt->execute();
$reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="row">
    <!-- Book Details -->
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-4 mb-md-0">
                        <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" class="img-fluid rounded" alt="<?php echo $book['title']; ?>">
                        
                        <div class="d-grid gap-2 mt-3">
                            <?php if (!$hasPurchased): ?>
                                <?php if ($book['price'] > 0): ?>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#purchaseModal">
                                    <i class="fas fa-shopping-cart me-1"></i> Purchase (<?php echo formatPrice($book['price']); ?>)
                                </button>
                                <?php else: ?>
                                <a href="actions/add_free_book.php?id=<?php echo $book_id; ?>" class="btn btn-success">
                                    <i class="fas fa-plus me-1"></i> Add to Library
                                </a>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if ($book['pdf_path']): ?>
                                    <a href="index.php?page=read&id=<?php echo $book_id; ?>" class="btn btn-info">
                                        <i class="fas fa-book-reader me-1"></i> Read PDF
                                    </a>
                                <?php endif; ?>
                                
                                <?php if ($book['audio_path']): ?>
                                    <a href="index.php?page=listen&id=<?php echo $book_id; ?>" class="btn btn-warning">
                                        <i class="fas fa-headphones me-1"></i> Listen Audio
                                    </a>
                                <?php endif; ?>
                                
                                <?php if ($book['download_allowed']): ?>
                                    <?php if ($book['pdf_path']): ?>
                                        <a href="actions/download.php?type=pdf&id=<?php echo $book_id; ?>" class="btn btn-outline-primary">
                                            <i class="fas fa-file-pdf me-1"></i> Download PDF
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php if ($book['audio_path']): ?>
                                        <a href="actions/download.php?type=audio&id=<?php echo $book_id; ?>" class="btn btn-outline-primary">
                                            <i class="fas fa-file-audio me-1"></i> Download Audio
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-md-8">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h2><?php echo $book['title']; ?></h2>
                                <p class="text-muted">By <?php echo $book['author']; ?></p>
                            </div>
                            <?php if (isLoggedIn()): ?>
                            <button class="btn btn-sm btn-outline-danger" 
                                    data-bs-toggle="report-modal" 
                                    data-report-type="book" 
                                    data-target-id="<?php echo $book_id; ?>" 
                                    data-target-name="<?php echo htmlspecialchars($book['title']); ?>">
                                <i class="fas fa-flag"></i> Report
                            </button>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-3">
                            <div class="d-flex align-items-center">
                                <div class="me-2">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <?php if ($i <= $averageRating): ?>
                                            <i class="fas fa-star text-warning"></i>
                                        <?php elseif ($i - 0.5 <= $averageRating): ?>
                                            <i class="fas fa-star-half-alt text-warning"></i>
                                        <?php else: ?>
                                            <i class="far fa-star text-warning"></i>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </div>
                                <div>
                                    <span class="fw-bold"><?php echo number_format($averageRating, 1); ?></span>
                                    <span class="text-muted">(<?php echo $ratingCount; ?> reviews)</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <span class="badge bg-primary"><?php echo $book['category']; ?></span>
                            
                            <?php if ($book['pdf_path']): ?>
                                <span class="badge bg-info"><i class="fas fa-file-pdf me-1"></i> PDF</span>
                            <?php endif; ?>
                            
                            <?php if ($book['audio_path']): ?>
                                <span class="badge bg-warning"><i class="fas fa-headphones me-1"></i> Audio</span>
                            <?php endif; ?>
                            
                            <?php if ($book['download_allowed']): ?>
                                <span class="badge bg-success"><i class="fas fa-download me-1"></i> Downloadable</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-3">
                            <h5>Description</h5>
                            <p><?php echo nl2br($book['description']); ?></p>
                        </div>
                        
                        <div class="mb-3">
                            <h5>Uploader</h5>
                            <div class="dropdown">
                                <a href="#" class="text-decoration-none dropdown-toggle" id="uploaderDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    <?php echo $book['publisher_name']; ?>
                                </a>
                                <div class="dropdown-menu p-3" aria-labelledby="uploaderDropdown" style="min-width: 250px;">
                                    <div class="mb-2">
                                        <h6 class="dropdown-header px-0">Uploader Details</h6>
                                        <p class="mb-1"><strong>Name:</strong> <?php echo $book['publisher_name']; ?></p>
                                        <?php 
                                        // Get publisher email
                                        $stmt = $conn->prepare("SELECT email FROM users WHERE id = :publisher_id");
                                        $stmt->bindParam(':publisher_id', $book['publisher_id'], PDO::PARAM_INT);
                                        $stmt->execute();
                                        $publisherEmail = $stmt->fetchColumn();
                                        ?>
                                        <p class="mb-1"><strong>Email:</strong> <?php echo $publisherEmail; ?></p>
                                    </div>
                                    <div class="dropdown-divider"></div>
                                    <div class="d-grid">
                                        <?php if (isLoggedIn()): ?>
                                        <button class="btn btn-sm btn-outline-danger" 
                                                data-bs-toggle="report-modal" 
                                                data-report-type="user" 
                                                data-target-id="<?php echo $book['publisher_id']; ?>" 
                                                data-target-name="<?php echo htmlspecialchars($book['publisher_name']); ?>">
                                            <i class="fas fa-flag me-1" style="font-size: 1.4rem;"></i> Report Uploader
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <h5>Published On</h5>
                            <p><?php echo date('F d, Y', strtotime($book['created_at'])); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Preview Section -->
        <?php if ($book['preview_enabled'] && !$hasPurchased): ?>
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Preview</h5>
                </div>
                <div class="card-body">
                    <?php if ($book['pdf_path']): ?>
                        <div class="mb-3">
                            <h6><i class="fas fa-file-pdf me-1"></i> PDF Preview</h6>
                            <p>Read the first few pages of this book for free.</p>
                            <a href="index.php?page=preview&type=pdf&id=<?php echo $book_id; ?>" class="btn btn-outline-primary">
                                View PDF Preview
                            </a>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($book['audio_path']): ?>
                        <div>
                            <h6><i class="fas fa-headphones me-1"></i> Audio Preview</h6>
                            <p>Listen to the first minute of this book for free.</p>
                            <a href="index.php?page=preview&type=audio&id=<?php echo $book_id; ?>" class="btn btn-outline-primary">
                                Listen to Audio Preview
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Reviews Section -->
        <div class="card mb-4">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Reviews</h5>
                <?php if ($hasPurchased): ?>
                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#reviewModal">
                        <i class="fas fa-star me-1"></i> Write a Review
                    </button>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if (count($reviews) > 0): ?>
                    <?php foreach ($reviews as $review): ?>
                        <div class="border-bottom pb-3 mb-3">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <div class="reviewer-container">
                                        <a href="#" class="fw-bold text-decoration-none" onclick="toggleReviewerDetails(<?php echo $review['id']; ?>); return false;">
                                            <?php echo $review['user_name']; ?> <i class="fas fa-chevron-down reviewer-toggle-icon" id="reviewerToggleIcon<?php echo $review['id']; ?>"></i>
                                        </a>
                                        
                                        <!-- Reviewer details section that appears below the name -->
                                        <div class="reviewer-details mt-2 p-3 border rounded" id="reviewerDetails<?php echo $review['id']; ?>" style="display: none; background-color: #f8f9fa;">
                                            <div class="mb-2">
                                                <h6 class="mb-2">Reviewer Details</h6>
                                                <p class="mb-1"><strong>Name:</strong> <?php echo $review['user_name']; ?></p>
                                                <?php 
                                                // Get reviewer email
                                                $stmt = $conn->prepare("SELECT email FROM users WHERE id = :user_id");
                                                $stmt->bindParam(':user_id', $review['user_id'], PDO::PARAM_INT);
                                                $stmt->execute();
                                                $reviewerEmail = $stmt->fetchColumn();
                                                ?>
                                                <p class="mb-1"><strong>Email:</strong> <?php echo $reviewerEmail; ?></p>
                                            </div>
                                            <?php if (isLoggedIn()): ?>
                                            <div class="border-top my-2 pt-2"></div>
                                            <div class="d-grid">
                                                <button class="btn btn-sm btn-outline-danger" 
                                                        data-bs-toggle="report-modal" 
                                                        data-report-type="user" 
                                                        data-target-id="<?php echo $review['user_id']; ?>" 
                                                        data-target-name="<?php echo htmlspecialchars($review['user_name']); ?>">
                                                    <i class="fas fa-flag me-1"></i> Report Reviewer
                                                </button>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="text-warning">
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <?php if ($i <= $review['rating']): ?>
                                                <i class="fas fa-star"></i>
                                            <?php else: ?>
                                                <i class="far fa-star"></i>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center">
                                    <small class="text-muted me-2"><?php echo date('M d, Y', strtotime($review['created_at'])); ?></small>
                                    <?php if (isLoggedIn()): ?>
                                    <button class="btn btn-sm btn-link text-danger p-0" 
                                            data-bs-toggle="report-modal" 
                                            data-report-type="review" 
                                            data-target-id="<?php echo $review['id']; ?>" 
                                            data-target-name="Review by <?php echo htmlspecialchars($review['user_name']); ?>">
                                        <i class="fas fa-flag"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <p class="mb-0"><?php echo nl2br($review['comment']); ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted">No reviews yet. Be the first to review this book!</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Sidebar -->
    <div class="col-md-4">
        <!-- Related Books -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">Similar Books</h5>
            </div>
            <div class="card-body">
                <?php
                // Get books in the same category
                $stmt = $conn->prepare("SELECT b.*, u.name as publisher_name 
                                      FROM books b 
                                      JOIN users u ON b.publisher_id = u.id 
                                      WHERE b.category = :category AND b.id != :book_id 
                                      ORDER BY b.created_at DESC 
                                      LIMIT 3");
                $stmt->bindParam(':category', $book['category'], PDO::PARAM_STR);
                $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
                $stmt->execute();
                $similarBooks = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (count($similarBooks) > 0):
                    foreach ($similarBooks as $similarBook):
                ?>
                    <div class="d-flex mb-3">
                        <div class="flex-shrink-0">
                            <img src="<?php echo $similarBook['cover_path'] ? $similarBook['cover_path'] : 'assets/images/default-cover.jpg'; ?>" alt="<?php echo $similarBook['title']; ?>" class="img-thumbnail" style="width: 70px;">
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="mb-0"><a href="index.php?page=book&id=<?php echo $similarBook['id']; ?>"><?php echo $similarBook['title']; ?></a></h6>
                            <small class="text-muted">By <?php echo $similarBook['author']; ?></small>
                            <div>
                                <?php
                                $similarBookRating = getAverageRating($similarBook['id']);
                                for ($i = 1; $i <= 5; $i++):
                                    if ($i <= $similarBookRating):
                                ?>
                                    <i class="fas fa-star text-warning small"></i>
                                <?php else: ?>
                                    <i class="far fa-star text-warning small"></i>
                                <?php endif; endfor; ?>
                                <span class="small">(<?php echo getRatingCount($similarBook['id']); ?>)</span>
                            </div>
                        </div>
                    </div>
                <?php
                    endforeach;
                else:
                ?>
                    <p class="text-muted">No similar books found.</p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- More by Author -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">More by <?php echo $book['author']; ?></h5>
            </div>
            <div class="card-body">
                <?php
                // Get books by the same author
                $stmt = $conn->prepare("SELECT b.*, u.name as publisher_name 
                                      FROM books b 
                                      JOIN users u ON b.publisher_id = u.id 
                                      WHERE b.author = :author AND b.id != :book_id 
                                      ORDER BY b.created_at DESC 
                                      LIMIT 3");
                $stmt->bindParam(':author', $book['author'], PDO::PARAM_STR);
                $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
                $stmt->execute();
                $authorBooks = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (count($authorBooks) > 0):
                    foreach ($authorBooks as $authorBook):
                ?>
                    <div class="d-flex mb-3">
                        <div class="flex-shrink-0">
                            <img src="<?php echo $authorBook['cover_path'] ? $authorBook['cover_path'] : 'assets/images/default-cover.jpg'; ?>" alt="<?php echo $authorBook['title']; ?>" class="img-thumbnail" style="width: 70px;">
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="mb-0"><a href="index.php?page=book&id=<?php echo $authorBook['id']; ?>"><?php echo $authorBook['title']; ?></a></h6>
                            <small class="text-muted"><?php echo $authorBook['category']; ?></small>
                            <div>
                                <?php
                                $authorBookRating = getAverageRating($authorBook['id']);
                                for ($i = 1; $i <= 5; $i++):
                                    if ($i <= $authorBookRating):
                                ?>
                                    <i class="fas fa-star text-warning small"></i>
                                <?php else: ?>
                                    <i class="far fa-star text-warning small"></i>
                                <?php endif; endfor; ?>
                                <span class="small">(<?php echo getRatingCount($authorBook['id']); ?>)</span>
                            </div>
                        </div>
                    </div>
                <?php
                    endforeach;
                else:
                ?>
                    <p class="text-muted">No other books by this author.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Purchase Modal -->
<div class="modal fade" id="purchaseModal" tabindex="-1" aria-labelledby="purchaseModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="purchaseModalLabel">Purchase Book</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-4">
                    <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" alt="<?php echo $book['title']; ?>" class="img-thumbnail" style="max-height: 200px;">
                    <h5 class="mt-3"><?php echo $book['title']; ?></h5>
                    <p class="text-muted">By <?php echo $book['author']; ?></p>
                    <h4 class="text-primary"><?php echo formatPrice($book['price']); ?></h4>
                </div>
                
                <?php if (!isLoggedIn()): ?>
                    <div class="alert alert-warning">
                        <p>You need to <a href="#" data-bs-toggle="modal" data-bs-target="#authModal" class="auth-trigger">login</a> to purchase this book.</p>
                    </div>
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            // Store book info for redirect after login
                            const authTriggers = document.querySelectorAll('.auth-trigger');
                            authTriggers.forEach(trigger => {
                                trigger.addEventListener('click', function(e) {
                                    // Set session variables via AJAX
                                    fetch('actions/set_auth_redirect.php?book_id=<?php echo $book_id; ?>&action=purchase', {
                                        method: 'GET'
                                    });
                                });
                            });
                        });
                    </script>
                <?php else: ?>
                    <form action="actions/purchase_book.php" method="POST">
                        <input type="hidden" name="book_id" value="<?php echo $book_id; ?>">
                        
                        <div class="mb-3">
                            <label for="payment_method" class="form-label">Payment Method</label>
                            <select class="form-select" id="payment_method" name="payment_method" required>
                                <option value="">Select payment method</option>
                                <option value="credit_card">Credit Card</option>
                                <option value="paypal">PayPal</option>
                                <option value="bank_transfer">Bank Transfer</option>
                            </select>
                        </div>
                        
                        <div id="credit_card_details" style="display: none;">
                            <div class="mb-3">
                                <label for="card_number" class="form-label">Card Number</label>
                                <input type="text" class="form-control" id="card_number" name="card_number" placeholder="1234 5678 9012 3456">
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="expiry_date" class="form-label">Expiry Date</label>
                                    <input type="text" class="form-control" id="expiry_date" name="expiry_date" placeholder="MM/YY">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="cvv" class="form-label">CVV</label>
                                    <input type="text" class="form-control" id="cvv" name="cvv" placeholder="123">
                                </div>
                            </div>
                        </div>
                        
                        <div class="alert alert-info">
                            <p class="mb-0"><strong>Note:</strong> This is a simulated payment system for demonstration purposes. No actual payment will be processed.</p>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Complete Purchase</button>
                        </div>
                    </form>
                    
                    <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        const paymentMethodSelect = document.getElementById('payment_method');
                        const creditCardDetails = document.getElementById('credit_card_details');
                        
                        paymentMethodSelect.addEventListener('change', function() {
                            if (this.value === 'credit_card') {
                                creditCardDetails.style.display = 'block';
                            } else {
                                creditCardDetails.style.display = 'none';
                            }
                        });
                    });
                    </script>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>



<!-- Review Modal -->
<?php if ($hasPurchased): ?>
<div class="modal fade" id="reviewModal" tabindex="-1" aria-labelledby="reviewModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="reviewModalLabel">Write a Review</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="actions/submit_review.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="book_id" value="<?php echo $book_id; ?>">
                    
                    <div class="mb-3">
                        <label for="rating" class="form-label">Rating</label>
                        <div class="rating-stars">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="rating" id="rating1" value="1" required>
                                <label class="form-check-label" for="rating1"><i class="fas fa-star"></i></label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="rating" id="rating2" value="2">
                                <label class="form-check-label" for="rating2"><i class="fas fa-star"></i></label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="rating" id="rating3" value="3">
                                <label class="form-check-label" for="rating3"><i class="fas fa-star"></i></label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="rating" id="rating4" value="4">
                                <label class="form-check-label" for="rating4"><i class="fas fa-star"></i></label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="rating" id="rating5" value="5">
                                <label class="form-check-label" for="rating5"><i class="fas fa-star"></i></label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="comment" class="form-label">Review</label>
                        <textarea class="form-control" id="comment" name="comment" rows="5" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit Review</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
