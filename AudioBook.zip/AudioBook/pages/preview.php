<?php
// Get book ID and preview type from URL
$book_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$type = isset($_GET['type']) ? sanitize($_GET['type']) : '';

// If no book ID provided, redirect to home
if ($book_id <= 0) {
    setMessage('Invalid book ID', 'error');
    header('Location: index.php');
    exit();
}

// Validate preview type
if ($type !== 'pdf' && $type !== 'audio') {
    setMessage('Invalid preview type', 'error');
    header('Location: index.php');
    exit();
}

// Get book details
$book = getBookById($book_id);

// If book not found, redirect to home
if (!$book) {
    setMessage('Book not found', 'error');
    header('Location: index.php');
    exit();
}

// Check if preview is enabled for this book
if (!$book['preview_enabled']) {
    setMessage('Preview is not available for this book', 'error');
    header('Location: index.php?page=book&id=' . $book_id);
    exit();
}

// Check if user has already purchased this book
$hasPurchased = false;
if (isLoggedIn()) {
    $hasPurchased = hasPurchasedBook($_SESSION['user_id'], $book_id);
    
    // If user has already purchased, redirect to the full content
    if ($hasPurchased) {
        if ($type === 'pdf') {
            header('Location: index.php?page=read&id=' . $book_id);
        } else {
            header('Location: index.php?page=listen&id=' . $book_id);
        }
        exit();
    }
}

// Check if requested content exists
if ($type === 'pdf' && empty($book['pdf_path'])) {
    setMessage('This book does not have a PDF version', 'error');
    header('Location: index.php?page=book&id=' . $book_id);
    exit();
} elseif ($type === 'audio' && empty($book['audio_path'])) {
    setMessage('This book does not have an audio version', 'error');
    header('Location: index.php?page=book&id=' . $book_id);
    exit();
}

// Set preview limits
$previewLimit = 5; // First 5 pages for PDF
$audioPreviewLimit = 60; // 60 seconds for audio

// Include header
include_once "includes/header.php";
?>

<div class="container-fluid p-0">
    <div class="row g-0">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center p-3 bg-white border-bottom">
                <div>
                    <h5 class="mb-0">
                        <span class="badge bg-warning me-2">Preview</span>
                        <?php echo $book['title']; ?>
                    </h5>
                    <small class="text-muted">By <?php echo $book['author']; ?></small>
                </div>
                <div>
                    <a href="index.php?page=book&id=<?php echo $book_id; ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-arrow-left me-1"></i> Back to Book
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="alert alert-warning m-0 rounded-0">
        <p class="mb-0">
            <i class="fas fa-info-circle me-1"></i>
            <?php if ($type === 'pdf'): ?>
                This is a preview of the first <?php echo $previewLimit; ?> pages. 
            <?php else: ?>
                This is a preview of the first <?php echo $audioPreviewLimit; ?> seconds.
            <?php endif; ?>
            <a href="index.php?page=book&id=<?php echo $book_id; ?>" class="alert-link">Purchase the book</a> to access the full content.
        </p>
    </div>
    
    <?php if ($type === 'pdf'): ?>
    <!-- PDF Preview -->
    <div class="row g-0">
        <div class="col-12 pdf-container">
            <!-- Device-specific PDF viewers - both using PDF.js for preview limit control -->
            <div id="desktop-viewer" class="d-none d-md-block">
                <!-- Desktop: PDF.js viewer with continuous scrolling -->
                <div id="pdf-viewer-container-desktop" class="pdf-viewer-container">
                    <div id="pdf-viewer-desktop"></div>
                </div>
                
                <!-- Page indicator overlay (non-interactive) -->
                <div class="page-indicator-desktop page-indicator">
                    <span>Page <span id="page-num-desktop">1</span> of <span id="page-count-desktop">1</span></span>
                </div>
            </div>
            
            <div id="mobile-viewer" class="d-block d-md-none">
                <!-- Mobile: PDF.js viewer with continuous scrolling -->
                <div id="pdf-viewer-container" class="pdf-viewer-container">
                    <div id="pdf-viewer"></div>
                </div>
                
                <!-- Page indicator overlay (non-interactive) -->
                <div class="page-indicator">
                    <span>Page <span id="page-num">1</span> of <span id="page-count">1</span></span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Include PDF.js library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js"></script>
    
    <style>
        footer {
            display: none !important;
        }
        
        /* Responsive PDF container */
        .pdf-container {
            position: relative;
            width: 100%;
            height: calc(100vh - 180px);
        }
        
        /* Desktop viewer styles */
        #desktop-viewer {
            width: 100%;
            height: 100%;
            overflow: auto;
        }
        
        /* PDF viewer container - both desktop and mobile */
        .pdf-viewer-container {
            flex-grow: 1;
            overflow: auto !important; /* Force scrolling */
            background-color: #525659;
            padding-bottom: 60px; /* Add padding to prevent content from being hidden behind fixed nav */
            height: 100%;
        }
        
        /* Mobile viewer styles */
        #mobile-viewer {
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        
        #pdf-viewer-container {
            flex-grow: 1;
            overflow: auto !important; /* Force scrolling */
            background-color: #525659;
            padding-bottom: 60px; /* Add padding to prevent content from being hidden behind fixed nav */
        }
        
        /* Make PDF viewer responsive */
        #pdf-viewer, #pdf-viewer-desktop {
            width: 100%;
            height: auto;
            overflow: visible;
        }
        
        #pdf-viewer canvas, #pdf-viewer-desktop canvas {
            max-width: 100%;
            margin: 0 auto 15px auto;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            background-color: white;
        }
        
        /* PDF pages container */
        .pdf-pages-container {
            width: 100%;
            padding: 15px;
            background-color: #525659;
        }
        
        /* PDF page */
        .pdf-page {
            margin-bottom: 15px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
        }
        
        /* Error page */
        .error-page {
            padding: 20px;
            text-align: center;
        }
        
        /* Page indicator overlay */
        .page-indicator {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: rgba(0, 0, 0, 0.6);
            color: white;
            padding: 8px 12px;
            border-radius: 20px;
            font-size: 14px;
            z-index: 100;
            opacity: 0.8;
            transition: opacity 0.3s;
        }
        
        .page-indicator:hover {
            opacity: 1;
        }
        
        /* Mobile adjustments */
        @media (max-width: 768px) {
            #pdf-viewer-container {
                height: calc(100vh - 240px);
            }
            
            /* Ensure buttons are easy to tap on mobile */
            .btn-sm {
                padding: 0.375rem 0.75rem;
                font-size: 0.9rem;
            }
        }
        
        /* Small mobile devices */
        @media (max-width: 576px) {
            #pdf-viewer-container {
                height: calc(100vh - 260px);
            }
        }
        
        /* PDF pages styling */
        .pdf-page {
            margin-bottom: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            background-color: white;
        }
    </style>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get zoom control buttons if they exist
            const zoomIn = document.getElementById('zoom-in');
            const zoomOut = document.getElementById('zoom-out');
            
            // Set up PDF.js
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';
            
            // Elements for mobile
            const pdfViewerContainer = document.getElementById('pdf-viewer-container');
            const pageNumSpan = document.getElementById('page-num');
            const pageCountSpan = document.getElementById('page-count');
            
            // Elements for desktop
            const pdfViewerContainerDesktop = document.getElementById('pdf-viewer-container-desktop');
            const pageNumSpanDesktop = document.getElementById('page-num-desktop');
            const pageCountSpanDesktop = document.getElementById('page-count-desktop');
            
            // Variables
            let pdfDoc = null;
            let scale = 1.0;
            
            // PDF URL
            const pdfUrl = '<?php echo $book['pdf_path']; ?>';
            
            // Preview limit - strictly enforce 5 pages only
            const previewLimit = <?php echo $previewLimit; ?>;
            
            // Load the PDF
            pdfjsLib.getDocument(pdfUrl).promise.then(function(pdf) {
                pdfDoc = pdf;
                
                // Update page counts for both viewers
                if (pageCountSpan) pageCountSpan.textContent = pdf.numPages;
                if (pageCountSpanDesktop) pageCountSpanDesktop.textContent = pdf.numPages;
                
                // Render pages for mobile viewer
                if (pdfViewerContainer) {
                    renderAllPages(pdfViewerContainer, pageNumSpan);
                }
                
                // Render pages for desktop viewer
                if (pdfViewerContainerDesktop) {
                    renderAllPages(pdfViewerContainerDesktop, pageNumSpanDesktop);
                }
            }).catch(function(error) {
                // Show error message if PDF fails to load
                const errorMessage = `
                    <div class="alert alert-danger m-3">
                        <p><i class="fas fa-exclamation-triangle me-2"></i> Failed to load PDF</p>
                        <p class="mb-0">Error: ${error.message}</p>
                    </div>
                `;
                
                if (pdfViewerContainer) pdfViewerContainer.innerHTML = errorMessage;
                if (pdfViewerContainerDesktop) pdfViewerContainerDesktop.innerHTML = errorMessage;
            });
            
            // Render all pages for continuous scrolling
            async function renderAllPages(container, pageNumElement) {
                if (!container) return;
                
                // Clear the container first
                container.innerHTML = '';
                
                // Calculate the container width
                const containerWidth = container.clientWidth - 20; // Subtract padding
                
                // Get total pages and update counter
                const numPages = pdfDoc.numPages;
                
                // Create a container for all pages
                const pagesContainer = document.createElement('div');
                pagesContainer.className = 'pdf-pages-container';
                container.appendChild(pagesContainer);
                
                // Render only the preview limit pages (first 5 pages)
                const pagesToRender = Math.min(numPages, previewLimit);
                console.log(`Rendering ${pagesToRender} pages out of ${numPages} (preview limit: ${previewLimit})`);
                
                // Render each page up to the preview limit
                for (let i = 1; i <= pagesToRender; i++) {
                    try {
                        const page = await pdfDoc.getPage(i);
                        const originalViewport = page.getViewport({ scale: 1.0 });
                        
                        // Calculate scale to fit width
                        const containerScale = containerWidth / originalViewport.width;
                        const viewport = page.getViewport({ scale: scale * containerScale });
                        
                        // Create a container for this page
                        const pageContainer = document.createElement('div');
                        pageContainer.className = 'pdf-page';
                        pageContainer.dataset.pageNumber = i;
                        pagesContainer.appendChild(pageContainer);
                        
                        // Create canvas for this page
                        const canvas = document.createElement('canvas');
                        const ctx = canvas.getContext('2d');
                        canvas.height = viewport.height;
                        canvas.width = viewport.width;
                        pageContainer.appendChild(canvas);
                        
                        // Render the page
                        await page.render({
                            canvasContext: ctx,
                            viewport: viewport
                        }).promise;
                        
                        // No page number element needed
                    } catch (err) {
                        console.error(`Error rendering page ${i}:`, err);
                        // Create an error message for this page
                        const errorPage = document.createElement('div');
                        errorPage.className = 'pdf-page error-page';
                        errorPage.innerHTML = `<div class="alert alert-warning">Error loading page ${i}</div>`;
                        pagesContainer.appendChild(errorPage);
                    }
                }
                
                // Add preview message if there are more pages than the preview limit
                if (previewLimit < numPages) {
                    const previewMessage = document.createElement('div');
                    previewMessage.className = 'alert alert-warning m-3';
                    previewMessage.innerHTML = 'Preview limit reached. <a href="index.php?page=book&id=<?php echo $book_id; ?>" class="alert-link">Purchase the book</a> to continue reading.';
                    pagesContainer.appendChild(previewMessage);
                }
                
                // Add scroll event listener to update page indicator
                container.addEventListener('scroll', function() {
                    updatePageIndicator(container, pageNumElement);
                });
                
                // Initial update of page indicator
                updatePageIndicator(container, pageNumElement);
            }
            
            // Update the page indicator based on scroll position
            function updatePageIndicator(container, pageNumElement) {
                if (!container || !pageNumElement) return;
                
                const pages = container.querySelectorAll('.pdf-page');
                if (!pages.length) return;
                
                // Find the page that is most visible in the viewport
                let mostVisiblePage = 1;
                let maxVisibleArea = 0;
                
                const containerTop = container.scrollTop;
                const containerHeight = container.clientHeight;
                const containerBottom = containerTop + containerHeight;
                
                pages.forEach(page => {
                    const pageTop = page.offsetTop - container.offsetTop;
                    const pageHeight = page.offsetHeight;
                    const pageBottom = pageTop + pageHeight;
                    
                    // Calculate how much of the page is visible
                    const visibleTop = Math.max(containerTop, pageTop);
                    const visibleBottom = Math.min(containerBottom, pageBottom);
                    const visibleHeight = Math.max(0, visibleBottom - visibleTop);
                    
                    if (visibleHeight > maxVisibleArea) {
                        maxVisibleArea = visibleHeight;
                        mostVisiblePage = parseInt(page.dataset.pageNumber);
                    }
                });
                
                // Update page indicator
                pageNumElement.textContent = mostVisiblePage;
            }
            
            // Zoom controls if available
            if (zoomIn) {
                zoomIn.addEventListener('click', function() {
                    scale += 0.25;
                    if (scale > 3) scale = 3; // Max zoom
                    
                    // Re-render all pages with new scale
                    if (pdfViewerContainer) {
                        renderAllPages(pdfViewerContainer, pageNumSpan);
                    }
                    
                    if (pdfViewerContainerDesktop) {
                        renderAllPages(pdfViewerContainerDesktop, pageNumSpanDesktop);
                    }
                });
            }
            
            if (zoomOut) {
                zoomOut.addEventListener('click', function() {
                    scale -= 0.25;
                    if (scale < 0.5) scale = 0.5; // Min zoom
                    
                    // Re-render all pages with new scale
                    if (pdfViewerContainer) {
                        renderAllPages(pdfViewerContainer, pageNumSpan);
                    }
                    
                    if (pdfViewerContainerDesktop) {
                        renderAllPages(pdfViewerContainerDesktop, pageNumSpanDesktop);
                    }
                });
            }
        });
    </script>
    <?php else: ?>
    <!-- Audio Preview -->
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-4 align-items-center">
                            <!-- Book cover on the left -->
                            <div class="col-md-4 text-center">
                                <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" alt="<?php echo $book['title']; ?>" class="img-fluid rounded shadow-sm" style="max-height: 180px;">
                            </div>
                            
                            <!-- Book details on the right -->
                            <div class="col-md-8">
                                <h5 class="mb-2"><?php echo $book['title']; ?></h5>
                                <p class="text-muted mb-1"><strong>Author:</strong> <?php echo $book['author']; ?></p>
                                <p class="text-muted mb-1"><strong>Publisher:</strong> <?php echo $book['publisher_name']; ?></p>
                                <?php if(isset($book['genre']) && !empty($book['genre'])): ?>
                                <p class="text-muted mb-0"><strong>Genre:</strong> <?php echo $book['genre']; ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="audio-player-container">
                            <audio id="audioPlayer" controlsList="nodownload">
                                <source src="<?php echo $book['audio_path']; ?>" type="audio/mpeg">
                                Your browser does not support the audio element.
                            </audio>
                            
                            <div class="custom-audio-player">
                                <div class="player-controls d-flex align-items-center justify-content-between">
                                    <button id="backwardBtn" class="btn btn-light btn-circle" title="Backward 10 seconds">
                                        <i class="fas fa-backward"></i>
                                    </button>
                                    
                                    <button id="playPauseBtn" class="btn btn-primary btn-circle btn-lg">
                                        <i class="fas fa-play"></i>
                                    </button>
                                    
                                    <button id="forwardBtn" class="btn btn-light btn-circle" title="Forward 10 seconds">
                                        <i class="fas fa-forward"></i>
                                    </button>
                                </div>
                                
                                <div class="progress-container mt-3">
                                    <div class="time-display">
                                        <span id="currentTime">0:00</span>
                                    </div>
                                    
                                    <div class="progress">
                                        <div id="progressBar" class="progress-bar" role="progressbar" style="width: 0%"></div>
                                    </div>
                                    
                                    <div class="time-display">
                                        <span id="duration">0:00</span>
                                    </div>
                                </div>
                                
                                <div class="playback-controls mt-3 d-flex align-items-center justify-content-center">
                                    <button id="decreaseSpeed" class="btn btn-sm btn-outline-secondary me-2">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                    
                                    <div id="playbackSpeed" class="playback-speed">1.0x</div>
                                    
                                    <button id="increaseSpeed" class="btn btn-sm btn-outline-secondary ms-2">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="alert alert-warning mt-4">
                            <p class="mb-0">This is a preview of the first <?php echo $audioPreviewLimit; ?> seconds. <a href="index.php?page=book&id=<?php echo $book_id; ?>" class="alert-link">Purchase the book</a> to listen to the full audio.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <style>
        .audio-player-container {
            margin: 20px 0;
        }
        
        .custom-audio-player {
            width: 100%;
        }
        
        .btn-circle {
            border-radius: 50%;
            width: 40px;
            height: 40px;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn-circle.btn-lg {
            width: 60px;
            height: 60px;
        }
        
        .progress-container {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .progress {
            flex-grow: 1;
            height: 8px;
            cursor: pointer;
        }
        
        .time-display {
            font-size: 14px;
            color: #666;
            min-width: 45px;
        }
        
        .playback-speed {
            font-weight: bold;
            padding: 0 10px;
        }
    </style>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const audioPlayer = document.getElementById('audioPlayer');
            const playPauseBtn = document.getElementById('playPauseBtn');
            const backwardBtn = document.getElementById('backwardBtn');
            const forwardBtn = document.getElementById('forwardBtn');
            const progressBar = document.getElementById('progressBar');
            const currentTimeDisplay = document.getElementById('currentTime');
            const durationDisplay = document.getElementById('duration');
            const decreaseSpeedBtn = document.getElementById('decreaseSpeed');
            const increaseSpeedBtn = document.getElementById('increaseSpeed');
            const playbackSpeedDisplay = document.getElementById('playbackSpeed');
            const progressContainer = document.querySelector('.progress');
            
            // Set the preview limit
            const previewLimit = <?php echo $audioPreviewLimit; ?>;
            let previewEnded = false;
            
            // Initialize
            let playbackRate = 1.0;
            
            // Format time in MM:SS format
            function formatTime(seconds) {
                const minutes = Math.floor(seconds / 60);
                seconds = Math.floor(seconds % 60);
                return minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
            }
            
            // Update progress bar and time displays
            function updateProgress() {
                const currentTime = audioPlayer.currentTime;
                const duration = audioPlayer.duration || 0;
                
                // Check if preview limit is reached
                if (currentTime >= previewLimit && !previewEnded) {
                    previewEnded = true;
                    audioPlayer.pause();
                    // Force the current time to stay at the limit
                    audioPlayer.currentTime = previewLimit;
                    playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
                    alert('Preview limit reached. Purchase the book to listen to the full audio.');
                }
                
                // Update progress bar
                const progressPercent = (currentTime / duration) * 100;
                progressBar.style.width = progressPercent + '%';
                
                // Update time displays
                currentTimeDisplay.textContent = formatTime(currentTime);
                durationDisplay.textContent = formatTime(duration);
            }
            
            // Play/Pause toggle
            playPauseBtn.addEventListener('click', function() {
                if (previewEnded) {
                    // If preview has ended, reset to beginning
                    audioPlayer.currentTime = 0;
                    previewEnded = false;
                }
                
                if (audioPlayer.paused) {
                    audioPlayer.play();
                    playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
                } else {
                    audioPlayer.pause();
                    playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
                }
            });
            
            // Backward 10 seconds
            backwardBtn.addEventListener('click', function() {
                audioPlayer.currentTime = Math.max(0, audioPlayer.currentTime - 10);
                
                // If we were in preview ended state, reset it
                if (previewEnded && audioPlayer.currentTime < previewLimit) {
                    previewEnded = false;
                }
            });
            
            // Forward 10 seconds
            forwardBtn.addEventListener('click', function() {
                audioPlayer.currentTime = Math.min(audioPlayer.duration, audioPlayer.currentTime + 10);
                
                // Check if we've exceeded preview limit
                if (audioPlayer.currentTime >= previewLimit && !previewEnded) {
                    previewEnded = true;
                    audioPlayer.pause();
                    playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
                    alert('Preview limit reached. Purchase the book to listen to the full audio.');
                }
            });
            
            // Click on progress bar to seek
            progressContainer.addEventListener('click', function(e) {
                const progressWidth = this.clientWidth;
                const clickX = e.offsetX;
                const duration = audioPlayer.duration;
                
                // Calculate new time
                let newTime = (clickX / progressWidth) * duration;
                
                // Enforce preview limit
                if (newTime > previewLimit) {
                    newTime = previewLimit;
                    previewEnded = true;
                    alert('Preview limit reached. Purchase the book to listen to the full audio.');
                } else {
                    previewEnded = false;
                }
                
                audioPlayer.currentTime = newTime;
            });
            
            // Decrease playback speed
            decreaseSpeedBtn.addEventListener('click', function() {
                if (playbackRate > 0.25) {
                    playbackRate -= 0.25;
                    audioPlayer.playbackRate = playbackRate;
                    playbackSpeedDisplay.textContent = playbackRate.toFixed(1) + 'x';
                }
            });
            
            // Increase playback speed
            increaseSpeedBtn.addEventListener('click', function() {
                if (playbackRate < 2.0) {
                    playbackRate += 0.25;
                    audioPlayer.playbackRate = playbackRate;
                    playbackSpeedDisplay.textContent = playbackRate.toFixed(1) + 'x';
                }
            });
            
            // Event listeners for audio player
            audioPlayer.addEventListener('timeupdate', updateProgress);
            audioPlayer.addEventListener('loadedmetadata', updateProgress);
            
            // Prevent seeking beyond preview limit
            audioPlayer.addEventListener('seeked', function() {
                if (audioPlayer.currentTime > previewLimit) {
                    audioPlayer.currentTime = previewLimit;
                    audioPlayer.pause();
                    playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
                    previewEnded = true;
                    alert('Preview limit reached. Purchase the book to listen to the full audio.');
                }
            });
            
            // Additional safeguard: hard limit on audio duration
            audioPlayer.addEventListener('loadedmetadata', function() {
                // Create a clipping region that only allows playing up to the preview limit
                if (audioPlayer.duration > previewLimit) {
                    // Set a timer to force stop at exactly the preview limit
                    setTimeout(function() {
                        if (audioPlayer.currentTime >= previewLimit) {
                            audioPlayer.pause();
                            audioPlayer.currentTime = previewLimit;
                            playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
                            previewEnded = true;
                        }
                    }, previewLimit * 1000);
                }
            });
            
            // Final safeguard: check every second if we've exceeded the limit
            setInterval(function() {
                if (audioPlayer.currentTime > previewLimit) {
                    audioPlayer.pause();
                    audioPlayer.currentTime = previewLimit;
                    playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
                    previewEnded = true;
                }
            }, 1000);
        });
    </script>
    <?php endif; ?>
</div>
