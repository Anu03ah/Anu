<?php
// Get book ID from URL
$book_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// If no book ID provided, redirect to home
if ($book_id <= 0) {
    setMessage('Invalid book ID', 'error');
    header('Location: index.php');
    exit();
}

// Get book details
$book = getBookById($book_id);

// If book not found, redirect to home
if (!$book) {
    setMessage('Book not found', 'error');
    header('Location: index.php');
    exit();
}

// Check if book has PDF
if (!$book['pdf_path']) {
    setMessage('This book does not have a PDF version', 'error');
    header('Location: index.php?page=book&id=' . $book_id);
    exit();
}

// Check if user has purchased this book or is the publisher of the book
$hasPurchased = false;
$isPublisherOfBook = false;

if (isLoggedIn()) {
    // Check if user has purchased the book
    $hasPurchased = hasPurchasedBook($_SESSION['user_id'], $book_id);
    
    // Check if user is the publisher of this book
    if (isPublisher() && $book['publisher_id'] == $_SESSION['user_id']) {
        $isPublisherOfBook = true;
        // Publishers can read their own books
        $hasPurchased = true;
    }
}

// If not purchased and not preview, redirect to book page
$isPreview = isset($_GET['preview']) && $_GET['preview'] == 'true';
if (!$hasPurchased && !$isPreview) {
    setMessage('You need to purchase this book to read it', 'error');
    header('Location: index.php?page=book&id=' . $book_id);
    exit();
}

// If preview but preview not enabled, redirect to book page
if ($isPreview && !$book['preview_enabled']) {
    setMessage('Preview is not available for this book', 'error');
    header('Location: index.php?page=book&id=' . $book_id);
    exit();
}

// Get user's bookmark if exists
$startPage = 1;
if (isLoggedIn() && $hasPurchased) {
    $bookmark = getBookmark($_SESSION['user_id'], $book_id);
    if ($bookmark && $bookmark['last_read_page']) {
        $startPage = $bookmark['last_read_page'];
    }
}

// For preview, always start at page 1 and limit to first few pages
$previewLimit = 5; // First 5 pages for preview
?>

<?php
include_once "includes/header.php";
?>

<div class="container-fluid p-0">
    <div class="row g-0">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center p-3 bg-white border-bottom">
                <div>
                    <h5 class="mb-0">
                        <?php if ($isPreview): ?>
                            <span class="badge bg-warning me-2">Preview</span>
                        <?php endif; ?>
                        <?php echo $book['title']; ?>
                    </h5>
                    <small class="text-muted">By <?php echo $book['author']; ?></small>
                </div>
                <div>
                    <div class="btn-group me-2" role="group" aria-label="Zoom controls">
                        <button id="zoom-out" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-search-minus"></i>
                        </button>
                        <button id="zoom-in" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-search-plus"></i>
                        </button>
                    </div>
                    <a href="index.php?page=book&id=<?php echo $book_id; ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-arrow-left me-1"></i> Back to Book
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <?php if ($isPreview): ?>
        <div class="alert alert-warning m-0 rounded-0">
            <p class="mb-0">
                <i class="fas fa-info-circle me-1"></i>
                This is a preview of the first <?php echo $previewLimit; ?> pages. 
                <a href="index.php?page=book&id=<?php echo $book_id; ?>" class="alert-link">Purchase the book</a> to read the full content.
            </p>
        </div>
    <?php endif; ?>
    
    <div class="row g-0">
        <div class="col-12 pdf-container">
            <!-- Device-specific PDF viewers - both using PDF.js for consistent experience -->
            <div id="desktop-viewer" class="d-none d-md-block">
                <!-- Desktop: PDF.js viewer with continuous scrolling -->
                <div id="pdf-viewer-container-desktop" class="pdf-viewer-container">
                    <div id="pdf-viewer-desktop"></div>
                </div>
                
                <!-- No page indicator -->
            </div>
            
            <div id="mobile-viewer" class="d-block d-md-none">
                <!-- Mobile: PDF.js viewer with continuous scrolling -->
                <div id="pdf-viewer-container">
                    <div id="pdf-viewer"></div>
                </div>
                
                <!-- No page indicator -->
            </div>
        </div>
    </div>
</div>

<!-- Include PDF.js library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js"></script>

<style>
    footer {
        display: none !important;
    }
    
    /* Responsive PDF container */
    .pdf-container {
        position: relative;
        width: 100%;
        height: calc(100vh - 180px);
    }
    
    /* Desktop viewer styles */
    #desktop-viewer {
        width: 100%;
        height: 100%;
        overflow: auto;
    }
    
    /* PDF viewer container - both desktop and mobile */
    .pdf-viewer-container {
        flex-grow: 1;
        overflow: auto !important; /* Force scrolling */
        background-color: #525659;
        padding-bottom: 60px; /* Add padding to prevent content from being hidden behind fixed nav */
        height: 100%;
    }
    
    /* Mobile viewer styles */
    #mobile-viewer {
        display: flex;
        flex-direction: column;
        height: 100%;
    }
    
    #pdf-viewer-container {
        flex-grow: 1;
        overflow: auto !important; /* Force scrolling */
        background-color: #525659;
        padding-bottom: 60px; /* Add padding to prevent content from being hidden behind fixed nav */
    }
    
    /* Make PDF viewer responsive */
    #pdf-viewer, #pdf-viewer-desktop {
        width: 100%;
        height: auto;
        overflow: visible;
    }
    
    #pdf-viewer canvas, #pdf-viewer-desktop canvas {
        max-width: 100%;
        margin: 0 auto 15px auto;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        background-color: white;
    }
    
    /* PDF pages container */
    .pdf-pages-container {
        width: 100%;
        padding: 15px;
        background-color: #525659;
    }
    
    /* PDF page */
    .pdf-page {
        margin-bottom: 15px;
        background-color: white;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
    }
    
    /* Error page */
    .error-page {
        padding: 20px;
        text-align: center;
    }
    
    /* No page indicator styles needed */
    
    /* Mobile adjustments */
    @media (max-width: 768px) {
        #pdf-viewer-container {
            height: calc(100vh - 240px);
        }
        
        /* Ensure buttons are easy to tap on mobile */
        .btn-sm {
            padding: 0.375rem 0.75rem;
            font-size: 0.9rem;
        }
    }
    
    /* Small mobile devices */
    @media (max-width: 576px) {
        #pdf-viewer-container {
            height: calc(100vh - 260px);
        }
        
        .pdf-controls span {
            font-size: 0.9rem;
        }
    }
    
    /* Button active state for better touch feedback */
    .btn.active {
        background-color: #6c5ce7;
        color: white;
        transform: scale(0.95);
        transition: all 0.1s ease;
    }
    
    /* Larger touch targets for mobile */
    @media (max-width: 768px) {
        .btn-group .btn {
            padding: 0.5rem 0.75rem;
            min-width: 44px;
            min-height: 44px;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // PDF.js setup
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';
        
        // Variables
        let scale = 1.0;
        const pdfUrl = '<?php echo $book['pdf_path']; ?>';
        const startPage = <?php echo $startPage; ?>;
        const pageLimit = <?php echo $isPreview ? $previewLimit : '1000'; ?>;
        const hasPurchased = <?php echo $hasPurchased ? 'true' : 'false'; ?>;
        const bookId = <?php echo $book_id; ?>;
        
        console.log('PDF URL:', pdfUrl); // Debug log
        
        // Get elements
        const mobileViewer = document.getElementById('pdf-viewer');
        const desktopViewer = document.getElementById('pdf-viewer-desktop');
        const mobileContainer = document.getElementById('pdf-viewer-container');
        const desktopContainer = document.getElementById('pdf-viewer-container-desktop');
        const zoomIn = document.getElementById('zoom-in');
        const zoomOut = document.getElementById('zoom-out');
        
        console.log('Elements found:', {
            mobileViewer: !!mobileViewer,
            desktopViewer: !!desktopViewer,
            mobileContainer: !!mobileContainer,
            desktopContainer: !!desktopContainer
        });
        
        // Load and render PDF
        console.log('Loading PDF from:', pdfUrl);
        pdfjsLib.getDocument(pdfUrl).promise.then(function(pdf) {
            console.log('PDF loaded successfully with ' + pdf.numPages + ' pages');
            
            // Render for mobile
            if (mobileViewer && mobileContainer) {
                console.log('Rendering for mobile');
                renderPDF(pdf, mobileViewer, mobileContainer);
            }
            
            // Render for desktop
            if (desktopViewer && desktopContainer) {
                console.log('Rendering for desktop');
                renderPDF(pdf, desktopViewer, desktopContainer);
            }
            
            // Set up zoom controls with improved mobile support
            function setupZoomButton(button, isZoomIn) {
                if (!button) return;
                
                // Function to handle zoom action
                const performZoom = function(e) {
                    // Prevent default behavior and stop propagation
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Adjust scale based on zoom direction
                    if (isZoomIn) {
                        scale += 0.25;
                        if (scale > 3) scale = 3;
                        console.log('Zooming in, scale:', scale);
                    } else {
                        scale -= 0.25;
                        if (scale < 0.5) scale = 0.5;
                        console.log('Zooming out, scale:', scale);
                    }
                    
                    // Re-render PDF with new scale
                    if (mobileViewer && mobileContainer) renderPDF(pdf, mobileViewer, mobileContainer);
                    if (desktopViewer && desktopContainer) renderPDF(pdf, desktopViewer, desktopContainer);
                    
                    // Add visual feedback
                    button.classList.add('active');
                    setTimeout(() => button.classList.remove('active'), 200);
                };
                
                // Add both click and touchend events for better mobile support
                button.addEventListener('click', performZoom);
                button.addEventListener('touchend', performZoom);
            }
            
            // Set up zoom in and zoom out buttons
            setupZoomButton(zoomIn, true);
            setupZoomButton(zoomOut, false);
        }).catch(function(error) {
            const errorMsg = `<div class="alert alert-danger m-3"><p><i class="fas fa-exclamation-triangle me-2"></i>Failed to load PDF</p><p class="mb-0">Error: ${error.message}</p></div>`;
            if (mobileViewer) mobileViewer.innerHTML = errorMsg;
            if (desktopViewer) desktopViewer.innerHTML = errorMsg;
            console.error('Error loading PDF:', error);
        });
        
        // Render PDF function - simple and reliable
        async function renderPDF(pdfDoc, viewerElement, containerElement) {
            if (!viewerElement || !containerElement || !pdfDoc) {
                console.error('Missing required elements for rendering PDF');
                return;
            }
            
            console.log('Rendering PDF with scale:', scale);
            
            // Clear the viewer
            viewerElement.innerHTML = '';
            
            // Calculate the container width
            const containerWidth = containerElement.clientWidth - 20; // Subtract padding
            console.log('Container width:', containerWidth);
            
            // Create a container for all pages
            const pagesContainer = document.createElement('div');
            pagesContainer.className = 'pdf-pages-container';
            viewerElement.appendChild(pagesContainer);
            
            // Get total pages
            const numPages = pdfDoc.numPages;
            const pagesToRender = Math.min(numPages, pageLimit);
            console.log(`Rendering ${pagesToRender} pages out of ${numPages}`);
            
            // Render each page up to the limit
            for (let i = 1; i <= pagesToRender; i++) {
                try {
                    console.log(`Rendering page ${i}`);
                    const page = await pdfDoc.getPage(i);
                    const originalViewport = page.getViewport({ scale: 1.0 });
                    
                    // Calculate scale to fit width
                    const containerScale = containerWidth / originalViewport.width;
                    const viewport = page.getViewport({ scale: scale * containerScale });
                    
                    // Create a container for this page
                    const pageContainer = document.createElement('div');
                    pageContainer.className = 'pdf-page';
                    pageContainer.dataset.pageNumber = i;
                    pagesContainer.appendChild(pageContainer);
                    
                    // Create canvas for this page
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;
                    pageContainer.appendChild(canvas);
                    
                    // Render the page
                    await page.render({
                        canvasContext: ctx,
                        viewport: viewport
                    }).promise;
                    
                    console.log(`Page ${i} rendered successfully`);
                } catch (err) {
                    console.error(`Error rendering page ${i}:`, err);
                    // Create an error message for this page
                    const errorPage = document.createElement('div');
                    errorPage.className = 'pdf-page error-page';
                    errorPage.innerHTML = `<div class="alert alert-warning">Error loading page ${i}</div>`;
                    pagesContainer.appendChild(errorPage);
                }
            }
            
            // Add preview message if needed
            <?php if ($isPreview): ?>
            if (pageLimit < numPages) {
                const previewMessage = document.createElement('div');
                previewMessage.className = 'alert alert-warning m-3';
                previewMessage.innerHTML = 'Preview limit reached. <a href="index.php?page=book&id=<?php echo $book_id; ?>" class="alert-link">Purchase the book</a> to continue reading.';
                pagesContainer.appendChild(previewMessage);
            }
            <?php endif; ?>
            
            // If bookmark exists, scroll to that page
            if (startPage > 0 && startPage <= numPages) {
                // Delay slightly to ensure pages are rendered
                setTimeout(() => {
                    const pageToScrollTo = pagesContainer.querySelector(`.pdf-page[data-page-number="${startPage}"]`);
                    if (pageToScrollTo) {
                        pageToScrollTo.scrollIntoView({ behavior: 'smooth' });
                    }
                }, 500);
            }
            
            // Set up scroll event to save bookmark
            if (hasPurchased) {
                containerElement.addEventListener('scroll', function() {
                    clearTimeout(window.scrollTimer);
                    window.scrollTimer = setTimeout(() => {
                        saveBookmark(findVisiblePage(containerElement));
                    }, 5000);
                }, { passive: true });
            }
        }
        
        // Find the most visible page in the viewport
        function findVisiblePage(containerElement) {
            const pages = containerElement.querySelectorAll('.pdf-page');
            if (!pages.length) return 1;
            
            let mostVisiblePage = 1;
            let maxVisibleArea = 0;
            
            const containerTop = containerElement.scrollTop;
            const containerHeight = containerElement.clientHeight;
            const containerBottom = containerTop + containerHeight;
            
            pages.forEach(page => {
                const pageTop = page.offsetTop - containerElement.offsetTop;
                const pageHeight = page.offsetHeight;
                const pageBottom = pageTop + pageHeight;
                
                // Calculate how much of the page is visible
                const visibleTop = Math.max(containerTop, pageTop);
                const visibleBottom = Math.min(containerBottom, pageBottom);
                const visibleHeight = Math.max(0, visibleBottom - visibleTop);
                
                if (visibleHeight > maxVisibleArea) {
                    maxVisibleArea = visibleHeight;
                    mostVisiblePage = parseInt(page.dataset.pageNumber);
                }
            });
            
            return mostVisiblePage;
        }
        
        // Save bookmark function
        function saveBookmark(page) {
            if (!hasPurchased) return;
            
            // Create form data
            const formData = new FormData();
            formData.append('action', 'save');
            formData.append('book_id', bookId);
            formData.append('page', page);
            
            // Send to server
            fetch('actions/bookmark_action.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                console.log('Bookmark saved:', data);
            })
            .catch(error => {
                console.error('Error saving bookmark:', error);
            });
        }
    }); // End of DOMContentLoaded event listener
</script>

<?php
include_once "includes/footer.php";
?>


