<?php
// Get book ID from URL
$book_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// If no book ID provided, redirect to home
if ($book_id <= 0) {
    setMessage('Invalid book ID', 'error');
    header('Location: index.php');
    exit();
}

// Get book details
$book = getBookById($book_id);

// If book not found, redirect to home
if (!$book) {
    setMessage('Book not found', 'error');
    header('Location: index.php');
    exit();
}

// Check if book has audio
if (!$book['audio_path']) {
    setMessage('This book does not have an audio version', 'error');
    header('Location: index.php?page=book&id=' . $book_id);
    exit();
}

// Check if user has purchased this book or is the publisher of the book
$hasPurchased = false;
$isPublisherOfBook = false;

if (isLoggedIn()) {
    // Check if user has purchased the book
    $hasPurchased = hasPurchasedBook($_SESSION['user_id'], $book_id);
    
    // Check if user is the publisher of this book
    if (isPublisher() && $book['publisher_id'] == $_SESSION['user_id']) {
        $isPublisherOfBook = true;
        // Publishers can listen to their own books
        $hasPurchased = true;
    }
}

// If not purchased and not preview, redirect to book page
$isPreview = isset($_GET['preview']) && $_GET['preview'] == 'true';
if (!$hasPurchased && !$isPreview) {
    setMessage('You need to purchase this book to listen to it', 'error');
    header('Location: index.php?page=book&id=' . $book_id);
    exit();
}

// If preview but preview not enabled, redirect to book page
if ($isPreview && !$book['preview_enabled']) {
    setMessage('Preview is not available for this book', 'error');
    header('Location: index.php?page=book&id=' . $book_id);
    exit();
}

// Get user's bookmark if exists
$startPosition = 0;
if (isLoggedIn() && $hasPurchased) {
    $bookmark = getBookmark($_SESSION['user_id'], $book_id);
    if ($bookmark && $bookmark['last_listen_position']) {
        $startPosition = $bookmark['last_listen_position'];
    }
}

// For preview, always start at beginning and limit to first minute
$previewLimit = 60; // 60 seconds for preview
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mb-4">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <?php if ($isPreview): ?>
                        <span class="badge bg-warning me-2">Preview</span>
                    <?php endif; ?>
                    <?php echo $book['title']; ?> - Audio Player
                </h5>
                <a href="index.php?page=book&id=<?php echo $book_id; ?>" class="btn btn-outline-primary btn-sm">
                    <i class="fas fa-arrow-left me-1"></i> Back to Book
                </a>
            </div>
            <div class="card-body">
                <?php if ($isPreview): ?>
                    <div class="alert alert-warning">
                        <p class="mb-0">
                            <i class="fas fa-info-circle me-1"></i>
                            This is a preview of the first minute. 
                            <a href="index.php?page=book&id=<?php echo $book_id; ?>" class="alert-link">Purchase the book</a> to listen to the full content.
                        </p>
                    </div>
                <?php endif; ?>
                

                
                <!-- Modern Audio Player -->
                <div class="audio-player mt-3" id="audio-player" data-book-id="<?php echo $book_id; ?>">
                    <div class="card shadow-sm border-0 rounded-lg">
                        <div class="card-body p-4">
                            <div class="row mb-4 align-items-center">
                                <!-- Book cover on the left -->
                                <div class="col-md-4 text-center">
                                    <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" alt="<?php echo $book['title']; ?>" class="img-fluid rounded shadow-sm" style="max-height: 180px;">
                                </div>
                                
                                <!-- Book details on the right -->
                                <div class="col-md-8">
                                    <h5 class="mb-2"><?php echo $book['title']; ?></h5>
                                    <p class="text-muted mb-1"><strong>Author:</strong> <?php echo $book['author']; ?></p>
                                    <p class="text-muted mb-1"><strong>Publisher:</strong> <?php echo $book['publisher_name']; ?></p>
                                    <?php if(isset($book['genre']) && !empty($book['genre'])): ?>
                                    <p class="text-muted mb-0"><strong>Genre:</strong> <?php echo $book['genre']; ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="audio-player-container">
                                <audio id="audioPlayer" controlsList="nodownload" preload="auto">
                                    <source src="<?php echo $book['audio_path']; ?>" type="audio/mpeg">
                                    Your browser does not support the audio element.
                                </audio>
                                
                                <div class="custom-audio-player">
                                    <div class="player-controls d-flex align-items-center justify-content-between">
                                        <button id="backwardBtn" class="btn btn-light btn-circle" title="Backward 10 seconds">
                                            <i class="fas fa-backward"></i>
                                        </button>
                                        
                                        <button id="playPauseBtn" class="btn btn-primary btn-circle btn-lg">
                                            <i class="fas fa-play"></i>
                                        </button>
                                        
                                        <button id="forwardBtn" class="btn btn-light btn-circle" title="Forward 10 seconds">
                                            <i class="fas fa-forward"></i>
                                        </button>
                                    </div>
                                    
                                    <div class="progress-container mt-3">
                                        <div class="time-display">
                                            <span id="currentTime">0:00</span>
                                        </div>
                                        
                                        <div class="progress">
                                            <div id="progressBar" class="progress-bar" role="progressbar" style="width: 0%"></div>
                                        </div>
                                        
                                        <div class="time-display">
                                            <span id="duration">0:00</span>
                                        </div>
                                    </div>
                                    
                                    <div class="playback-controls mt-3 d-flex align-items-center justify-content-center">
                                        <button id="decreaseSpeed" class="btn btn-sm btn-outline-secondary me-2">
                                            <i class="fas fa-minus"></i>
                                        </button>
                                        
                                        <div id="playbackSpeed" class="playback-speed">1.0x</div>
                                        
                                        <button id="increaseSpeed" class="btn btn-sm btn-outline-secondary ms-2">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            
                            <?php if ($isPreview): ?>
                            <div class="alert alert-warning mt-4">
                                <p class="mb-0">This is a preview of the first <?php echo $previewLimit; ?> seconds. <a href="index.php?page=book&id=<?php echo $book_id; ?>" class="alert-link">Purchase the book</a> to listen to the full audio.</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Modern Audio Player Styles -->
                    <style>
                        .audio-player-container {
                            margin: 20px 0;
                        }
                        
                        .custom-audio-player {
                            width: 100%;
                        }
                        
                        .btn-circle {
                            border-radius: 50%;
                            width: 40px;
                            height: 40px;
                            padding: 0;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                        }
                        
                        .btn-circle.btn-lg {
                            width: 60px;
                            height: 60px;
                        }
                        
                        .progress-container {
                            display: flex;
                            align-items: center;
                            gap: 10px;
                        }
                        
                        .progress {
                            flex-grow: 1;
                            height: 8px;
                            cursor: pointer;
                        }
                        
                        .time-display {
                            font-size: 14px;
                            color: #666;
                            min-width: 45px;
                        }
                        
                        .playback-speed {
                            font-weight: bold;
                            padding: 0 10px;
                        }
                    </style>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const audioPlayer = document.getElementById('audioPlayer');
    const playPauseBtn = document.getElementById('playPauseBtn');
    const backwardBtn = document.getElementById('backwardBtn');
    const forwardBtn = document.getElementById('forwardBtn');
    const progressBar = document.getElementById('progressBar');
    const currentTimeDisplay = document.getElementById('currentTime');
    const durationDisplay = document.getElementById('duration');
    const decreaseSpeedBtn = document.getElementById('decreaseSpeed');
    const increaseSpeedBtn = document.getElementById('increaseSpeed');
    const playbackSpeedDisplay = document.getElementById('playbackSpeed');
    const progressContainer = document.querySelector('.progress');
    const bookId = document.getElementById('audio-player').getAttribute('data-book-id');
    
    // Check if audio element exists
    if (!audioPlayer) {
        console.error('Audio player element not found');
        return;
    }
    
    // Set initial position if bookmark exists
    const startPosition = <?php echo $startPosition; ?>;
    if (startPosition > 0) {
        audioPlayer.currentTime = startPosition;
    }
    
    // For preview mode
    <?php if ($isPreview): ?>
    const previewLimit = <?php echo $previewLimit; ?>;
    let previewEnded = false;
    <?php endif; ?>
    
    // Initialize
    let playbackRate = 1.0;
    
    // Format time in MM:SS format
    function formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        seconds = Math.floor(seconds % 60);
        return minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
    }
    
    // Update progress bar and time displays
    function updateProgress() {
        const currentTime = audioPlayer.currentTime;
        const duration = audioPlayer.duration || 0;
        
        <?php if ($isPreview): ?>
        // Check if preview limit is reached
        if (currentTime >= previewLimit && !previewEnded) {
            previewEnded = true;
            audioPlayer.pause();
            // Force the current time to stay at the limit
            audioPlayer.currentTime = previewLimit;
            playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
            alert('Preview limit reached. Purchase the book to listen to the full audio.');
        }
        <?php endif; ?>
        
        // Update progress bar
        const progressPercent = (currentTime / duration) * 100;
        progressBar.style.width = progressPercent + '%';
        
        // Update time displays
        currentTimeDisplay.textContent = formatTime(currentTime);
        durationDisplay.textContent = formatTime(duration);
        
        // Save bookmark every 5 seconds while playing (for purchased books)
        <?php if ($hasPurchased): ?>
        if (Math.floor(currentTime) % 5 === 0 && Math.floor(currentTime) > 0 && !audioPlayer.paused) {
            saveBookmark(Math.floor(currentTime));
        }
        <?php endif; ?>
    }
    
    // Play/Pause toggle
    playPauseBtn.addEventListener('click', function() {
        <?php if ($isPreview): ?>
        if (previewEnded) {
            // If preview has ended, reset to beginning
            audioPlayer.currentTime = 0;
            previewEnded = false;
        }
        <?php endif; ?>
        
        if (audioPlayer.paused) {
            audioPlayer.play();
            playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
        } else {
            audioPlayer.pause();
            playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
        }
    });
    
    // Backward 10 seconds
    backwardBtn.addEventListener('click', function() {
        audioPlayer.currentTime = Math.max(0, audioPlayer.currentTime - 10);
        
        <?php if ($isPreview): ?>
        // If we were in preview ended state, reset it
        if (previewEnded && audioPlayer.currentTime < previewLimit) {
            previewEnded = false;
        }
        <?php endif; ?>
    });
    
    // Forward 10 seconds
    forwardBtn.addEventListener('click', function() {
        audioPlayer.currentTime = Math.min(audioPlayer.duration, audioPlayer.currentTime + 10);
        
        <?php if ($isPreview): ?>
        // Check if we've exceeded preview limit
        if (audioPlayer.currentTime >= previewLimit && !previewEnded) {
            previewEnded = true;
            audioPlayer.pause();
            playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
            alert('Preview limit reached. Purchase the book to listen to the full audio.');
        }
        <?php endif; ?>
    });
    
    // Click on progress bar to seek
    progressContainer.addEventListener('click', function(e) {
        const progressWidth = this.clientWidth;
        const clickX = e.offsetX;
        const duration = audioPlayer.duration;
        
        // Calculate new time
        let newTime = (clickX / progressWidth) * duration;
        
        <?php if ($isPreview): ?>
        // Enforce preview limit
        if (newTime > previewLimit) {
            newTime = previewLimit;
            previewEnded = true;
            alert('Preview limit reached. Purchase the book to listen to the full audio.');
        } else {
            previewEnded = false;
        }
        <?php endif; ?>
        
        audioPlayer.currentTime = newTime;
    });
    
    // Decrease playback speed
    decreaseSpeedBtn.addEventListener('click', function() {
        if (playbackRate > 0.25) {
            playbackRate -= 0.25;
            audioPlayer.playbackRate = playbackRate;
            playbackSpeedDisplay.textContent = playbackRate.toFixed(1) + 'x';
        }
    });
    
    // Increase playback speed
    increaseSpeedBtn.addEventListener('click', function() {
        if (playbackRate < 2.0) {
            playbackRate += 0.25;
            audioPlayer.playbackRate = playbackRate;
            playbackSpeedDisplay.textContent = playbackRate.toFixed(1) + 'x';
        }
    });
    
    // Event listeners for audio player
    audioPlayer.addEventListener('timeupdate', updateProgress);
    audioPlayer.addEventListener('loadedmetadata', updateProgress);
    
    <?php if ($isPreview): ?>
    // Prevent seeking beyond preview limit
    audioPlayer.addEventListener('seeked', function() {
        if (audioPlayer.currentTime > previewLimit) {
            audioPlayer.currentTime = previewLimit;
            audioPlayer.pause();
            playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
            previewEnded = true;
            alert('Preview limit reached. Purchase the book to listen to the full audio.');
        }
    });
    
    // Additional safeguard: hard limit on audio duration
    audioPlayer.addEventListener('loadedmetadata', function() {
        // Create a clipping region that only allows playing up to the preview limit
        if (audioPlayer.duration > previewLimit) {
            // Set a timer to force stop at exactly the preview limit
            setTimeout(function() {
                if (audioPlayer.currentTime >= previewLimit) {
                    audioPlayer.pause();
                    audioPlayer.currentTime = previewLimit;
                    playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
                    previewEnded = true;
                }
            }, previewLimit * 1000);
        }
    });
    
    // Final safeguard: check every second if we've exceeded the limit
    setInterval(function() {
        if (audioPlayer.currentTime > previewLimit) {
            audioPlayer.pause();
            audioPlayer.currentTime = previewLimit;
            playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
            previewEnded = true;
        }
    }, 1000);
    <?php endif; ?>
    
    // Handle audio errors
    audioPlayer.addEventListener('error', function(e) {
        alert('There was an error loading the audio file. Please try again later.');
        console.error('Audio error:', e);
    });
    
    // Save bookmark function
    function saveBookmark(position) {
        // Create form data
        const formData = new FormData();
        formData.append('action', 'save');
        formData.append('book_id', bookId);
        formData.append('position', position);
        
        // Send to server
        fetch('actions/bookmark_action.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok: ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            // Bookmark saved successfully
        })
        .catch(error => {
            // Don't show alerts for bookmark errors to avoid disrupting the user experience
        });
    }
});
</script>
