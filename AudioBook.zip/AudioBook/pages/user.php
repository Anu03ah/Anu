<?php
/**
 * Public user profile page
 * Allows viewing other users' profiles and reporting them if necessary
 */

// Get user ID from URL
$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// If no user ID provided, redirect to home
if ($user_id <= 0) {
    setMessage('Invalid user ID', 'error');
    header('Location: index.php');
    exit();
}

// Get user details
$stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
$stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// If user not found, redirect to home
if (!$user) {
    setMessage('User not found', 'error');
    header('Location: index.php');
    exit();
}

// Check if viewing own profile
$isOwnProfile = isLoggedIn() && $_SESSION['user_id'] == $user_id;

// If viewing own profile, redirect to profile page
if ($isOwnProfile) {
    header('Location: index.php?page=profile');
    exit();
}

// Get user's published books (if publisher)
$publishedBooks = [];
if ($user['role'] === 'publisher') {
    $stmt = $conn->prepare("SELECT * FROM books WHERE publisher_id = :publisher_id ORDER BY created_at DESC LIMIT 6");
    $stmt->bindParam(':publisher_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $publishedBooks = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get user's reviews
$stmt = $conn->prepare("SELECT f.*, b.title as book_title, b.id as book_id 
                       FROM feedback f 
                       JOIN books b ON f.book_id = b.id 
                       WHERE f.user_id = :user_id 
                       ORDER BY f.created_at DESC LIMIT 5");
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">User Profile</h5>
                    <?php if (isLoggedIn()): ?>
                    <button class="btn btn-sm btn-outline-danger" 
                            data-bs-toggle="report-modal" 
                            data-report-type="user" 
                            data-target-id="<?php echo $user_id; ?>" 
                            data-target-name="<?php echo htmlspecialchars($user['name']); ?>">
                        <i class="fas fa-flag"></i> Report User
                    </button>
                    <?php endif; ?>
                </div>
                <div class="card-body text-center">
                    <div class="mb-3">
                        <div class="profile-avatar">
                            <?php if ($user['role'] === 'publisher'): ?>
                                <i class="fas fa-user-tie fa-5x text-primary"></i>
                            <?php else: ?>
                                <i class="fas fa-user-circle fa-5x text-primary"></i>
                            <?php endif; ?>
                        </div>
                    </div>
                    <h5><?php echo htmlspecialchars($user['name']); ?></h5>
                    <p class="text-muted">
                        <?php if ($user['role'] === 'publisher'): ?>
                            <span class="badge bg-primary">Publisher</span>
                        <?php elseif ($user['role'] === 'admin'): ?>
                            <span class="badge bg-danger">Admin</span>
                        <?php elseif ($user['role'] === 'moderator'): ?>
                            <span class="badge bg-success">Moderator</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">User</span>
                        <?php endif; ?>
                    </p>
                    <p><i class="fas fa-calendar me-2"></i>Joined: <?php echo date('M d, Y', strtotime($user['created_at'])); ?></p>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <?php if ($user['role'] === 'publisher' && count($publishedBooks) > 0): ?>
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Published Books</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php foreach ($publishedBooks as $book): ?>
                        <div class="col-md-4 mb-3">
                            <div class="card h-100 book-card">
                                <a href="index.php?page=book&id=<?php echo $book['id']; ?>" class="text-decoration-none">
                                    <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" class="card-img-top" alt="<?php echo $book['title']; ?>">
                                    <div class="card-body">
                                        <h6 class="card-title text-truncate"><?php echo $book['title']; ?></h6>
                                        <p class="card-text text-muted small"><?php echo $book['author']; ?></p>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if (count($reviews) > 0): ?>
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Recent Reviews</h5>
                </div>
                <div class="card-body">
                    <?php foreach ($reviews as $review): ?>
                    <div class="border-bottom pb-3 mb-3">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div>
                                <a href="index.php?page=book&id=<?php echo $review['book_id']; ?>" class="fw-bold text-decoration-none">
                                    <?php echo htmlspecialchars($review['book_title']); ?>
                                </a>
                                <div class="text-warning">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <?php if ($i <= $review['rating']): ?>
                                            <i class="fas fa-star"></i>
                                        <?php else: ?>
                                            <i class="far fa-star"></i>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <div class="d-flex align-items-center">
                                <small class="text-muted me-2"><?php echo date('M d, Y', strtotime($review['created_at'])); ?></small>
                                <?php if (isLoggedIn()): ?>
                                <button class="btn btn-sm btn-link text-danger p-0" 
                                        data-bs-toggle="report-modal" 
                                        data-report-type="review" 
                                        data-target-id="<?php echo $review['id']; ?>" 
                                        data-target-name="Review by <?php echo htmlspecialchars($user['name']); ?>">
                                    <i class="fas fa-flag"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <p class="mb-0"><?php echo nl2br(htmlspecialchars($review['comment'])); ?></p>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if (count($reviews) === 0 && count($publishedBooks) === 0): ?>
            <div class="card">
                <div class="card-body">
                    <div class="alert alert-info mb-0">
                        <p class="mb-0">This user hasn't published any books or written any reviews yet.</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
