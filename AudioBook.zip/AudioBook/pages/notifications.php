<?php
// Check if user is logged in is handled in index.php

// Get all notifications for the user

// Get all notifications for the user
global $conn;
$stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = :user_id ORDER BY created_at DESC");
$stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
$stmt->execute();
$all_notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get unread notifications count
$unread_count = 0;
foreach ($all_notifications as $notification) {
    if (!$notification['is_read']) {
        $unread_count++;
    }
}
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Your Notifications</h5>
                    <?php if ($unread_count > 0): ?>
                    <a href="actions/notification_actions.php?action=mark_all_read&redirect=notifications" class="btn btn-sm btn-outline-primary mark-all-read" data-toast-message="All notifications marked as read" data-toast-type="success">
                        <i class="fas fa-check-double"></i> Mark All as Read
                    </a>
                    <?php endif; ?>
                </div>
                <div class="card-body p-0">
                    <?php if (count($all_notifications) > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($all_notifications as $notification): ?>
                                <div class="list-group-item notification-item <?php echo $notification['is_read'] ? '' : 'bg-light'; ?>">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h6 class="mb-0">
                                            <?php 
                                            // Display icon based on notification type
                                            $icon = 'info-circle';
                                            switch ($notification['type']) {
                                                case 'purchase':
                                                    $icon = 'shopping-cart';
                                                    break;
                                                case 'review':
                                                    $icon = 'star';
                                                    break;
                                                case 'license_application':
                                                case 'license_approved':
                                                case 'license_rejected':
                                                    $icon = 'id-card';
                                                    break;
                                                case 'book_uploaded':
                                                case 'sale':
                                                    $icon = 'book';
                                                    break;
                                                case 'complaint_resolved':
                                                    $icon = 'check-circle';
                                                    break;
                                                case 'account_blocked':
                                                    $icon = 'ban';
                                                    break;
                                            }
                                            ?>
                                            <i class="fas fa-<?php echo $icon; ?> me-2"></i>
                                            <?php echo ucfirst($notification['type']); ?>
                                        </h6>
                                        <small class="text-muted"><?php echo date('M d, Y H:i', strtotime($notification['created_at'])); ?></small>
                                    </div>
                                    <p class="mb-2"><?php echo $notification['message']; ?></p>
                                    <div class="d-flex justify-content-end gap-2">
                                        <?php if (!$notification['is_read']): ?>
                                        <a href="actions/notification_actions.php?id=<?php echo $notification['id']; ?>&action=mark_read&redirect=notifications" class="btn btn-sm btn-outline-secondary mark-notification-read" data-notification-id="<?php echo $notification['id']; ?>" data-toast-message="Notification marked as read" data-toast-type="success">
                                            <i class="fas fa-check"></i> Mark as Read
                                        </a>
                                        <?php endif; ?>
                                        <a href="#" class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#notification-detail-<?php echo $notification['id']; ?>" aria-expanded="false">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <a href="actions/notification_actions.php?id=<?php echo $notification['id']; ?>&action=delete&redirect=notifications" class="btn btn-sm btn-outline-danger" data-toast-message="Notification deleted" data-toast-type="success" onclick="return confirm('Are you sure you want to delete this notification?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </a>
                                    </div>
                                    <div class="collapse mt-3" id="notification-detail-<?php echo $notification['id']; ?>">
                                        <div class="card card-body bg-light">
                                            <h6 class="card-subtitle mb-2 text-muted">Full Details</h6>
                                            <p><?php echo $notification['message']; ?></p>
                                            <div class="d-flex justify-content-between">
                                                <small>Type: <?php echo ucfirst($notification['type']); ?></small>
                                                <small>Created: <?php echo date('F d, Y H:i:s', strtotime($notification['created_at'])); ?></small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info m-3">
                            <i class="fas fa-info-circle me-2"></i> You have no notifications
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
