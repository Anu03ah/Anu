<div class="container mt-5">
    <div class="row">
        <div class="col-md-8 mx-auto text-center">
            <div class="error-template">
                <h1>Oops!</h1>
                <h2>404 Not Found</h2>
                <div class="error-details mb-4">
                    Sorry, the page you requested could not be found.
                </div>
                <div class="error-actions">
                    <a href="index.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-home"></i> Take Me Home
                    </a>
                    <a href="index.php?page=dashboard" class="btn btn-outline-secondary btn-lg ml-2">
                        <i class="fas fa-user"></i> Go to Dashboard
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .error-template {
        padding: 40px 15px;
    }
    .error-actions {
        margin-top: 15px;
        margin-bottom: 15px;
    }
    .error-actions .btn {
        margin-right: 10px;
    }
</style>
