<?php
// Get search parameters
$query = isset($_GET['query']) ? sanitize($_GET['query']) : '';
$category = isset($_GET['category']) ? sanitize($_GET['category']) : '';
$sort = isset($_GET['sort']) ? sanitize($_GET['sort']) : 'newest';
$free = isset($_GET['free']) ? (int)$_GET['free'] : 0;
$trending = isset($_GET['trending']) ? (int)$_GET['trending'] : 0;
$new_release = isset($_GET['new_release']) ? (int)$_GET['new_release'] : 0;

// Get all categories for filter
$categories = getCategories();

// Handle different filter scenarios
if ($free == 1) {
    // Get free books
    $books = getFreeBooks(0); // 0 means no limit
} elseif ($trending == 1) {
    // Get trending books - only books with at least one purchase
    $stmt = $conn->prepare("SELECT b.*, COUNT(p.id) as purchase_count, u.name as publisher_name 
                           FROM books b 
                           JOIN purchases p ON b.id = p.book_id 
                           JOIN users u ON b.publisher_id = u.id 
                           GROUP BY b.id 
                           HAVING purchase_count > 0 
                           ORDER BY purchase_count DESC, b.created_at DESC");
    $stmt->execute();
    $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // If no books found, show a message indicating no trending books
    if (empty($books)) {
        $books = [];
    }
} elseif ($new_release == 1) {
    // Get new releases
    $books = getNewReleases(0); // 0 means no limit
} elseif (!empty($query) || !empty($category)) {
    // Search books by query or category
    $books = searchBooks($query, $category);
} else {
    // Get all books if no search parameters
    $stmt = $conn->prepare("SELECT b.*, u.name as publisher_name FROM books b JOIN users u ON b.publisher_id = u.id ORDER BY b.created_at DESC");
    $stmt->execute();
    $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Sort books based on sort parameter
if ($sort === 'title_asc') {
    usort($books, function($a, $b) {
        return strcmp($a['title'], $b['title']);
    });
} elseif ($sort === 'title_desc') {
    usort($books, function($a, $b) {
        return strcmp($b['title'], $a['title']);
    });
} elseif ($sort === 'price_asc') {
    usort($books, function($a, $b) {
        return $a['price'] - $b['price'];
    });
} elseif ($sort === 'price_desc') {
    usort($books, function($a, $b) {
        return $b['price'] - $a['price'];
    });
} elseif ($sort === 'rating') {
    usort($books, function($a, $b) {
        $ratingA = getAverageRating($a['id']);
        $ratingB = getAverageRating($b['id']);
        return $ratingB - $ratingA;
    });
} else { // newest (default)
    usort($books, function($a, $b) {
        return strtotime($b['created_at']) - strtotime($a['created_at']);
    });
}
?>

<div class="row">
    <!-- Sidebar Filters -->
    <div class="col-md-3">
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">Search & Filter</h5>
            </div>
            <div class="card-body">
                <form action="index.php" method="GET">
                    <input type="hidden" name="page" value="search">
                    
                    <div class="mb-3">
                        <label for="query" class="form-label">Search</label>
                        <input type="text" class="form-control" id="query" name="query" value="<?php echo $query; ?>" placeholder="Book title, author...">
                    </div>
                    
                    <div class="mb-3">
                        <label for="category" class="form-label">Category</label>
                        <select class="form-select" id="category" name="category">
                            <option value="">All Categories</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat; ?>" <?php if ($category === $cat) echo 'selected'; ?>>
                                    <?php echo $cat; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="sort" class="form-label">Sort By</label>
                        <select class="form-select" id="sort" name="sort">
                            <option value="newest" <?php if ($sort === 'newest') echo 'selected'; ?>>Newest First</option>
                            <option value="title_asc" <?php if ($sort === 'title_asc') echo 'selected'; ?>>Title (A-Z)</option>
                            <option value="title_desc" <?php if ($sort === 'title_desc') echo 'selected'; ?>>Title (Z-A)</option>
                            <option value="price_asc" <?php if ($sort === 'price_asc') echo 'selected'; ?>>Price (Low to High)</option>
                            <option value="price_desc" <?php if ($sort === 'price_desc') echo 'selected'; ?>>Price (High to Low)</option>
                            <option value="rating" <?php if ($sort === 'rating') echo 'selected'; ?>>Highest Rated</option>
                        </select>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Apply Filters</button>
                    </div>
                </form>
                
                <?php if (!empty($query) || !empty($category) || $sort !== 'newest'): ?>
                    <div class="d-grid mt-2">
                        <a href="index.php?page=search" class="btn btn-outline-secondary">Clear Filters</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">Format</h5>
            </div>
            <div class="card-body">
                <div class="form-check">
                    <input class="form-check-input format-filter" type="checkbox" value="pdf" id="pdfFilter" checked>
                    <label class="form-check-label" for="pdfFilter">
                        <i class="fas fa-file-pdf text-info me-1"></i> PDF
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input format-filter" type="checkbox" value="audio" id="audioFilter" checked>
                    <label class="form-check-label" for="audioFilter">
                        <i class="fas fa-headphones text-warning me-1"></i> Audio
                    </label>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Book Results -->
    <div class="col-md-9">
        <div class="card mb-4">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <?php if ($free == 1): ?>
                        Free Books
                    <?php elseif ($trending == 1): ?>
                        Trending Books
                    <?php elseif ($new_release == 1): ?>
                        New Releases
                    <?php elseif (!empty($query) || !empty($category)): ?>
                        Search Results
                        <?php if (!empty($query)): ?>
                            for "<?php echo $query; ?>"
                        <?php endif; ?>
                        <?php if (!empty($category)): ?>
                            in <?php echo $category; ?>
                        <?php endif; ?>
                    <?php else: ?>
                        Browse Books
                    <?php endif; ?>
                </h5>
                <span><?php echo count($books); ?> books found</span>
            </div>
            <div class="card-body">
                <?php if (count($books) > 0): ?>
                    <div class="book-grid">
                        <?php foreach ($books as $book): ?>
                            <div class="book-item" 
                                 data-pdf="<?php echo !empty($book['pdf_path']) ? 'true' : 'false'; ?>" 
                                 data-audio="<?php echo !empty($book['audio_path']) ? 'true' : 'false'; ?>">
                                <div class="modern-book-card">
                                    <div class="card-img-container">
                                        <img src="<?php echo $book['cover_path'] ? $book['cover_path'] : 'assets/images/default-cover.jpg'; ?>" class="card-img-top" alt="<?php echo $book['title']; ?>">
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo $book['title']; ?></h5>
                                        <p class="card-author"><?php echo $book['author']; ?></p>
                                        
                                        <div class="book-format-badges">
                                            <?php if ($book['pdf_path']): ?>
                                                <span class="book-format-badge bg-info"><i class="fas fa-file-pdf"></i> PDF</span>
                                            <?php endif; ?>
                                            
                                            <?php if ($book['audio_path']): ?>
                                                <span class="book-format-badge bg-warning"><i class="fas fa-headphones"></i> Audio</span>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="book-meta">
                                            <div class="book-rating">
                                                <?php
                                                $rating = getAverageRating($book['id']);
                                                for ($i = 1; $i <= 5; $i++) {
                                                    if ($i <= $rating) {
                                                        echo '<i class="fas fa-star"></i>';
                                                    } elseif ($i - 0.5 <= $rating) {
                                                        echo '<i class="fas fa-star-half-alt"></i>';
                                                    } else {
                                                        echo '<i class="far fa-star"></i>';
                                                    }
                                                }
                                                ?>
                                                <span>(<?php echo getRatingCount($book['id']); ?>)</span>
                                            </div>
                                            <?php if ($book['price'] > 0): ?>
                                                <span class="book-price"><?php echo formatPrice($book['price']); ?></span>
                                            <?php else: ?>
                                                <span class="book-free">Free</span>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="book-actions">
                                            <a href="index.php?page=book&id=<?php echo $book['id']; ?>" class="btn btn-primary btn-action">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">
                        <p>No books found matching your search criteria.</p>
                        <a href="index.php?page=search" class="btn btn-primary mt-2">Clear Search</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Format filter functionality
    const pdfFilter = document.getElementById('pdfFilter');
    const audioFilter = document.getElementById('audioFilter');
    const bookItems = document.querySelectorAll('.book-item');
    
    function applyFilters() {
        const showPdf = pdfFilter.checked;
        const showAudio = audioFilter.checked;
        
        bookItems.forEach(item => {
            const hasPdf = item.getAttribute('data-pdf') === 'true';
            const hasAudio = item.getAttribute('data-audio') === 'true';
            
            // Show item if it matches any of the checked formats
            if ((showPdf && hasPdf) || (showAudio && hasAudio)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    }
    
    pdfFilter.addEventListener('change', applyFilters);
    audioFilter.addEventListener('change', applyFilters);
    
    // Apply filters on page load
    applyFilters();
});
</script>
