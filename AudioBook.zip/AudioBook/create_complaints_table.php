<?php
// Include database configuration
require_once 'config/config.php';

try {
    // Create complaints table
    $sql = "CREATE TABLE IF NOT EXISTS complaints (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        message TEXT NOT NULL,
        status ENUM('pending', 'in_progress', 'resolved') DEFAULT 'pending',
        resolved_by INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL
    )";
    
    $conn->exec($sql);
    echo "Complaints table created successfully!";
    
    // Insert some sample complaints for testing
    $sql = "INSERT INTO complaints (user_id, message) VALUES 
            (1, 'I cannot access my purchased books'),
            (1, 'The audio player is not working properly'),
            (1, 'I need help with downloading my books')";
    
    $conn->exec($sql);
    echo "<br>Sample complaints added successfully!";
    
    echo "<br><br><a href='index.php?page=dashboard'>Return to Dashboard</a>";
    
} catch(PDOException $e) {
    echo "Error creating complaints table: " . $e->getMessage();
}
?>
