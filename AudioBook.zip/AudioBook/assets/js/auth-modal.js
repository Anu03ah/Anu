/**
 * Auth Modal Handling
 * Keeps the modal open for blocked users and only closes it on successful login
 */
document.addEventListener('DOMContentLoaded', function() {
    // Get the auth modal element
    const authModal = document.getElementById('authModal');
    
    // Check if the modal should be kept open
    if (authModal && authModal.getAttribute('data-keep-open') === 'true') {
        // Show the modal
        const modal = new bootstrap.Modal(authModal);
        modal.show();
        
        // Remove the keep-open attribute after showing
        authModal.removeAttribute('data-keep-open');
    }
    
    // Intercept form submissions in the modal
    const loginForm = document.querySelector('#login-tab-pane form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            // Don't prevent default - let the form submit normally
            // The backend will handle redirecting back with the appropriate session variables
            // if the login fails or the user is blocked
        });
    }
});
