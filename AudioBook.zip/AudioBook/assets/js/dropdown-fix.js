/**
 * Dropdown fix for reviewer details and other dropdowns
 * Ensures all dropdowns have proper scrolling behavior
 */
document.addEventListener('DOMContentLoaded', function() {
    // Apply max height and scrolling to all dropdown menus
    const fixDropdowns = function() {
        // Target all dropdown menus
        const dropdowns = document.querySelectorAll('.dropdown-menu');
        
        dropdowns.forEach(function(dropdown) {
            // Set max height and enable scrolling
            dropdown.style.maxHeight = '250px';
            dropdown.style.overflowY = 'auto';
            
            // Ensure proper z-index
            dropdown.style.zIndex = '1050';
            
            // Ensure proper positioning
            if (dropdown.closest('.dropdown')) {
                dropdown.closest('.dropdown').style.position = 'relative';
            }
        });
    };
    
    // Run initially
    fixDropdowns();
    
    // Also run when dropdowns are shown
    document.addEventListener('shown.bs.dropdown', fixDropdowns);
    
    // Fix specifically for reviewer dropdowns which might be dynamically added
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes && mutation.addedNodes.length > 0) {
                for (let i = 0; i < mutation.addedNodes.length; i++) {
                    const node = mutation.addedNodes[i];
                    if (node.nodeType === 1 && node.classList && node.classList.contains('dropdown-menu')) {
                        // Set max height and enable scrolling
                        node.style.maxHeight = '250px';
                        node.style.overflowY = 'auto';
                        node.style.zIndex = '1050';
                    }
                }
            }
        });
    });
    
    // Start observing the document body for changes
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
});
