/**
 * Fix for modal blinking issue when closing
 */
document.addEventListener('DOMContentLoaded', function() {
    // Store references to Bootstrap modals
    const bsModalInstances = {};
    
    // Function to ensure modal backdrop is removed
    function ensureBackdropRemoved() {
        // Remove any lingering backdrops
        const backdrops = document.querySelectorAll('.modal-backdrop');
        backdrops.forEach(backdrop => {
            backdrop.remove();
        });
        
        // Also ensure body classes are cleaned up
        document.body.classList.remove('modal-open');
        document.body.style.overflow = '';
        document.body.style.paddingRight = '';
    }
    
    // Fix for modal blinking issue
    const modals = document.querySelectorAll('.modal');
    
    // Add event listeners to all modals
    modals.forEach(modal => {
        // When modal is shown
        modal.addEventListener('show.bs.modal', function() {
            // Add a class to body to prevent card hover effects
            document.body.classList.add('modal-showing');
            // Prevent table row hover effects when modal is open
            document.querySelectorAll('.table-hover tr').forEach(row => {
                row.classList.add('no-hover');
            });
        });
        
        // When modal is hidden
        modal.addEventListener('hidden.bs.modal', function() {
            // Remove the class after a small delay to prevent blinking
            setTimeout(() => {
                document.body.classList.remove('modal-showing');
                // Restore table row hover effects
                document.querySelectorAll('.table-hover tr').forEach(row => {
                    row.classList.remove('no-hover');
                });
                
                // Ensure backdrop is removed
                ensureBackdropRemoved();
            }, 300);
        });
        
        // Store the Bootstrap modal instance for later use
        bsModalInstances[modal.id] = new bootstrap.Modal(modal);
    });
    
    // Handle the close button in modals
    const closeButtons = document.querySelectorAll('.modal .btn-close, .modal .btn-secondary');
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Find the parent modal
            const modal = this.closest('.modal');
            if (modal && bsModalInstances[modal.id]) {
                // Hide using Bootstrap API
                bsModalInstances[modal.id].hide();
                
                // Ensure backdrop is removed
                setTimeout(ensureBackdropRemoved, 350);
            }
        });
    });
    
    // Special handling for block/unblock buttons in user management
    const actionButtons = document.querySelectorAll('.btn-danger[data-bs-toggle="modal"], .btn-success[data-bs-toggle="modal"]');
    actionButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Prevent the event from affecting parent elements
            e.stopPropagation();
            e.preventDefault();
            
            // Get the target modal
            const modalId = this.getAttribute('data-bs-target').substring(1); // Remove the # prefix
            
            // Show the modal using our stored instance
            if (bsModalInstances[modalId]) {
                bsModalInstances[modalId].show();
            }
        });
    });
    
    // Fix for modals within scrollable containers
    const modalButtons = document.querySelectorAll('[data-bs-toggle="modal"]');
    modalButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Prevent the event from affecting parent elements
            e.stopPropagation();
        });
    });
    
    // We don't need special handling for nested modals since we're using data-bs-dismiss
    // This matches the admin dashboard implementation which is working correctly
    
    // Add a global handler to ensure backdrop is removed when Escape key is pressed
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            setTimeout(ensureBackdropRemoved, 350);
        }
    });
});
