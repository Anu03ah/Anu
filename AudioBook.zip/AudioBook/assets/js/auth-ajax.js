/**
 * AJAX Authentication for Login and Register forms
 * Handles form submissions without page redirects
 */
document.addEventListener('DOMContentLoaded', function() {
    // Get the login and register forms
    const loginForm = document.querySelector('#login-tab-pane form');
    const registerForm = document.querySelector('#register-tab-pane form');
    
    // Error message container for login form
    const createErrorContainer = function(targetForm) {
        // Check if error container already exists
        let errorContainer = targetForm.querySelector('.auth-error-container');
        if (!errorContainer) {
            errorContainer = document.createElement('div');
            errorContainer.className = 'auth-error-container alert alert-danger mt-3 d-none';
            errorContainer.innerHTML = '<i class="fas fa-exclamation-circle me-2"></i> <span class="error-message"></span>';
            targetForm.prepend(errorContainer);
        }
        return errorContainer;
    };
    
    // Create error containers
    const loginErrorContainer = createErrorContainer(loginForm);
    const registerErrorContainer = createErrorContainer(registerForm);
    
    // Handle login form submission
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Hide any existing error messages
            loginErrorContainer.classList.add('d-none');
            
            // Get form data
            const formData = new FormData(loginForm);
            
            // Add X-Requested-With header to identify as AJAX request
            const headers = new Headers();
            headers.append('X-Requested-With', 'XMLHttpRequest');
            
            // Send AJAX request
            fetch('actions/login_action.php', {
                method: 'POST',
                body: formData,
                headers: headers
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    // Successful login - always redirect to homepage
                    if (data.redirect) {
                        // Use the server-provided redirect URL (which should be absolute)
                        window.location.href = data.redirect;
                    } else {
                        // Fallback to the AudioBook homepage if no redirect is provided
                        const baseUrl = window.location.origin + '/AudioBook/';
                        window.location.href = baseUrl + 'index.php';
                    }
                } else {
                    // Show error message
                    loginErrorContainer.querySelector('.error-message').textContent = data.message || 'Invalid email or password';
                    loginErrorContainer.classList.remove('d-none');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                loginErrorContainer.querySelector('.error-message').textContent = 'Invalid email or password';
                loginErrorContainer.classList.remove('d-none');
            });
        });
    }
    
    // Handle register form submission
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Hide any existing error messages
            registerErrorContainer.classList.add('d-none');
            
            // Get form data
            const formData = new FormData(registerForm);
            
            // Add X-Requested-With header to identify as AJAX request
            const headers = new Headers();
            headers.append('X-Requested-With', 'XMLHttpRequest');
            
            // Send AJAX request
            fetch('actions/register_action.php', {
                method: 'POST',
                body: formData,
                headers: headers
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    // Successful registration - redirect or reload page
                    if (data.redirect) {
                        window.location.href = data.redirect;
                    } else {
                        window.location.reload();
                    }
                } else {
                    // Show error message
                    registerErrorContainer.querySelector('.error-message').textContent = data.message || 'Registration failed. Please try again.';
                    registerErrorContainer.classList.remove('d-none');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                registerErrorContainer.querySelector('.error-message').textContent = 'Please check your information and try again.';
                registerErrorContainer.classList.remove('d-none');
            });
        });
    }
});
