/**
 * In-place action forms for report modals in the moderator dashboard
 * This script handles showing and hiding action forms within the main report modal
 */
document.addEventListener('DOMContentLoaded', function() {
    // Handle action buttons
    const actionButtons = document.querySelectorAll('.action-btn');
    
    actionButtons.forEach(button => {
        button.addEventListener('click', function() {
            const reportId = this.getAttribute('data-report-id');
            const action = this.getAttribute('data-action');
            const formsContainer = document.getElementById('actionForms' + reportId);
            
            if (!formsContainer) return;
            
            // Hide all forms first
            const allForms = formsContainer.querySelectorAll('.action-form');
            allForms.forEach(form => form.style.display = 'none');
            
            // Show the appropriate form based on the action
            let formToShow;
            
            switch(action) {
                case 'in-progress':
                    formToShow = document.getElementById('inProgressForm' + reportId);
                    break;
                case 'resolve':
                    formToShow = document.getElementById('resolveForm' + reportId);
                    break;
                case 'dismiss':
                    formToShow = document.getElementById('dismissForm' + reportId);
                    break;
                case 'remove-book':
                    formToShow = document.getElementById('removeBookForm' + reportId);
                    break;
                case 'block-user':
                    formToShow = document.getElementById('blockUserForm' + reportId);
                    break;
                case 'remove-review':
                    formToShow = document.getElementById('removeReviewForm' + reportId);
                    break;
            }
            
            if (formToShow) {
                formToShow.style.display = 'block';
                
                // Scroll to the form
                formToShow.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        });
    });
    
    // Handle cancel buttons
    const cancelButtons = document.querySelectorAll('.cancel-action');
    
    cancelButtons.forEach(button => {
        button.addEventListener('click', function() {
            const reportId = this.getAttribute('data-report-id');
            const formsContainer = document.getElementById('actionForms' + reportId);
            
            if (!formsContainer) return;
            
            // Hide all forms
            const allForms = formsContainer.querySelectorAll('.action-form');
            allForms.forEach(form => form.style.display = 'none');
        });
    });
    
    // Handle form submissions - no confirmation checkboxes needed
    const actionForms = document.querySelectorAll('.action-form form');
    
    actionForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            // All forms are valid by default - just submit
            return true;
        });
    });
    
    // Auto-check confirmation boxes when "I understand" text is clicked
    const confirmationLabels = document.querySelectorAll('.confirmation-label');
    
    confirmationLabels.forEach(label => {
        label.addEventListener('click', function() {
            const checkboxId = this.getAttribute('for');
            const checkbox = document.getElementById(checkboxId);
            
            if (checkbox) {
                checkbox.checked = !checkbox.checked;
            }
        });
    });
    
    // Add some basic styling for the action forms
    const style = document.createElement('style');
    style.textContent = `
        .action-forms-container {
            transition: all 0.3s ease;
        }
        .action-form {
            transition: all 0.3s ease;
        }
        .confirmation-label {
            cursor: pointer;
        }
    `;
    document.head.appendChild(style);
});
