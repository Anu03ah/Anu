/**
 * Script to block all notification toasts
 */
document.addEventListener('DOMContentLoaded', function() {
    // Function to remove all toast notifications
    function removeAllToasts() {
        // Remove any toast containers
        const toastContainers = document.querySelectorAll('.toast-container');
        toastContainers.forEach(container => {
            container.innerHTML = '';
        });
        
        // Remove any alert messages related to notifications
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            if (alert.textContent.includes('Notification')) {
                alert.remove();
            }
        });
    }
    
    // Run immediately
    removeAllToasts();
    
    // Also run after a short delay to catch any dynamically added toasts
    setTimeout(removeAllToasts, 100);
    setTimeout(removeAllToasts, 500);
    setTimeout(removeAllToasts, 1000);
    
    // Create a mutation observer to watch for new toasts
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes.length) {
                removeAllToasts();
            }
        });
    });
    
    // Start observing the document body for changes
    observer.observe(document.body, { 
        childList: true,
        subtree: true
    });
});
