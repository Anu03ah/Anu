/**
 * Search Button Hover Effects
 */
document.addEventListener('DOMContentLoaded', function() {
    const searchButton = document.querySelector('.search-button');
    
    if (searchButton) {
        // Add hover effect
        searchButton.addEventListener('mouseenter', function() {
            this.style.backgroundColor = 'rgba(255, 255, 255, 0.4)';
            this.style.transform = 'translateY(-2px)';
            this.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.15)';
        });
        
        // Remove hover effect
        searchButton.addEventListener('mouseleave', function() {
            this.style.backgroundColor = 'rgba(255, 255, 255, 0.2)';
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.1)';
        });
        
        // Add active effect
        searchButton.addEventListener('mousedown', function() {
            this.style.transform = 'scale(0.92)';
            this.style.boxShadow = '0 1px 3px rgba(0, 0, 0, 0.2)';
            this.style.backgroundColor = 'rgba(255, 255, 255, 0.5)';
        });
        
        // Remove active effect
        searchButton.addEventListener('mouseup', function() {
            this.style.transform = 'translateY(-2px)';
            this.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.15)';
            this.style.backgroundColor = 'rgba(255, 255, 255, 0.4)';
        });
        
        // Handle case when mouse leaves during active state
        searchButton.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.1)';
            this.style.backgroundColor = 'rgba(255, 255, 255, 0.2)';
        });
    }
});
