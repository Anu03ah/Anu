/**
 * Inline Sliding Search Bar functionality
 */
document.addEventListener('DOMContentLoaded', function() {
    const searchToggle = document.querySelector('.search-toggle');
    const searchFormContainer = document.querySelector('.inline-search-form');
    const searchInput = document.querySelector('.search-input');
    
    // Toggle search form when search icon is clicked
    if (searchToggle) {
        searchToggle.addEventListener('click', function(e) {
            e.preventDefault();
            searchFormContainer.classList.toggle('active');
            
            // Focus the search input after a short delay to allow the animation to complete
            if (searchFormContainer.classList.contains('active')) {
                setTimeout(() => {
                    searchInput.focus();
                }, 300);
            }
        });
    }
    
    // Close button removed as search icon now toggles the search
    
    // Close search form when clicking outside
    document.addEventListener('click', function(e) {
        if (!searchFormContainer.contains(e.target) && 
            !searchToggle.contains(e.target) && 
            searchFormContainer.classList.contains('active')) {
            searchFormContainer.classList.remove('active');
        }
    });
    
    // Close search form when ESC key is pressed
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && searchFormContainer.classList.contains('active')) {
            searchFormContainer.classList.remove('active');
        }
    });
});
