/**
 * Make book cards clickable
 * This script makes the entire book card clickable and removes the View buttons
 * Carefully targets only book cards in the main content sections
 */
document.addEventListener('DOMContentLoaded', function() {
    // Define the CSS for clickable cards once
    const style = document.createElement('style');
    style.textContent = `
        .book-grid .modern-book-card .card-link,
        .free-books-section .modern-book-card .card-link,
        .trending-books-section .modern-book-card .card-link,
        section .book-item .modern-book-card .card-link {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 10;
            text-indent: -9999px;
            overflow: hidden;
        }
        
        .book-grid .modern-book-card:hover,
        .free-books-section .modern-book-card:hover,
        .trending-books-section .modern-book-card:hover,
        section .book-item .modern-book-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.12);
        }
        
        .book-grid .modern-book-card,
        .free-books-section .modern-book-card,
        .trending-books-section .modern-book-card,
        section .book-item .modern-book-card {
            cursor: pointer;
            position: relative;
        }
    `;
    document.head.appendChild(style);
    
    // Function to process a book card
    function processBookCard(card) {
        // Only process cards that have a View button and don't already have a card-link
        const viewButton = card.querySelector('.book-actions a');
        const existingCardLink = card.querySelector('.card-link');
        
        if (viewButton && !existingCardLink) {
            // Get the link URL
            const bookUrl = viewButton.getAttribute('href');
            
            // Create a new invisible link that covers the entire card
            const cardLink = document.createElement('a');
            cardLink.setAttribute('href', bookUrl);
            cardLink.setAttribute('class', 'card-link');
            cardLink.setAttribute('aria-label', 'View book details');
            
            // Add the link to the card
            card.appendChild(cardLink);
            
            // Hide the View button container
            const actionsContainer = card.querySelector('.book-actions');
            if (actionsContainer) {
                actionsContainer.style.display = 'none';
            }
        }
    }
    
    // Process all book cards in the main content area only
    // Use very specific selectors to avoid affecting the header
    const mainContent = document.querySelector('main') || document.querySelector('body > .container') || document.body;
    
    // Target book cards only in specific sections
    const bookGrids = mainContent.querySelectorAll('.book-grid');
    bookGrids.forEach(grid => {
        const cards = grid.querySelectorAll('.modern-book-card');
        cards.forEach(processBookCard);
    });
    
    // Target book cards in book sections
    const bookSections = mainContent.querySelectorAll('section');
    bookSections.forEach(section => {
        // Skip the header/hero section
        if (section.classList.contains('hero') || section.classList.contains('navbar')) {
            return;
        }
        
        const cards = section.querySelectorAll('.modern-book-card');
        cards.forEach(processBookCard);
    });
});
