/**
 * AudioBook - Main JavaScript File
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // PDF Viewer Initialization
    initPdfViewer();
    
    // Audio Player Controls
    initAudioPlayer();
    
    // Bookmark Functionality
    initBookmarkSystem();
    
    // Form Validations
    initFormValidations();
    
    // Notification System
    initNotifications();
});

/**
 * Initialize PDF Viewer if it exists on the page
 */
function initPdfViewer() {
    const pdfViewer = document.getElementById('pdf-viewer');
    if (!pdfViewer) return;
    
    const pdfUrl = pdfViewer.getAttribute('data-pdf-url');
    const pageNum = parseInt(pdfViewer.getAttribute('data-page') || '1');
    const bookId = pdfViewer.getAttribute('data-book-id');
    
    // Initialize PDF.js
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';
    
    let pdfDoc = null;
    let scale = 1.0; // Default scale
    let canvasContainer = document.getElementById('pdf-canvas-container');
    let currentVisiblePage = 1;
    let totalPagesCount = 0;
    
    // Handle modal events for PDF viewer
    const pdfModal = document.getElementById('pdfReaderModal');
    if (pdfModal) {
        pdfModal.addEventListener('shown.bs.modal', function() {
            // Re-initialize PDF viewer when modal is shown
            if (pdfDoc === null) {
                loadPdf();
            }
        });
    }
    
    /**
     * Render all pages in continuous scroll mode
     */
    function renderAllPages() {
        if (!pdfDoc || !canvasContainer) return;
        
        // Clear the container
        canvasContainer.innerHTML = '';
        
        // Hide loading indicator
        const loadingIndicator = document.getElementById('pdf-loading');
        if (loadingIndicator) {
            loadingIndicator.style.display = 'none';
        }
        
        // Update total pages count
        totalPagesCount = pdfDoc.numPages;
        
        // Render each page sequentially
        for (let i = 1; i <= pdfDoc.numPages; i++) {
            renderSinglePage(i);
        }
        
        // Set up scroll event to save bookmark
        setupScrollTracking();
    }
    
    /**
     * Render a single page and add it to the container
     * @param {number} num Page number
     */
    function renderSinglePage(num) {
        pdfDoc.getPage(num).then(page => {
            const viewport = page.getViewport({scale: scale});
            
            // Create page container
            const pageContainer = document.createElement('div');
            pageContainer.className = 'pdf-page';
            pageContainer.setAttribute('data-page-number', num);
            pageContainer.style.width = `${viewport.width}px`;
            pageContainer.style.margin = '0 auto 20px auto';
            
            // Create canvas for this page
            const canvas = document.createElement('canvas');
            canvas.className = 'pdf-page-canvas';
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            
            // Add page number indicator
            const pageNumberIndicator = document.createElement('div');
            pageNumberIndicator.className = 'pdf-page-number';
            pageNumberIndicator.textContent = `Page ${num} of ${pdfDoc.numPages}`;
            
            pageContainer.appendChild(canvas);
            pageContainer.appendChild(pageNumberIndicator);
            canvasContainer.appendChild(pageContainer);
            
            // Render the page content
            const ctx = canvas.getContext('2d');
            const renderContext = {
                canvasContext: ctx,
                viewport: viewport
            };
            
            page.render(renderContext);
        }).catch(error => {
            console.error(`Error rendering page ${num}:`, error);
        });
    }
    
    /**
     * Set up scroll tracking to save bookmarks
     */
    function setupScrollTracking() {
        const pdfContainer = document.querySelector('.pdf-container');
        if (!pdfContainer) return;
        
        pdfContainer.addEventListener('scroll', function() {
            // Find which page is most visible
            const pageElements = document.querySelectorAll('.pdf-page');
            let maxVisiblePage = 1;
            let maxVisibleArea = 0;
            
            pageElements.forEach(pageEl => {
                const rect = pageEl.getBoundingClientRect();
                const containerRect = pdfContainer.getBoundingClientRect();
                
                // Calculate how much of the page is visible
                const visibleTop = Math.max(rect.top, containerRect.top);
                const visibleBottom = Math.min(rect.bottom, containerRect.bottom);
                const visibleHeight = Math.max(0, visibleBottom - visibleTop);
                const visibleArea = visibleHeight * rect.width;
                
                if (visibleArea > maxVisibleArea) {
                    maxVisibleArea = visibleArea;
                    maxVisiblePage = parseInt(pageEl.getAttribute('data-page-number'));
                }
            });
            
            if (maxVisiblePage !== currentVisiblePage) {
                currentVisiblePage = maxVisiblePage;
                
                // Save bookmark for current visible page
                saveBookmark(bookId, currentVisiblePage, null);
            }
        });
    }
    }
    
    /**
     * If another page rendering in progress, waits until the rendering is
     * finished. Otherwise, executes rendering immediately.
     */
    function queueRenderPage(num) {
        if (pageRendering) {
            pageNumPending = num;
        } else {
            renderPage(num);
        }
    }
    
    /**
     * Displays previous page.
     */
    function onPrevPage() {
        if (pdfDoc === null || pageNum <= 1) {
            return;
        }
        pageNum--;
        queueRenderPage(pageNum);
    }
    
    /**
     * Displays next page.
     */
    function onNextPage() {
        if (pdfDoc === null || pageNum >= pdfDoc.numPages) {
            return;
        }
        pageNum++;
        queueRenderPage(pageNum);
    }
    
    /**
     * Scroll to a specific page
     * @param {number} pageNum Page number to scroll to
     */
    function scrollToPage(pageNum) {
        const pageElement = document.querySelector(`.pdf-page[data-page-number="${pageNum}"]`);
        if (pageElement) {
            pageElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    
    // Load PDF function
    function loadPdf() {
        // Load the PDF
        pdfjsLib.getDocument(pdfUrl).promise.then(function(pdfDoc_) {
            pdfDoc = pdfDoc_;
            console.log('PDF loaded successfully with', pdfDoc.numPages, 'pages');
            
            // Calculate appropriate scale for the container
            const pdfContainer = document.querySelector('.pdf-container');
            if (pdfContainer) {
                const containerWidth = pdfContainer.clientWidth - 40; // 20px padding on each side
                
                // Get first page to calculate scale
                pdfDoc.getPage(1).then(page => {
                    const viewport = page.getViewport({scale: 1});
                    scale = containerWidth / viewport.width;
                    
                    // Render all pages
                    renderAllPages();
                });
            } else {
                renderAllPages();
            }
            
        }).catch(function(error) {
            console.error('Error loading PDF:', error);
            if (canvasContainer) {
                canvasContainer.innerHTML = `
                    <div class="alert alert-danger m-3">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Error loading PDF. Please try again later.
                    </div>
                `;
            }
        });
    }
    
    // Initial load of PDF when modal is shown
    const pdfModal = document.getElementById('pdfReaderModal');
    if (pdfModal) {
        pdfModal.addEventListener('shown.bs.modal', function() {
            loadPdf();
        });
    }

/**
 * Initialize Audio Player if it exists on the page
 */
function initAudioPlayer() {
    const audioPlayer = document.getElementById('audio-player');
    if (!audioPlayer) return;
    
    const audio = document.getElementById('audio');
    if (!audio) return;
    
    const bookId = audioPlayer.getAttribute('data-book-id');
    
    // Optional UI elements that might not exist in all player versions
    const playBtn = document.getElementById('play-btn');
    const muteBtn = document.getElementById('mute-btn');
    const seekSlider = document.getElementById('seek-slider');
    const volumeSlider = document.getElementById('volume-slider');
    const currentTime = document.getElementById('current-time');
    const duration = document.getElementById('duration');
    
    // Play/Pause - only if the button exists
    if (playBtn) {
        playBtn.addEventListener('click', function() {
            if (audio.paused) {
                audio.play();
                playBtn.innerHTML = '<i class="fas fa-pause"></i>';
            } else {
                audio.pause();
                playBtn.innerHTML = '<i class="fas fa-play"></i>';
            }
        });
    }
    
    // Mute/Unmute - only if the button exists
    if (muteBtn) {
        muteBtn.addEventListener('click', function() {
            if (audio.muted) {
                audio.muted = false;
                muteBtn.innerHTML = '<i class="fas fa-volume-up"></i>';
            } else {
                audio.muted = true;
                muteBtn.innerHTML = '<i class="fas fa-volume-mute"></i>';
            }
        });
    }
    
    // Update seek slider as audio plays - only if the elements exist
    audio.addEventListener('timeupdate', function() {
        // Only update UI elements if they exist
        if (seekSlider && !isNaN(audio.duration)) {
            const seekPosition = audio.currentTime * (100 / audio.duration);
            seekSlider.value = seekPosition;
        }
        
        // Update current time display if it exists
        if (currentTime && !isNaN(audio.duration)) {
            const mins = Math.floor(audio.currentTime / 60);
            const secs = Math.floor(audio.currentTime % 60);
            currentTime.textContent = mins + ':' + (secs < 10 ? '0' : '') + secs;
        }
        
        // Save bookmark (every 5 seconds) - this works regardless of UI
        if (Math.floor(audio.currentTime) % 5 === 0 && Math.floor(audio.currentTime) > 0 && !audio.paused) {
            saveBookmark(bookId, null, Math.floor(audio.currentTime));
        }
    });
    
    // Seek in the audio - only if the slider exists
    if (seekSlider) {
        seekSlider.addEventListener('change', function() {
            if (!isNaN(audio.duration)) {
                const seekTo = audio.duration * (seekSlider.value / 100);
                audio.currentTime = seekTo;
            }
        });
    }
    
    // Update volume - only if the slider exists
    if (volumeSlider) {
        volumeSlider.addEventListener('change', function() {
            audio.volume = volumeSlider.value / 100;
        });
    }
    
    // Update duration display when metadata is loaded - only if the element exists
    if (duration) {
        audio.addEventListener('loadedmetadata', function() {
            if (!isNaN(audio.duration)) {
                const mins = Math.floor(audio.duration / 60);
                const secs = Math.floor(audio.duration % 60);
                duration.textContent = mins + ':' + (secs < 10 ? '0' : '') + secs;
            }
        });
    }
}

/**
 * Initialize Bookmark System
 */
function initBookmarkSystem() {
    // This function will be called by the PHP code when needed
}

/**
 * Save bookmark position to the server
 * @param {number} bookId The book ID
 * @param {number|null} page The page number (for PDF)
 * @param {number|null} position The position (for audio)
 */
function saveBookmark(bookId, page, position) {
    // Only save if we have a book ID
    if (!bookId) return;
    
    fetch('actions/save_bookmark.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `book_id=${bookId}&page=${page || ''}&position=${position || ''}`
    })
    .then(response => response.json())
    .then(data => {
        // Bookmark saved successfully
        console.log('Bookmark saved:', data);
    })
    .catch(error => {
        console.error('Error saving bookmark:', error);
    });
}

/**
 * Initialize Form Validations
 */
function initFormValidations() {
    // Get all forms with the 'needs-validation' class
    const forms = document.querySelectorAll('.needs-validation');
    
    // Loop over them and prevent submission
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });
}

/**
 * Initialize Notification System
 */
function initNotifications() {
    // Mark notification as read when clicked
    const notificationLinks = document.querySelectorAll('.notification-link');
    const markAsReadButtons = document.querySelectorAll('.mark-notification-read');
    
    // Initialize toasts
    const toastElList = [].slice.call(document.querySelectorAll('.toast'));
    const toastList = toastElList.map(function(toastEl) {
        return new bootstrap.Toast(toastEl, {
            autohide: true,
            delay: 3000
        });
    });
    
    // Show toast on hover for notification actions
    document.querySelectorAll('[data-toast-message]').forEach(element => {
        element.addEventListener('mouseenter', function() {
            showToast(this.getAttribute('data-toast-message'), this.getAttribute('data-toast-type') || 'info');
        });
    });
    
    // Handle notification mark as read buttons
    markAsReadButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const notificationId = this.getAttribute('data-notification-id');
            
            fetch('actions/notification_actions.php?id=' + notificationId + '&action=mark_read&redirect=dashboard', {
                method: 'GET'
            })
            .then(response => {
                // Show toast notification
                showToast('Notification marked as read', 'success');
                
                // Update UI if needed
                const notificationElement = this.closest('.notification-item');
                if (notificationElement) {
                    notificationElement.classList.remove('bg-light');
                    this.style.display = 'none';
                }
                
                // Update badge count
                updateNotificationCount(-1);
            })
            .catch(error => {
                console.error('Error marking notification as read:', error);
                showToast('Failed to mark notification as read', 'danger');
            });
        });
    });
    
    // Handle mark all as read button
    const markAllAsReadBtn = document.querySelector('.mark-all-read');
    if (markAllAsReadBtn) {
        markAllAsReadBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            fetch('actions/notification_actions.php?action=mark_all_read&redirect=dashboard', {
                method: 'GET'
            })
            .then(response => {
                showToast('All notifications marked as read', 'success');
                
                // Update UI
                document.querySelectorAll('.notification-item').forEach(item => {
                    item.classList.remove('bg-light');
                });
                document.querySelectorAll('.mark-notification-read').forEach(btn => {
                    btn.style.display = 'none';
                });
                
                // Reset badge count
                document.querySelector('.notification-badge').style.display = 'none';
            })
            .catch(error => {
                console.error('Error marking all notifications as read:', error);
                showToast('Failed to mark all notifications as read', 'danger');
            });
        });
    }
}

/**
 * Show a toast notification
 * @param {string} message The message to display
 * @param {string} type The type of toast (success, danger, warning, info)
 */
function showToast(message, type = 'info') {
    // Create toast container if it doesn't exist
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    // Create toast element
    const toastId = 'toast-' + Date.now();
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.id = toastId;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    // Create toast content
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    // Add toast to container
    toastContainer.appendChild(toast);
    
    // Initialize and show toast
    const bsToast = new bootstrap.Toast(toast, {
        autohide: true,
        delay: 3000
    });
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', function() {
        toast.remove();
    });
}

/**
 * Update notification count badge
 * @param {number} change The change in count (positive or negative)
 */
function updateNotificationCount(change) {
    const badge = document.querySelector('.notification-badge');
    if (!badge) return;
    
    let count = parseInt(badge.textContent || '0');
    count += change;
    
    if (count <= 0) {
        badge.style.display = 'none';
    } else {
        badge.style.display = 'inline-block';
        badge.textContent = count;
    }
}

/**
 * Preview book cover image before upload
 * @param {HTMLInputElement} input The file input element
 */
function previewCover(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            document.getElementById('cover-preview').src = e.target.result;
            document.getElementById('cover-preview-container').style.display = 'block';
        }
        
        reader.readAsDataURL(input.files[0]);
    }
}

/**
 * Toggle download agreement section
 * @param {HTMLInputElement} checkbox The download allowed checkbox
 */
function toggleAgreement(checkbox) {
    const agreementSection = document.getElementById('download-agreement');
    if (checkbox.checked) {
        agreementSection.style.display = 'block';
    } else {
        agreementSection.style.display = 'none';
    }
}
