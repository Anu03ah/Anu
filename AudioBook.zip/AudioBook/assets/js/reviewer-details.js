/**
 * Reviewer details toggle functionality
 * Shows reviewer details below the name when clicked
 */
function toggleReviewerDetails(reviewId) {
    // Get the reviewer details element
    const detailsElement = document.getElementById('reviewerDetails' + reviewId);
    const iconElement = document.getElementById('reviewerToggleIcon' + reviewId);
    
    if (detailsElement) {
        // Toggle the display
        if (detailsElement.style.display === 'none') {
            // Show the details with a smooth animation
            detailsElement.style.display = 'block';
            
            // Rotate the chevron icon
            if (iconElement) {
                iconElement.classList.remove('fa-chevron-down');
                iconElement.classList.add('fa-chevron-up');
            }
        } else {
            // Hide the details
            detailsElement.style.display = 'none';
            
            // Reset the chevron icon
            if (iconElement) {
                iconElement.classList.remove('fa-chevron-up');
                iconElement.classList.add('fa-chevron-down');
            }
        }
    }
}

// Close all reviewer details when clicking outside
document.addEventListener('click', function(event) {
    // Check if the click was outside any reviewer container
    if (!event.target.closest('.reviewer-container')) {
        // Get all open reviewer details
        const openDetails = document.querySelectorAll('.reviewer-details[style*="display: block"]');
        const allIcons = document.querySelectorAll('.reviewer-toggle-icon');
        
        // Close each one
        openDetails.forEach(function(element) {
            element.style.display = 'none';
        });
        
        // Reset all icons
        allIcons.forEach(function(icon) {
            icon.classList.remove('fa-chevron-up');
            icon.classList.add('fa-chevron-down');
        });
    }
});
