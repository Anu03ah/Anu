/**
 * Auth Modal Trigger
 * Automatically shows the auth modal when a non-registered user tries to add a book to their library
 */
document.addEventListener('DOMContentLoaded', function() {
    // Check if the URL has the show_auth parameter
    const urlParams = new URLSearchParams(window.location.search);
    const showAuth = urlParams.get('show_auth');
    
    // If show_auth parameter is present, trigger the auth modal
    if (showAuth === '1') {
        const authModal = document.getElementById('authModal');
        if (authModal) {
            const modal = new bootstrap.Modal(authModal);
            modal.show();
            
            // Remove the show_auth parameter from the URL without reloading the page
            const newUrl = window.location.href.replace(/[&?]show_auth=1/, '');
            window.history.replaceState({}, document.title, newUrl);
        }
    }
});
