/**
 * Contact Support Modal Functionality
 * Handles the contact support popup for blocked users
 */

document.addEventListener('DOMContentLoaded', function() {
    // Get the contact support modal element
    const contactSupportModal = document.getElementById('contactSupportModal');
    
    // Initialize the contact support modal
    if (contactSupportModal) {
        const contactModal = new bootstrap.Modal(contactSupportModal);
        
        // Listen for clicks on the contact support link in the auth modal
        document.querySelectorAll('.contact-support-link').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Get the email from the link's data attribute
                const email = this.getAttribute('data-email') || '';
                
                // Set the email in the contact form
                const emailInput = document.getElementById('contact-email');
                if (emailInput) {
                    emailInput.value = email;
                }
                
                // Hide the auth modal and show the contact support modal
                const authModal = bootstrap.Modal.getInstance(document.getElementById('authModal'));
                if (authModal) {
                    authModal.hide();
                }
                
                // Show the contact support modal
                contactModal.show();
            });
        });
        
        // Handle the contact form submission
        const contactForm = document.getElementById('contactSupportForm');
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                // Form validation is handled by the browser and server-side
                
                // After submission, the form will be processed by submit_appeal.php
                // and the user will be redirected to the homepage with a success message
            });
        }
        
        // Handle the "return to login" button
        document.querySelectorAll('.return-to-login').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Hide the contact support modal
                contactModal.hide();
                
                // Show the auth modal again
                const authModal = new bootstrap.Modal(document.getElementById('authModal'));
                authModal.show();
                
                // Activate the login tab
                const loginTab = document.getElementById('login-tab');
                if (loginTab) {
                    const tab = new bootstrap.Tab(loginTab);
                    tab.show();
                }
            });
        });
    }
});
