/**
 * AudioBook - Notifications JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize notification system
    initNotificationSystem();
    
    // Initialize tooltips for existing buttons
    initTooltips();
    
    // Prevent dropdown from closing when clicking inside it
    const dropdown = document.querySelector('#notificationsDropdown');
    if (dropdown) {
        const notificationDropdownMenu = document.querySelector('.notification-dropdown');
        
        // Create a Bootstrap dropdown instance
        const bsDropdown = new bootstrap.Dropdown(dropdown, {
            autoClose: false // Prevent auto closing
        });
        
        // Add click handlers to specific elements that should close the dropdown
        document.addEventListener('click', function(e) {
            // Close if clicked outside the dropdown
            if (!notificationDropdownMenu.contains(e.target) && e.target !== dropdown) {
                bsDropdown.hide();
            }
        });
        
        // Handle the Load More button separately
        const loadMoreBtn = document.getElementById('loadMoreNotifications');
        if (loadMoreBtn) {
            loadMoreBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                e.preventDefault();
                
                // Call the load more function from initNotificationSystem
                if (!loadMoreBtn.disabled && !loadMoreBtn.classList.contains('loading')) {
                    loadMoreBtn.classList.add('loading');
                    loadMoreBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading...';
                    
                    // Trigger the load more function
                    const event = new Event('loadMore');
                    loadMoreBtn.dispatchEvent(event);
                }
            });
        }
        
        // Add click handlers to action buttons
        notificationDropdownMenu.querySelectorAll('.btn-outline-primary, .mark-notification-read, .btn-outline-danger').forEach(button => {
            button.addEventListener('click', function(e) {
                // Allow collapse buttons to work normally
                if (this.getAttribute('data-bs-toggle') === 'collapse') {
                    e.stopPropagation();
                    return;
                }
                
                // For action buttons, prevent default and handle via AJAX
                e.stopPropagation();
                e.preventDefault();
                
                // Get the URL for the action
                const url = this.getAttribute('href');
                
                // Show confirmation for delete buttons
                if (this.classList.contains('notification-delete-btn') || this.classList.contains('btn-outline-danger')) {
                    if (!confirm('Are you sure you want to delete this notification?')) {
                        return;
                    }
                }
                
                // Send AJAX request
                fetch(url)
                    .then(response => response.text())
                    .then(data => {
                        // Update UI if needed
                        if (this.classList.contains('mark-notification-read')) {
                            const notificationItem = this.closest('.notification-item');
                            if (notificationItem) {
                                notificationItem.classList.remove('bg-light');
                                this.style.display = 'none';
                                
                                // Remove 'New' badge
                                const badge = notificationItem.querySelector('.badge-sm');
                                if (badge) badge.remove();
                            }
                            
                            // Update badge count
                            updateNotificationCount(-1);
                        } else if (this.classList.contains('btn-outline-danger')) {
                            const notificationItem = this.closest('li');
                            if (notificationItem) {
                                notificationItem.remove();
                                
                                // Also remove the divider
                                const nextElement = notificationItem.nextElementSibling;
                                if (nextElement && nextElement.querySelector('hr')) {
                                    nextElement.remove();
                                }
                            }
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            });
        });
    }
});

/**
 * Initialize the notification system
 */
function initNotificationSystem() {
    // Track current page of notifications
    let currentPage = 1;
    const pageSize = 5;
    let loading = false;
    let hasMoreNotifications = true;
    
    // Get the load more button
    const loadMoreBtn = document.getElementById('loadMoreNotifications');
    if (!loadMoreBtn) return;
    
    // Get the notification dropdown
    const notificationDropdown = document.querySelector('.notification-dropdown');
    if (!notificationDropdown) return;
    
    // Handle load more button custom event
    loadMoreBtn.addEventListener('loadMore', function() {
        if (loading || !hasMoreNotifications) {
            loadMoreBtn.classList.remove('loading');
            loadMoreBtn.innerHTML = '<i class="fas fa-chevron-down me-1"></i> Load More';
            return;
        }
        
        loading = true;
        loadMoreNotifications();
    });
    
    /**
     * Load more notifications via AJAX
     */
    function loadMoreNotifications() {
        // Create a new XMLHttpRequest
        const xhr = new XMLHttpRequest();
        
        // Configure it: GET-request for the URL
        xhr.open('GET', `actions/get_notifications.php?page=${currentPage + 1}&size=${pageSize}`, true);
        
        // Send the request
        xhr.send();
        
        // This will be called after the response is received
        xhr.onload = function() {
            if (xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                
                if (response.success) {
                    // Update current page
                    currentPage++;
                    
                    // Check if there are more notifications
                    hasMoreNotifications = response.has_more;
                    
                    // Insert notifications before the load more button
                    if (response.notifications.length > 0) {
                        const loadMoreItem = loadMoreBtn.closest('li');
                        
                        response.notifications.forEach(notification => {
                            // Create notification item
                            const notificationItem = createNotificationItem(notification);
                            
                            // Insert before load more button
                            notificationDropdown.insertBefore(notificationItem, loadMoreItem);
                            
                            // Add divider
                            const divider = document.createElement('li');
                            divider.innerHTML = '<hr class="dropdown-divider my-1">';
                            notificationDropdown.insertBefore(divider, loadMoreItem);
                        });
                        
                        // Initialize tooltips for new items
                        initTooltips();
                    }
                    
                    // Update load more button
                    if (!hasMoreNotifications) {
                        loadMoreBtn.innerHTML = 'No more notifications';
                        loadMoreBtn.disabled = true;
                    } else {
                        loadMoreBtn.innerHTML = '<i class="fas fa-chevron-down me-1"></i> Load More';
                    }
                } else {
                    // Show error
                    showToast(response.message || 'Failed to load notifications', 'danger');
                    loadMoreBtn.innerHTML = '<i class="fas fa-chevron-down me-1"></i> Load More';
                }
            } else {
                // Show error
                showToast('Failed to load notifications', 'danger');
                loadMoreBtn.innerHTML = '<i class="fas fa-chevron-down me-1"></i> Load More';
            }
            
            // Reset loading state
            loading = false;
            loadMoreBtn.classList.remove('loading');
        };
        
        xhr.onerror = function() {
            // Show error
            showToast('Failed to load notifications', 'danger');
            loadMoreBtn.innerHTML = '<i class="fas fa-chevron-down me-1"></i> Load More';
            
            // Reset loading state
            loading = false;
            loadMoreBtn.classList.remove('loading');
        };
    }
}

/**
 * Create a notification item element
 * @param {Object} notification The notification data
 * @returns {HTMLElement} The notification item element
 */
function createNotificationItem(notification) {
    // Get icon based on notification type
    let icon = 'info-circle';
    switch (notification.type) {
        case 'purchase': icon = 'shopping-cart'; break;
        case 'review': icon = 'star'; break;
        case 'license_application':
        case 'license_approved':
        case 'license_rejected': icon = 'id-card'; break;
        case 'book_uploaded':
        case 'sale': icon = 'book'; break;
        case 'complaint_resolved': icon = 'check-circle'; break;
        case 'account_blocked': icon = 'ban'; break;
    }
    
    // Format date
    const date = new Date(notification.created_at);
    const formattedDate = `${date.toLocaleDateString()} ${date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
    
    // Create notification item
    const li = document.createElement('li');
    li.className = 'fade-in';
    
    // Create notification content
    li.innerHTML = `
        <div class="dropdown-item notification-item ${notification.is_read === '0' ? 'bg-light' : ''}">
            <div class="d-flex justify-content-between align-items-start mb-1">
                <small class="text-muted">${formattedDate}</small>
                ${notification.is_read === '0' ? '<span class="badge bg-primary badge-sm">New</span>' : ''}
            </div>
            <div class="mb-2">
                <i class="fas fa-${icon} me-1"></i>
                ${notification.message}
            </div>
            <div class="d-flex justify-content-end gap-1">
                ${notification.is_read === '0' ? `
                <a href="actions/notification_actions.php?id=${notification.id}&action=mark_read&redirect=dashboard" 
                   class="btn btn-sm btn-outline-secondary mark-notification-read" 
                   data-notification-id="${notification.id}" 
                   data-toast-message="Notification marked as read" 
                   data-toast-type="success" 
                   data-bs-toggle="tooltip" 
                   data-bs-placement="top" 
                   title="Mark as read">
                    <i class="fas fa-check"></i>
                </a>
                ` : ''}
                <a href="#" 
                   class="btn btn-sm btn-outline-primary" 
                   data-bs-toggle="collapse" 
                   data-bs-target="#notification-detail-dropdown-${notification.id}" 
                   aria-expanded="false" 
                   title="View details">
                    <i class="fas fa-eye"></i>
                </a>
                <a href="actions/notification_actions.php?id=${notification.id}&action=delete&redirect=dashboard" 
                   class="btn btn-sm btn-outline-danger" 
                   data-toast-message="Notification deleted" 
                   data-toast-type="success" 
                   title="Delete">
                    <i class="fas fa-trash"></i>
                </a>
            </div>
            <div class="collapse mt-2" id="notification-detail-dropdown-${notification.id}">
                <div class="card card-body py-2 px-3 bg-light">
                    <small>Type: ${notification.type.charAt(0).toUpperCase() + notification.type.slice(1)}</small>
                    <small>Created: ${new Date(notification.created_at).toLocaleString()}</small>
                </div>
            </div>
        </div>
    `;
    
    return li;
}

/**
 * Initialize tooltips for new elements
 */
function initTooltips() {
    // First dispose any existing tooltips to prevent duplicates
    const existingTooltips = document.querySelectorAll('.tooltip');
    existingTooltips.forEach(tooltip => {
        tooltip.remove();
    });
    
    // Initialize tooltips on elements with data-tooltip attribute
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-tooltip]'));
    tooltipTriggerList.forEach(function (tooltipTriggerEl) {
        new bootstrap.Tooltip(tooltipTriggerEl, {
            container: 'body',
            trigger: 'hover',
            placement: 'bottom'
        });
    });
}

// showToast function removed as requested

/**
 * Update the notification count badge
 * @param {number} change The change in count (positive or negative)
 */
function updateNotificationCount(change) {
    const badge = document.querySelector('.notification-badge');
    if (!badge) return;
    
    let count = parseInt(badge.textContent);
    count += change;
    
    if (count <= 0) {
        badge.style.display = 'none';
    } else {
        badge.style.display = 'block';
        badge.textContent = count;
    }
}
    
    /**
     * Create a notification item element
     * @param {Object} notification The notification data
     * @returns {HTMLElement} The notification item element
     */
    function createNotificationItem(notification) {
        // Get icon based on notification type
        let icon = 'info-circle';
        switch (notification.type) {
            case 'purchase': icon = 'shopping-cart'; break;
            case 'review': icon = 'star'; break;
            case 'license_application':
            case 'license_approved':
            case 'license_rejected': icon = 'id-card'; break;
            case 'book_uploaded':
            case 'sale': icon = 'book'; break;
            case 'complaint_resolved': icon = 'check-circle'; break;
            case 'account_blocked': icon = 'ban'; break;
        }
        
        // Format date
        const date = new Date(notification.created_at);
        const formattedDate = `${date.toLocaleDateString()} ${date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
        
        // Create notification item
        const li = document.createElement('li');
        li.className = 'fade-in';
        
        // Create notification content
        li.innerHTML = `
            <div class="dropdown-item notification-item ${notification.is_read === '0' ? 'bg-light' : ''}">
                <div class="d-flex justify-content-between align-items-start mb-1">
                    <small class="text-muted">${formattedDate}</small>
                    ${notification.is_read === '0' ? '<span class="badge bg-primary badge-sm">New</span>' : ''}
                </div>
                <div class="mb-2">
                    <i class="fas fa-${icon} me-1"></i>
                    ${notification.message}
                </div>
                <div class="d-flex justify-content-end gap-1">
                    ${notification.is_read === '0' ? `
                    <a href="actions/notification_actions.php?id=${notification.id}&action=mark_read&redirect=dashboard" 
                       class="btn btn-sm btn-outline-secondary mark-notification-read" 
                       data-notification-id="${notification.id}" 
                       aria-label="Mark as read">
                        <i class="fas fa-check"></i>
                    </a>
                    ` : ''}
                    <a href="#" 
                       class="btn btn-sm btn-outline-primary" 
                       data-bs-toggle="collapse" 
                       data-bs-target="#notification-detail-dropdown-${notification.id}" 
                       aria-expanded="false" 
                       aria-label="View details">
                        <i class="fas fa-eye"></i>
                    </a>
                    <a href="actions/notification_actions.php?id=${notification.id}&action=delete&redirect=dashboard" 
                       class="btn btn-sm btn-outline-danger notification-delete-btn" 
                       aria-label="Delete">
                        <i class="fas fa-trash"></i>
                    </a>
                </div>
                <div class="collapse mt-2" id="notification-detail-dropdown-${notification.id}">
                    <div class="card card-body py-2 px-3 bg-light">
                        <small>Type: ${notification.type.charAt(0).toUpperCase() + notification.type.slice(1)}</small>
                        <small>Created: ${new Date(notification.created_at).toLocaleString()}</small>
                    </div>
                </div>
            </div>
        `;
        
        return li;
    }
    
    /**
     * Initialize tooltips for new elements
     */
    function initTooltips() {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.forEach(function (tooltipTriggerEl) {
            new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }

// End of file
