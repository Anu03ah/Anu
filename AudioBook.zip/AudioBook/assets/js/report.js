/**
 * Report functionality for AudioBook
 * Handles reporting of books, users, and reviews
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize report modals
    const reportButtons = document.querySelectorAll('[data-bs-toggle="report-modal"]');
    
    reportButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const reportType = this.getAttribute('data-report-type');
            const targetId = this.getAttribute('data-target-id');
            const targetName = this.getAttribute('data-target-name');
            
            // Set values in the modal
            document.getElementById('report-modal-title').textContent = 'Report ' + 
                (reportType === 'book' ? 'Book' : (reportType === 'user' ? 'User' : 'Review'));
            
            document.getElementById('report-target-name').textContent = targetName;
            document.getElementById('report-type').value = reportType;
            document.getElementById('target-id').value = targetId;
            
            // Show the modal
            const reportModal = new bootstrap.Modal(document.getElementById('reportModal'));
            reportModal.show();
        });
    });
});
